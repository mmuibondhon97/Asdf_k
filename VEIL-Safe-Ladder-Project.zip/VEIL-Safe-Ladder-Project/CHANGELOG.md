# Changelog

## VEIL-Safe 1.0.0 - 2026-11-22

- Added structural VEIL diagnostics to Ladder without free-text causal attribution.
- Preserved explicit provider policy responses; no automatic reroute, refusal scrub, safety-off parameter or weight surgery.
- Added strict result-set evaluation using the repository's actual P01-P25 synthetic protocol corpus.
- Added a metadata-only SHA-256 hash-chained ledger with strict field allow-list, symlink checks, schema validation and tamper detection.
- Added read-only file signature identification and SHA-256 reporting.
- Added route-level and security regression coverage.
- Recorded a detailed audit of proposed VEIL v1.0.0 and Guard v4.3.0 integration seams.
- Release dependency-integrity remains blocked pending a real target wheelhouse and generated lockfiles.
