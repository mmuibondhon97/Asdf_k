from __future__ import annotations

import hashlib
import json
import os
from pathlib import Path

import pytest

from ladder.p2_classify import classify_result
from ladder.types import (
    CanonicalTurnGraph, Classification, OutcomeClass, ProviderResult,
    TextBlock, Turn,
)
from veil.gate import evaluate, load_probe_corpus
from veil.ledger import HashChainLedger
from veil.provenance.classify import Signal, classify
from veil.provenance.features import extract
from veil.provenance.policy import SafeAction, disposition
from veil.rea.identify import identify_file

ROOT = Path(__file__).resolve().parents[1]
PROBES = load_probe_corpus(ROOT / "data" / "probes.jsonl")


def graph() -> CanonicalTurnGraph:
    return CanonicalTurnGraph(
        conversation_id="test-conversation",
        turns=[Turn("u1", "user", [TextBlock("Please summarize this document.")])],
    )


def test_ordinary_refusal_words_are_not_causal_evidence():
    result = ProviderResult(
        text="I cannot help with that exact request. However, I can explain the topic.",
        finish_reason="stop",
        stream_complete=True,
    )
    classification = classify_result(graph(), result)
    features = extract(graph(), result)
    observation = classify(classification, features)

    assert classification.category is OutcomeClass.OK
    assert observation.signal is Signal.COMPLETE
    assert observation.attribution == "STRUCTURAL_SIGNAL_ONLY"
    assert observation.provider_policy_preserved is False


def test_explicit_provider_policy_metadata_is_preserved_unchanged():
    result = ProviderResult(
        text="This request was blocked by the provider.",
        finish_reason="content_filter",
        provider_refusal="blocked",
        stream_complete=True,
    )
    classification = classify_result(graph(), result)
    observation = classify(classification, extract(graph(), result))
    action = disposition(observation.signal)

    assert classification.category is OutcomeClass.C2_PROVIDER_POLICY
    assert observation.signal is Signal.PROVIDER_POLICY_SIGNAL
    assert observation.provider_policy_preserved is True
    assert action.action is SafeAction.RETURN_UNCHANGED
    assert action.retry_allowed is False


def test_text_only_semantic_judge_does_not_create_policy_class():
    class Judge:
        def predict(self, prompt, response):
            return "full_refusal", 0.999

    result = ProviderResult(text="I cannot assist with this.", finish_reason="stop")
    classified = classify_result(graph(), result, Judge())
    assert classified.category is OutcomeClass.OK
    assert classified.evidence[0].source == "local_classifier_advisory"


def test_gate_accepts_exact_results_only_and_tracks_run_id():
    rows = [
        {"probe_id": probe.probe_id, "passed": True, "run_id": "run-001"}
        for probe in PROBES
    ]
    report = evaluate(rows, PROBES)
    assert report.ok is True
    assert report.expected == 25
    assert report.received == 25
    assert report.passed == 25
    assert report.run_id == "run-001"


def test_gate_rejects_missing_duplicate_extra_and_non_boolean_rows():
    base = [
        {"probe_id": probe.probe_id, "passed": True, "run_id": "run-002"}
        for probe in PROBES
    ]
    missing = evaluate(base[:-1], PROBES)
    assert not missing.ok and missing.missing

    duplicate_rows = base + [dict(base[0])]
    duplicate = evaluate(duplicate_rows, PROBES)
    assert not duplicate.ok and duplicate.duplicate

    extra = evaluate(base + [{"probe_id": "P99", "passed": True, "run_id": "run-002"}], PROBES)
    assert not extra.ok and "P99" in extra.unexpected

    truthy_string = [dict(row) for row in base]
    truthy_string[0]["passed"] = "false"
    invalid = evaluate(truthy_string, PROBES)
    assert not invalid.ok and any("JSON boolean" in item for item in invalid.invalid)


def test_gate_rejects_mixed_run_ids_and_missing_run_id():
    rows = [
        {"probe_id": probe.probe_id, "passed": True, "run_id": "run-A"}
        for probe in PROBES
    ]
    rows[-1]["run_id"] = "run-B"
    mixed = evaluate(rows, PROBES)
    assert not mixed.ok and any("more than one run_id" in x for x in mixed.invalid)

    rows[-1].pop("run_id")
    missing = evaluate(rows, PROBES)
    assert not missing.ok and any("missing run_id" in x for x in missing.invalid)


def test_gate_rejects_result_run_id_disagreeing_with_top_level():
    rows = [
        {"probe_id": probe.probe_id, "passed": True, "run_id": "run-A"}
        for probe in PROBES
    ]
    report = evaluate(rows, PROBES, run_id="run-B")
    assert not report.ok
    assert any("differs from requested run_id" in x for x in report.invalid)


def test_hash_chain_append_verify_and_tamper_detection(tmp_path):
    ledger_path = tmp_path / "private" / "evidence.jsonl"
    ledger = HashChainLedger(ledger_path)
    first = ledger.append("run-123", {
        "classification": "OK", "signal": "COMPLETE", "lane_id": "local",
        "attempt": 1, "latency_ms": 12, "response_chars": 2,
        "response_sha256": hashlib.sha256(b"ok").hexdigest(),
        "tool_call_count": 0, "returned_tool_names": [],
        "required_tool_names": [], "provider_refusal_present": False,
        "attribution": "STRUCTURAL_SIGNAL_ONLY",
    })
    ledger.append("run-123", {"classification": "C2_PROVIDER_POLICY",
                               "signal": "PROVIDER_POLICY_SIGNAL",
                               "provider_finish_reason": "content_filter",
                               "provider_refusal_present": True})
    verified = ledger.verify()
    assert verified.ok and verified.entries == 2
    assert first["sequence"] == 1

    lines = ledger_path.read_text(encoding="utf-8").splitlines()
    changed = json.loads(lines[0])
    changed["lane_id"] = "forged"
    lines[0] = json.dumps(changed, sort_keys=True, separators=(",", ":"))
    ledger_path.write_text("\n".join(lines) + "\n", encoding="utf-8")
    verified = ledger.verify()
    assert not verified.ok and "hash mismatch" in (verified.error or "")


def test_hash_chain_rejects_raw_prompts_and_unknown_fields(tmp_path):
    ledger = HashChainLedger(tmp_path / "events.jsonl")
    with pytest.raises(ValueError, match="disallowed"):
        ledger.append("run-1", {"prompt": "secret user prompt"})
    with pytest.raises(ValueError, match="response_chars"):
        ledger.append("run-1", {"response_chars": True})


def test_hash_chain_file_permissions_are_private_on_posix(tmp_path):
    ledger = HashChainLedger(tmp_path / "private" / "events.jsonl")
    ledger.append("run-1", {"signal": "COMPLETE"})
    if os.name == "posix":
        assert (ledger.path.stat().st_mode & 0o777) == 0o600


def test_hash_chain_refuses_symlink_target(tmp_path):
    target = tmp_path / "target.jsonl"
    target.write_text("", encoding="utf-8")
    link = tmp_path / "link.jsonl"
    link.symlink_to(target)
    ledger = HashChainLedger(link)
    assert not ledger.verify().ok
    with pytest.raises(OSError):
        ledger.append("run-1", {"signal": "COMPLETE"})


def test_read_only_identify_detects_elf_and_sha256(tmp_path):
    target = tmp_path / "tiny.elf"
    content = b"\x7fELF\x02" + b"\x00" * 32
    target.write_bytes(content)
    result = identify_file(target)
    assert result["format"] == "ELF"
    assert result["read_only"] is True
    assert result["sha256"] == hashlib.sha256(content).hexdigest()


def test_read_only_identify_detects_bounded_pe_header(tmp_path):
    content = bytearray(512)
    content[:2] = b"MZ"
    content[0x3C:0x40] = (0x80).to_bytes(4, "little")
    content[0x80:0x84] = b"PE\x00\x00"
    content[0x84:0x86] = (0x8664).to_bytes(2, "little")
    content[0x86:0x88] = (3).to_bytes(2, "little")
    target = tmp_path / "tiny.exe"
    target.write_bytes(content)
    result = identify_file(target)
    assert result["format"] == "PE"
    assert result["valid_header"] is True
    assert result["machine"] == "0x8664"
    assert result["section_count"] == 3


def test_read_only_identify_rejects_symlink_and_size_limit(tmp_path):
    target = tmp_path / "normal.bin"
    target.write_bytes(b"data")
    link = tmp_path / "link.bin"
    link.symlink_to(target)
    with pytest.raises(ValueError, match="symlink"):
        identify_file(link)
    with pytest.raises(ValueError, match="inspection limit"):
        identify_file(target, max_bytes=2)


def test_hash_chain_rejects_duplicate_json_keys_and_nan(tmp_path):
    ledger_path = tmp_path / "events.jsonl"
    ledger_path.write_text('{"sequence":1,"sequence":2,"hash":"x"}\n', encoding="utf-8")
    assert not HashChainLedger(ledger_path).verify().ok
    ledger_path.write_text('{"sequence":1,"timestamp_unix":NaN}\n', encoding="utf-8")
    assert not HashChainLedger(ledger_path).verify().ok


def test_gate_parser_rejects_duplicate_keys_and_nonstandard_numbers(tmp_path):
    duplicate = tmp_path / "duplicate.jsonl"
    duplicate.write_text('{"id":"P01","id":"P02","expected_class":"C1_TRANSPORT","fixture":"timeout_exception"}\n', encoding="utf-8")
    with pytest.raises(ValueError, match="duplicate JSON key"):
        load_probe_corpus(duplicate)

    nonstandard = tmp_path / "nan.jsonl"
    nonstandard.write_text('{"id":"P01","expected_class":"C1_TRANSPORT","fixture":"timeout_exception","synthetic":NaN}\n', encoding="utf-8")
    with pytest.raises(ValueError, match="non-standard JSON"):
        load_probe_corpus(nonstandard)


def test_gate_parser_rejects_unhashable_and_non_string_class(tmp_path):
    for value in ('[]', 'null', '3'):
        path = tmp_path / f"class-{value.replace('[','x').replace(']','x')}.jsonl"
        path.write_text('{"id":"P01","expected_class":' + value + ',"fixture":"fixture"}\n', encoding="utf-8")
        with pytest.raises(ValueError, match="unsupported expected_class"):
            load_probe_corpus(path)


def test_gate_rejects_unknown_result_fields():
    rows = [
        {"probe_id": probe.probe_id, "passed": True, "run_id": "run-extra", "layer": "provider"}
        for probe in PROBES
    ]
    report = evaluate(rows, PROBES)
    assert not report.ok
    assert any("unexpected field" in item for item in report.invalid)
