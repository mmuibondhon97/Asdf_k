from __future__ import annotations

import asyncio
import inspect
import time
import uuid
from typing import Any, Callable

from ladder.p2_classify import ResponseJudge, classify_exception, classify_result
from ladder.p3_disposition import decide
from ladder.p4_lanes import SessionAffinity, build_lane_kwargs, rank_lanes
from ladder.p6_meter import FingerprintMeter
from ladder.p5_reconstruction import collect_litellm_stream, extract_nonstreaming
from veil.observe import observation_payload as veil_observation_payload

from ladder.types import (Action, AttemptRecord, CanonicalTurnGraph, Classification,
                          Evidence, Lane, OpaqueBlock, OutcomeClass, ProviderResult, RequestContext, RouteResult, TextBlock)


class RouteEngine:
    def __init__(self, settings, lanes: list[Lane], completion: Callable[..., Any] | None = None,
                 judge: ResponseJudge | None = None, meter: FingerprintMeter | None = None,
                 affinity: SessionAffinity | None = None, ledger=None, veil_ledger=None):
        self.settings = settings
        self.lanes = lanes
        self._completion = completion
        self.judge = judge
        self.meter = meter or FingerprintMeter(settings.metrics_path)
        self.affinity = affinity or SessionAffinity()
        self.ledger = ledger
        self.veil_ledger = veil_ledger

    def _client(self):
        if self._completion is None:
            import litellm
            return litellm.acompletion
        return self._completion

    async def _call(self, lane: Lane, graph: CanonicalTurnGraph, payload: dict[str, Any],
                    request: RequestContext, streaming: bool) -> ProviderResult:
        remaining = request.deadline_monotonic - time.monotonic()
        if remaining <= 0:
            raise TimeoutError("request deadline exhausted")
        messages = graph.to_openai_messages()
        kwargs = build_lane_kwargs(lane, messages, payload, remaining,
                                   request.output_token_budget, stream=streaming)
        client = self._client()
        async with asyncio.timeout(remaining):
            value = client(**kwargs)
            response = await value if inspect.isawaitable(value) else value
            if streaming:
                if not hasattr(response, "__aiter__"):
                    raise TypeError("streaming provider did not return an async iterator")
                return await collect_litellm_stream(response, self.settings.max_response_chars)
            return extract_nonstreaming(response)

    async def route(self, graph: CanonicalTurnGraph, payload: dict[str, Any],
                    request: RequestContext, streaming: bool = False) -> RouteResult:
        run_id = uuid.uuid4().hex
        tools_disabled = payload.get("tool_choice") == "none"
        required_modalities: set[str] = set()
        for turn in graph.turns:
            for block in turn.blocks:
                if isinstance(block, TextBlock):
                    required_modalities.add("text")
                elif isinstance(block, OpaqueBlock):
                    kind = block.kind.lower()
                    if kind in {"image", "input_image", "image_url"}:
                        required_modalities.add("image")
                    elif kind.startswith("audio") or kind in {"input_audio", "output_audio"}:
                        required_modalities.add("audio")
                    elif kind.startswith("video") or kind == "input_video":
                        required_modalities.add("video")
        if not required_modalities:
            required_modalities.add("text")
        candidates = rank_lanes(self.lanes, self.meter.ranking_profiles(),
                                require_tools=bool(graph.tool_contract.available_tools) and not tools_disabled,
                                require_streaming=streaming,
                                require_json=payload.get("response_format") is not None,
                                required_modalities=required_modalities)
        requested = request.requested_model
        if requested and requested not in ("auto", "ladder"):
            matching = [x for x in candidates if requested in (x.id, x.model, x.model.split("/", 1)[-1])]
            if not matching:
                return RouteResult(False, error_code="invalid_model", error_message="requested model is not a configured lane",
                                   status_code=400, run_id=run_id)
            candidates = matching
        if not candidates:
            return RouteResult(False, error_code="no_compatible_lane",
                               error_message="no enabled lane satisfies the request capabilities",
                               status_code=503, run_id=run_id)

        sticky_id = self.affinity.get(request.session_id)
        if sticky_id:
            sticky = [x for x in candidates if x.id == sticky_id]
            rest = [x for x in candidates if x.id != sticky_id]
            candidates = sticky + rest

        diagnostics: list[AttemptRecord] = []
        attempts = 0
        for lane_index, lane in enumerate(candidates):
            if attempts >= self.settings.max_attempts:
                break
            same_lane_retries = 0
            while attempts < self.settings.max_attempts:
                remaining = request.deadline_monotonic - time.monotonic()
                if remaining <= 0:
                    return RouteResult(False, attempts=attempts, diagnostics=diagnostics,
                                       error_code="deadline_exceeded", error_message="routing deadline exhausted",
                                       status_code=504, run_id=run_id)
                attempts += 1
                started = time.monotonic()
                try:
                    provider_result = await self._call(lane, graph, payload, request, streaming)
                    classification = classify_result(graph, provider_result, self.judge)
                except (ValueError, TypeError) as exc:
                    provider_result = None
                    classification = Classification(OutcomeClass.C3_INCOMPLETE,
                        (Evidence("provider_protocol", f"invalid or incomplete response: {type(exc).__name__}"),))
                except Exception as exc:
                    provider_result = None
                    classification = classify_exception(exc)
                elapsed = int((time.monotonic() - started) * 1000)
                evidence = [{"source": e.source, "code": e.code,
                             "excerpt": e.excerpt, "confidence": e.confidence}
                            for e in classification.evidence]
                diagnostics.append(AttemptRecord(attempts, lane.id, classification.category.value,
                                                 elapsed, evidence))
                try:
                    self.meter.record(lane.id, classification.category.value, elapsed, run_id)
                except OSError:
                    # Routing correctness must not depend on an optional metrics file.
                    pass
                if self.ledger:
                    try:
                        self.ledger.append({"run_id": run_id, "request_id": request.request_id,
                                            "lane_id": lane.id, "attempt": attempts,
                                            "class": classification.category.value,
                                            "evidence": evidence, "latency_ms": elapsed,
                                            "veil": veil_observation_payload(graph, provider_result, classification),
                                            "session_id_hash": __import__("hashlib").sha256(
                                                (request.session_id or "").encode("utf-8")).hexdigest() if request.session_id else None})
                    except OSError as exc:
                        return RouteResult(False, attempts=attempts, diagnostics=diagnostics,
                                           error_code="evidence_ledger_unavailable",
                                           error_message=f"evidence ledger write failed: {type(exc).__name__}",
                                           status_code=507, run_id=run_id)

                if self.veil_ledger is not None:
                    try:
                        observation = veil_observation_payload(graph, provider_result, classification)
                        feature = observation.get("features", {})
                        self.veil_ledger.append(run_id, {
                            "classification": classification.category.value,
                            "signal": observation.get("signal", "UNDETERMINED"),
                            "lane_id": lane.id,
                            "attempt": attempts,
                            "latency_ms": elapsed,
                            "response_chars": int(feature.get("response_chars", 0)),
                            "response_sha256": feature.get("response_sha256"),
                            "tool_call_count": int(feature.get("tool_call_count", 0)),
                            "returned_tool_names": feature.get("returned_tool_names", []),
                            "required_tool_names": feature.get("required_tool_names", []),
                            "provider_finish_reason": feature.get("finish_reason"),
                            "provider_refusal_present": bool(feature.get("provider_refusal_present", False)),
                            "attribution": observation.get("attribution", "NOT_ESTABLISHED"),
                        })
                    except (OSError, TypeError, ValueError) as exc:
                        return RouteResult(False, attempts=attempts, diagnostics=diagnostics,
                                           error_code="veil_evidence_ledger_unavailable",
                                           error_message=f"VEIL evidence write failed: {type(exc).__name__}",
                                           status_code=507, run_id=run_id)

                disposition = decide(classification, same_lane_retries)
                if disposition.action == Action.RETURN and provider_result is not None:
                    self.affinity.set(request.session_id, lane.id)
                    return RouteResult(True, provider_result, lane, attempts, classification,
                                       diagnostics, run_id=run_id)
                if disposition.action == Action.RETRY_SAME:
                    same_lane_retries += 1
                    continue
                if disposition.action == Action.TRY_NEXT_COMPATIBLE:
                    break
                # C2/C6/C7 and exhausted incomplete responses terminate here.
                return RouteResult(False, provider_result, lane, attempts, classification,
                                   diagnostics, classification.category.value,
                                   disposition.reason, disposition.status_code, run_id)
            # A new lane is only selected at a request/turn boundary. The full
            # normalized conversation graph is passed again on every attempt.
        last_classification = classification if diagnostics else None
        return RouteResult(False, attempts=attempts, classification=last_classification,
                           diagnostics=diagnostics,
                           error_code="attempts_exhausted",
                           error_message="all compatible lanes exhausted without a complete response",
                           status_code=502, run_id=run_id)
