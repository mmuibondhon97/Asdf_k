from __future__ import annotations

import asyncio
import html
import ipaddress
import inspect
import json
import logging
import os
import time
import uuid
from dataclasses import dataclass
from pathlib import Path
from typing import Any

from fastapi import FastAPI, HTTPException, Request
from fastapi.responses import HTMLResponse, JSONResponse, StreamingResponse

from ladder import __version__
from ladder.auth import check_token
from ladder.config import Settings, lane_from_dict, lane_to_dict, load_lanes, save_lanes
from ladder.p0_ingress import IngressError, parse_body, request_context
from ladder.p1_normalize import (NormalizeError, anthropic_choice_to_openai,
                                 anthropic_tools_to_openai, normalize_anthropic,
                                 normalize_openai)
from ladder.p4_lanes import LOCAL_PRESENCE_KEY, SessionAffinity
from ladder.p6_meter import FingerprintMeter
from ladder.p5_reconstruction import (anthropic_sse, error_sse, extract_nonstreaming,
                                      openai_sse, to_anthropic_response, to_openai_response)
from ladder.p6_ledger import EvidenceLedger
from ladder.router import RouteEngine
from ladder.types import Lane
from veil.ledger import HashChainLedger

log = logging.getLogger("ladder")


@dataclass
class AppContext:
    settings: Settings
    lanes: list[Lane]
    completion: Any = None
    judge: Any = None
    meter: FingerprintMeter | None = None
    affinity: SessionAffinity | None = None
    ledger: EvidenceLedger | None = None
    configured_lanes: list[Lane] | None = None
    veil_ledger: HashChainLedger | None = None

    @classmethod
    def load(cls) -> "AppContext":
        settings = Settings.from_env()
        configured_lanes = load_lanes(settings, include_inactive=True)
        lanes = [lane for lane in configured_lanes
                 if lane.enabled and (not lane.needs_key or
                                      (lane.api_key_env and os.environ.get(lane.api_key_env)))]
        secret_values = tuple(filter(None, [*settings.auth_tokens,
            *(os.environ.get(lane.api_key_env, "") for lane in configured_lanes if lane.api_key_env)]))
        judge = None
        classifier_model = os.environ.get("LADDER_CLASSIFIER_MODEL")
        classifier_revision = os.environ.get("LADDER_CLASSIFIER_REVISION")
        if classifier_model or classifier_revision:
            if not classifier_model or not classifier_revision:
                raise ValueError("LADDER_CLASSIFIER_MODEL and LADDER_CLASSIFIER_REVISION must be set together")
            from ladder.classifier_hf import HuggingFaceRefusalJudge
            judge = HuggingFaceRefusalJudge(classifier_model, classifier_revision,
                                            device=os.environ.get("LADDER_CLASSIFIER_DEVICE"))
        veil_ledger_path = os.environ.get("VEIL_AUDIT_LEDGER")
        veil_ledger = HashChainLedger(Path(veil_ledger_path).expanduser()) if veil_ledger_path else None
        return cls(settings=settings, lanes=lanes, judge=judge,
                   meter=FingerprintMeter(settings.metrics_path), affinity=SessionAffinity(),
                   ledger=EvidenceLedger(settings.ledger_path, secret_values),
                   configured_lanes=configured_lanes, veil_ledger=veil_ledger)

    def engine(self) -> RouteEngine:
        if self.meter is None:
            self.meter = FingerprintMeter(self.settings.metrics_path)
        if self.affinity is None:
            self.affinity = SessionAffinity()
        if self.ledger is None:
            secret_values = tuple(filter(None, [*self.settings.auth_tokens,
                *(os.environ.get(lane.api_key_env, "") for lane in self.lanes if lane.api_key_env)]))
            self.ledger = EvidenceLedger(self.settings.ledger_path, secret_values)
        return RouteEngine(self.settings, self.lanes, self.completion, self.judge,
                           self.meter, self.affinity, self.ledger, self.veil_ledger)


def _loopback(request: Request) -> bool:
    peer = request.client.host if request.client else ""
    host = request.headers.get("host", "").split(":", 1)[0].strip("[]").lower()
    if host not in ("127.0.0.1", "localhost"):
        return False
    if peer == "testclient":
        return True  # Starlette's in-process test transport has no socket peer.
    try:
        return ipaddress.ip_address(peer).is_loopback
    except ValueError:
        return False


def _error_payload(result) -> dict[str, Any]:
    return {"error": {"type": "ladder_route_error", "code": result.error_code,
                       "message": result.error_message,
                       "classification": result.classification.category.value if result.classification else None,
                       "run_id": result.run_id,
                       "diagnostics": [r.__dict__ for r in result.diagnostics]}}


def create_app(ctx: AppContext | None = None) -> FastAPI:
    ctx = ctx or AppContext.load()
    app = FastAPI(title="ladder", version=__version__)
    app.state.ctx = ctx

    @app.middleware("http")
    async def auth_and_host_guard(request: Request, call_next):
        if request.url.path == "/v1" or request.url.path.startswith("/v1/"):
            if not check_token(request.headers.get("authorization"), ctx.settings.auth_tokens,
                               request.headers.get("x-api-key")):
                return JSONResponse(status_code=401, content={"error": {"type": "authentication_error",
                                                                          "message": "missing or invalid Ladder token"}})
        if request.url.path.startswith("/setup") and not _loopback(request):
            return JSONResponse(status_code=403, content={"error": {"message": "operator surface is loopback-only"}})
        return await call_next(request)

    @app.get("/healthz")
    async def healthz():
        return {"status": "ok", "version": __version__, "configured_lanes": len(ctx.lanes)}

    @app.get("/v1/models")
    async def models():
        return {"object": "list", "data": [{"id": lane.id, "object": "model", "owned_by": lane.provider}
                                             for lane in ctx.lanes]}

    async def _body(request: Request) -> dict[str, Any]:
        # Consume incrementally so an oversized body is rejected before the
        # entire payload is retained in memory.
        chunks: list[bytes] = []
        total = 0
        async for chunk in request.stream():
            total += len(chunk)
            if total > ctx.settings.max_request_bytes:
                raise IngressError("request body exceeds configured size limit", 413)
            chunks.append(chunk)
        return parse_body(b"".join(chunks), ctx.settings.max_request_bytes)

    def _engine_and_context(body: dict[str, Any], request: Request):
        req_ctx = request_context(request.headers, body, ctx.settings, body.get("model"))
        return ctx.engine(), req_ctx

    @app.post("/v1/chat/completions")
    async def chat_completions(request: Request):
        try:
            body = await _body(request)
            graph = normalize_openai(body)
            engine, req_ctx = _engine_and_context(body, request)
        except (IngressError, NormalizeError) as exc:
            status = getattr(exc, "status_code", 400)
            raise HTTPException(status_code=status, detail={"error": {"message": str(exc)}})
        streaming = bool(body.get("stream", False))
        result = await engine.route(graph, body, req_ctx, streaming=streaming)
        policy_completion = (not result.ok and result.classification is not None
                             and result.classification.category.value == "C2_PROVIDER_POLICY"
                             and result.provider_result is not None and result.lane is not None)
        if not result.ok and not policy_completion:
            if streaming:
                return StreamingResponse(iter([error_sse({"type": result.error_code,
                    "message": result.error_message, "run_id": result.run_id,
                    "classification": result.classification.category.value if result.classification else None,
                    "diagnostics": [r.__dict__ for r in result.diagnostics]})]),
                    media_type="text/event-stream", headers={"Cache-Control": "no-cache", "X-Accel-Buffering": "no"})
            return JSONResponse(status_code=result.status_code, content=_error_payload(result))
        assert result.provider_result is not None and result.lane is not None
        classification = result.classification.category.value if result.classification else "OK"
        if streaming:
            frames = openai_sse(result.provider_result, result.lane.model, result.run_id,
                                bool((body.get("stream_options") or {}).get("include_usage", False)),
                                classification)
            return StreamingResponse(iter(frames), media_type="text/event-stream",
                                     headers={"Cache-Control": "no-cache", "X-Accel-Buffering": "no"})
        response = to_openai_response(result.provider_result, result.lane.model,
                                      result.run_id, result.lane.id, result.attempts, classification)
        return JSONResponse(response)

    @app.post("/v1/messages")
    async def anthropic_messages(request: Request):
        try:
            body = await _body(request)
            graph = normalize_anthropic(body)
            payload = dict(body)
            payload["messages"] = graph.to_openai_messages()
            payload["tools"] = anthropic_tools_to_openai(body.get("tools", []))
            payload["tool_choice"] = anthropic_choice_to_openai(body.get("tool_choice"))
            payload["max_tokens"] = body.get("max_tokens", ctx.settings.output_token_budget)
            if isinstance(body.get("stop_sequences"), list):
                payload["stop"] = body["stop_sequences"]
            engine, req_ctx = _engine_and_context(payload, request)
        except (IngressError, NormalizeError) as exc:
            status = getattr(exc, "status_code", 400)
            raise HTTPException(status_code=status, detail={"error": {"message": str(exc)}})
        streaming = bool(body.get("stream", False))
        result = await engine.route(graph, payload, req_ctx, streaming=streaming)
        policy_completion = (not result.ok and result.classification is not None
                             and result.classification.category.value == "C2_PROVIDER_POLICY"
                             and result.provider_result is not None and result.lane is not None)
        if not result.ok and not policy_completion:
            error = {"type": result.error_code or "ladder_error", "message": result.error_message,
                     "run_id": result.run_id,
                     "classification": result.classification.category.value if result.classification else None,
                     "diagnostics": [r.__dict__ for r in result.diagnostics]}
            if streaming:
                return StreamingResponse(iter([error_sse(error, anthropic=True)]),
                                         media_type="text/event-stream")
            return JSONResponse(status_code=result.status_code,
                                content={"type": "error", "error": error})
        assert result.provider_result is not None and result.lane is not None
        classification = result.classification.category.value if result.classification else "OK"
        if streaming:
            frames = anthropic_sse(result.provider_result, result.lane.model, result.run_id,
                                   result.lane.id, result.attempts, classification)
            return StreamingResponse(iter(frames), media_type="text/event-stream",
                                     headers={"Cache-Control": "no-cache", "X-Accel-Buffering": "no"})
        return JSONResponse(to_anthropic_response(result.provider_result, result.lane.model,
                                                  result.run_id, result.lane.id,
                                                  result.attempts, classification))

    @app.get("/setup/", response_class=HTMLResponse)
    async def setup_page():
        rows = []
        display_lanes = ctx.configured_lanes if ctx.configured_lanes is not None else ctx.lanes
        active_ids = {lane.id for lane in ctx.lanes}
        for lane in display_lanes:
            status = "active" if lane.id in active_ids else ("disabled" if not lane.enabled else "missing key")
            probe = (f"<button type='button' onclick=\"probeLane('{html.escape(lane.id, quote=True)}')\">Probe</button>"
                     if lane.id in active_ids else "—")
            rows.append(f"<tr><td>{html.escape(lane.id)}</td><td>{html.escape(lane.provider)}</td>"
                        f"<td>{html.escape(lane.model)}</td><td>{status}</td>"
                        f"<td>{'yes' if lane.capabilities.tools else 'no'}</td>"
                        f"<td>{probe}</td></tr>")
        editor_json = html.escape(json.dumps([lane_to_dict(lane) for lane in display_lanes],
                                             ensure_ascii=False, indent=2))
        page = ("<!doctype html><html><head><meta charset='utf-8'><title>ladder setup</title></head><body>"
                f"<h1>ladder {__version__}</h1><p>Loopback-only operator surface. Secrets are environment-only.</p>"
                "<h2>Configured lanes</h2><table><thead><tr><th>ID</th><th>Provider</th><th>Model</th>"
                "<th>Status</th><th>Tools</th><th>One-shot probe</th></tr></thead><tbody>" + "".join(rows) +
                "</tbody></table><h2>Operational fingerprints</h2>"
                "<table><thead><tr><th>Lane</th><th>Samples</th><th>Success rate</th>"
                "<th>Mean latency (ms)</th><th>2σ drift alarm</th></tr></thead><tbody>"
                + "".join(f"<tr><td>{html.escape(str(row['lane_id']))}</td>"
                          f"<td>{row['samples']}</td><td>{(row['success_rate'] * 100):.1f}%</td>"
                          f"<td>{row['mean_latency_ms']:.1f}</td><td>{'ALARM' if row['drift_alarm_2sigma'] else '—'}</td></tr>"
                          for row in (ctx.meter.snapshot() if ctx.meter else [])
                          if row['success_rate'] is not None and row['mean_latency_ms'] is not None)
                + "</tbody></table><h2>Redacted lane configuration</h2>"
                "<textarea id='lane-json' rows='16' cols='100' spellcheck='false'>" + editor_json + "</textarea><br>"
                "<button type='button' onclick='saveLanes()'>Save lane configuration</button>"
                "<p>Mutations use X-Ladder-UI: 1. Provider secrets are never accepted by the browser. "
                "Live probes require LADDER_LIVE=1.</p>"
                "<pre id='probe-output' aria-live='polite'></pre>"
                "<script>async function probeLane(id){const out=document.getElementById('probe-output');"
                "out.textContent='Probing '+id+'…';try{const r=await fetch('/setup/probe',{method:'POST',"
                "headers:{'Content-Type':'application/json','X-Ladder-UI':'1'},body:JSON.stringify({lane_id:id})});"
                "const data=await r.json();out.textContent=JSON.stringify(data,null,2);}catch(e){out.textContent=String(e);}}"
                "async function saveLanes(){const out=document.getElementById('probe-output');try{"
                "const lanes=JSON.parse(document.getElementById('lane-json').value);"
                "const r=await fetch('/setup/config',{method:'PUT',headers:{'Content-Type':'application/json',"
                "'X-Ladder-UI':'1'},body:JSON.stringify({lanes})});const data=await r.json();"
                "out.textContent=JSON.stringify(data,null,2);if(r.ok)location.reload();"
                "}catch(e){out.textContent=String(e);}}</script>"
                "</body></html>")
        return HTMLResponse(page)

    @app.post("/setup/probe")
    async def setup_probe(request: Request):
        """One explicit, isolated provider connectivity probe; never invokes the router."""
        if not ctx.settings.live_enabled:
            raise HTTPException(403, "live probes are disabled; set LADDER_LIVE=1 explicitly")
        if request.headers.get("x-ladder-ui") != "1":
            raise HTTPException(403, "missing X-Ladder-UI header")
        origin = request.headers.get("origin")
        if origin:
            from urllib.parse import urlparse
            parsed = urlparse(origin)
            if parsed.scheme not in ("http", "https") or parsed.hostname not in ("127.0.0.1", "localhost"):
                raise HTTPException(403, "cross-origin operator probe rejected")
        try:
            body = await _body(request)
        except IngressError as exc:
            raise HTTPException(status_code=exc.status_code, detail=str(exc))
        lane_id = str(body.get("lane_id", ""))[:128]
        lane = next((candidate for candidate in ctx.lanes if candidate.id == lane_id), None)
        if lane is None:
            raise HTTPException(404, "unknown or inactive lane")
        if lane.needs_key and (not lane.api_key_env or not os.environ.get(lane.api_key_env)):
            raise HTTPException(409, "lane credential is not configured")
        completion = ctx.completion
        if completion is None:
            try:
                import litellm
                completion = litellm.acompletion
            except ImportError:
                raise HTTPException(503, "LiteLLM is not installed")
        kwargs = {"model": lane.model, "messages": [{"role": "user", "content": "Reply with exactly LADDER_PROBE_OK."}],
                  "max_tokens": 16, "timeout": 8, "stream": False}
        if lane.api_key_env and os.environ.get(lane.api_key_env):
            kwargs["api_key"] = os.environ[lane.api_key_env]
        elif not lane.needs_key and lane.base_url:
            kwargs["api_key"] = LOCAL_PRESENCE_KEY
        if lane.base_url:
            kwargs["api_base"] = lane.base_url
        started = time.monotonic()
        run_id = uuid.uuid4().hex
        try:
            async with asyncio.timeout(8):
                pending = completion(**kwargs)
                response = await pending if inspect.isawaitable(pending) else pending
            result = extract_nonstreaming(response)
            passed = bool(result.finish_reason and (result.text or result.tool_calls))
            elapsed = int((time.monotonic() - started) * 1000)
            if ctx.ledger:
                ctx.ledger.append({"run_id": run_id, "request_id": run_id, "lane_id": lane.id,
                                   "attempt": 1, "class": "PROBE_OK" if passed else "PROBE_INCOMPLETE",
                                   "latency_ms": elapsed, "probe": True})
            return {"ok": passed, "lane_id": lane.id, "run_id": run_id, "latency_ms": elapsed,
                    "result": "provider returned a complete response" if passed else "provider response incomplete"}
        except Exception as exc:
            elapsed = int((time.monotonic() - started) * 1000)
            if ctx.ledger:
                ctx.ledger.append({"run_id": run_id, "request_id": run_id, "lane_id": lane.id,
                                   "attempt": 1, "class": "PROBE_ERROR",
                                   "latency_ms": elapsed, "error_type": type(exc).__name__, "probe": True})
            return JSONResponse(status_code=502, content={"ok": False, "lane_id": lane.id,
                                "run_id": run_id, "latency_ms": elapsed,
                                "error": type(exc).__name__})

    @app.put("/setup/config")
    async def setup_config(request: Request):
        if not ctx.settings.allow_setup_mutations:
            raise HTTPException(403, "setup mutations disabled")
        if request.headers.get("x-ladder-ui") != "1":
            raise HTTPException(403, "missing X-Ladder-UI header")
        origin = request.headers.get("origin")
        if origin:
            from urllib.parse import urlparse
            parsed = urlparse(origin)
            if parsed.scheme not in ("http", "https") or parsed.hostname not in ("127.0.0.1", "localhost"):
                raise HTTPException(403, "cross-origin operator mutation rejected")
        try:
            body = await _body(request)
            raw_lanes = body.get("lanes")
            if not isinstance(raw_lanes, list):
                raise IngressError("lanes must be an array")
            lanes: list[Lane] = []
            try:
                lanes = [lane_from_dict(item) for item in raw_lanes]
            except (ValueError, TypeError) as exc:
                raise IngressError(str(exc)) from exc
            if len({x.id for x in lanes}) != len(lanes):
                raise IngressError("lane IDs must be unique")
            save_lanes(ctx.settings, lanes)
            ctx.configured_lanes = lanes
            ctx.lanes = load_lanes(ctx.settings)
            return {"ok": True, "configured_lane_count": len(lanes), "active_lane_count": len(ctx.lanes)}
        except (IngressError, ValueError, TypeError) as exc:
            raise HTTPException(status_code=400, detail=str(exc))

    @app.get("/setup/metrics")
    async def setup_metrics():
        meter = ctx.meter or FingerprintMeter(ctx.settings.metrics_path)
        return {"lanes": meter.snapshot()}

    @app.get("/setup/ledger")
    async def setup_ledger():
        path = ctx.settings.ledger_path
        if not path.is_file():
            return {"events": []}
        lines = path.read_text(encoding="utf-8").splitlines()[-200:]
        events = []
        for line in lines:
            try:
                events.append(json.loads(line))
            except json.JSONDecodeError:
                continue
        return {"events": events}

    return app


app = create_app()
