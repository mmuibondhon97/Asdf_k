# VEIL v1.0.0 / Ladder Integration - Technical Audit Report

**Audit date:** 22 November 2026  
**Auditor role:** Independent engineering review / protocol integration / release QA  
**Disposition:** Proposed VEIL v1.0.0 rejected as a runnable release; VEIL-Safe diagnostic integration delivered as a constrained, tested alternative.  
**Evidence policy:** A claim is labelled observed only when a command or source inspection in this audit supports it. Test counts and hashes below are generated from this build, not copied from the proposed bundle's scorecard.

---

## 1. Executive disposition

The proposed VEIL v1.0.0 bundle is **not runnable as supplied** and is not safe to integrate as a refusal-routing service. Several declared Guard integration seams are contradicted by the supplied Guard v4.3.0 source. The bundle also contains independent fatal and logical defects: an import-time `TypeError`, a defective bundle unpacker, incorrect probe labels, a wrong-dimensional SVD selection, an unbounded auto-band evaluator, and runtime calls to functions absent from Guard.

The previous “12/12 static items” scorecard is not supported by the code. “Complete” source text is not equivalent to an importable package or a passing contract. Some stated test expectations are themselves wrong.

A separate VEIL-Safe implementation has been added to the supplied Ladder project. It retains useful diagnostic engineering: structured outcome signals, exact result-set gating, metadata-only evidence, a hash-chained audit log, and read-only file identification. It deliberately does not implement safety-policy bypass, refusal suppression, prompt pressure, safety-off settings, or model-weight abliteration. An explicit provider policy signal is preserved and returned without automatic provider switching.

**Release status:** Source and ambient test suite pass. Dependency integrity remains BLOCKED because generated hash lockfiles and the complete target wheelhouse are absent. Live provider, Docker, and coding-agent session acceptance remain unrun.

## 2. Inputs and source provenance

The audit used:

1. The user-supplied Ladder architecture specification (`Untitled document (1).txt`).
2. The uploaded `ladder-rebuilt-source-kit.zip` and its SHA-256 file.
3. The full Guard v4.2.1 bundle in `spark 1.txt` as historical reference.
4. The full Guard v4.3.0 bundle in `spark 2.txt` for exact integration-seam inspection.
5. The VEIL v1.0.0 bundle pasted in the user message.
6. The public `build_aio_source.py` in `https://github.com/mmuibondhon97/Asdf_k` to verify the Harvester patch target.

The uploaded Ladder source ZIP SHA-256 was recomputed as:

`d84b1efdfaf54dbae5963e19b088862e4a14382b6354ae48e77801fefd179aeb`

The checksum file matched and `unzip -t` reported no ZIP errors. The audit and test changes were made in a working copy; the original uploaded ZIP was not modified.

## 3. Source crosswalk: H1-H5

| ID | VEIL hypothesis | Audit result | Evidence and consequence |
|---|---|---|---|
| H1 | Guard v4.3.0 structure and public interfaces match the structural summary | **Partially contradicted** | The eight-plane Ladder concept and Guard package names are present, but the adapter contracts assumed by VEIL do not match Guard. The surgery pipeline has concrete, different signatures. A summary was not a substitute for source. |
| H2 | Guard battery has 25 stable IDs and `Probe.text` | **False** | `guard/battery.py` defines `Probe(pid, prompt, min_chars, avoid)` and IDs `p01`-`p25`. There is no `text` field. VEIL references `p.text` and invents `b01`-`b25`; its corpus/battery disjointness import therefore fails and its four-layer labels do not derive from Guard's battery. |
| H3 | Guard surgery exposes the assumed capture/ablate/score/pipeline/manifest API including residual capture and foreign-model battery calls | **False** | Actual `capture.py` exposes `_layer_list`, `target_matrices`, `collect_activations`, and `direction_from_means`. `pipeline.run` loads and evaluates a base model; it is not the VEIL `battery.run(model_path=...)` contract. No `capture.residual_diffs` or `_battery_seam` exists. `SurgeryManifest` exposes `improved` and `battery_met`; it does not expose VEIL's assumed `foreign_probe` contract. The extension would fail at runtime. |
| H4 | `unpack_veil.py` matches Guard marker/fence semantics | **False** | Guard's unpacker expects a pure-backtick fence; the emitted Guard bundle and the Guard tests use language-labelled fences such as ` ````python`. This makes two Guard unpacker tests fail. VEIL's own `unpack_veil.py` has a separate extraction-state bug: after the first opening fence it skips body lines until it sees another fence, so ordinary source text can be dropped; it also lacks robust resolved-root/symlink/atomic-write checks. Do not use either as a trusted package installer until corrected and regression-tested. |
| H5 | `patches/harvester.patch` applies to `build_aio_source.py` | **False** | The public source has `write_repo_markdown(...)` and `main()`, not `harvest(repo_list, args)`. The actual CLI exposes `--clone-dir`, `--out`, `--workers`, `--update`, `--submodules`, `--max-file-kb`, `--include-noise`, and `--split-dir`; the proposed `--manifest`, `--only`, and `--chunk` context is absent. The patch also refers to undefined `manifest_rows` and yields bytes where the existing writer builds strings. The patch must be redesigned against the real API, not applied as presented. |

The current public Harvester source shows the actual `write_repo_markdown` and `main` structure and CLI options. [Source](https://github.com/mmuibondhon97/Asdf_k/blob/main/build_aio_source.py) (accessed 22 November 2026).

## 4. Proposed VEIL source findings

### 4.1 Import and execution blockers

| ID | Severity | Finding | Impact |
|---|---|---|---|
| V-01 | Critical | `classify.py` includes `@dataclass_like := None` before `Attribution`. Python parses the assignment-expression decorator but evaluates it as a decorator and calls `None`. | Importing `veil.provenance.classify` raises `TypeError: 'NoneType' object is not callable`; the package cannot reach tests or runtime. |
| V-02 | Critical | `battery_texts()` reads `p.text`; Guard uses `Probe.prompt`. | H2 seam fails with `AttributeError`; disjointness test cannot execute. |
| V-03 | High | `BATTERY_LABELS` invents IDs `b01`-`b25` and causal layer assignments. | Labels do not match Guard's `p01`-`p25` IDs and are not justified by the Guard corpus. A per-layer gate can report coverage over an invented mapping. |
| V-04 | High | `test_flat_25_pass_with_one_layer_zero_fails` expects 19, but its own assignments yield 20 pass rows: client-injection has five labels (`b19`-`b23`), not six. | The test expectation is false and contradicts the defined map. |
| V-05 | High | `router.py` records clean responses with `Layer("PASS")`, but `PASS` is not a member of the `Layer` enum. | A clean completion can be emitted and then fail while trying to record it. |
| V-06 | High | `_pick_lane` returns `lane_override` without checking that the lane exists, is ready, is capability-compatible, or is enabled. | A missing/inactive override can raise or route to an invalid target. |
| V-07 | High | `policy.max_retries` is declared but not enforced as an independent per-class retry counter. | The fixed policy contract is not actually enforced; the global three-attempt loop can change semantics. |

### 4.2 Classification and false-positive risks

| ID | Severity | Finding | Impact |
|---|---|---|---|
| V-08 | Critical | Lexical phrases are treated as causal markers for provider filters, weight alignment and knowledge boundaries. | Phrasing is not evidence of the internal source. Quoted text, code blocks, user-provided strings, benign explanations and provider style can trigger false attribution. |
| V-09 | High | The 60 corpus entries are prompt designs intended to elicit a label, not a hand-labelled set of observed provider outputs with independently confirmed causes. | The corpus cannot calibrate causal attribution weights or establish precision/recall for four mechanisms. |
| V-10 | High | The score priors and 0.15 margin are hand-set; there is no calibration report or held-out response labelling. | A score or `margin_ok` flag is not a probability or validated confidence estimate. |
| V-11 | High | `is_refusal()` and `attribute()` use different thresholds. | A response can be called a refusal candidate while its attribution is `UNATTRIBUTED`; subsequent policies may still scrub/retry and modify the response despite no cause being established. |
| V-12 | High | `echoed_system` and cross-provider hedge similarity are not causal identification. | A prompt echoed in quoted or requested content does not prove client injection; a common hedge phrase across providers does not prove request contamination. |

### 4.3 Request steering and response mutation

| ID | Severity | Finding | Impact |
|---|---|---|---|
| V-13 | Critical | `PROVIDER_FILTER` automatically escalates to another provider; `WEIGHT_ALIGNMENT` escalates to abliteration; Gemini `BLOCK_NONE` is applied. | This routes around an explicit provider policy decision. It is excluded from VEIL-Safe. |
| V-14 | High | `sanitize.ingress()` copies a system message into a local variable but does not put the modified message back into the request's message list. | Its advertised mutation is not applied to `messages`. |
| V-15 | Critical | `strip_injected()` deletes every system message, not only a verified injected fragment. | Trusted application/system instructions are removed along with untrusted text. This is not a safe inference or sanitizer. |
| V-16 | Critical | `scrub.egress()` strips refusal/disclaimer wording. The exhausted path emits scrubbed text as best-effort output. | It suppresses refusal content and may change the provider's actual answer. This violates preservation of policy outcomes and response integrity. |
| V-17 | High | `logit_bias.py` describes a first-token-position bias but the submitted string-keyed map does not encode position. | A provider logit bias, where supported, applies to token IDs across generation, not just the first token position. String spellings are not portable token IDs. |
| V-18 | High | `GEMINI_BLOCK_NONE` uses `HARM_CATEGORY_DANGEROUS`, whereas the Guard config's category is `HARM_CATEGORY_DANGEROUS_CONTENT`; it omits the civic-integrity category present in Guard. | The declared category list is inconsistent with Guard and may be rejected or ignored by the provider. |

### 4.4 Surgery mathematics and REA defects

| ID | Severity | Finding | Impact |
|---|---|---|---|
| V-19 | Critical | `rank_k_auto_search()` performs SVD on `(n_probes, d)` but selects `u[:, i]`, a probe-space vector, then tests it against a feature-space text basis. | Dimensions are generally incompatible; where dimensions happen to match, the selected vector is still in the wrong space. The feature-space candidate should come from the right singular vectors (`Vh`) if this were a permitted offline research problem. No surgery code was retained in VEIL-Safe. |
| V-20 | High | `auto_band_search()` increments its counter in `try_w()` but calls `score_window()` directly outside that counter. | It can exceed `MAX_EVALS=24`; the stated evaluation bound is false. |
| V-21 | High | `multidir_pipeline()` calls `capture.residual_diffs`, absent from Guard, and can append two directions when only one slot remains under `k_max`. | Runtime failure plus possible limit overshoot. |
| V-22 | Critical | `probe_checkpoint()` calls `battery.run(model_path=ckpt)` and imports `._battery_seam.run_battery`; neither interface exists in Guard. | Foreign checkpoint probe cannot execute. |
| V-23 | High | The dry probe checks only file presence, not that a checkpoint and manifest are parseable, compatible or gated. | It is not a meaningful dry acceptance test. |
| V-24 | High | The REA `inject.session()` attaches Frida and writes `_veil_deadline`, but neither enforces the deadline nor guarantees detach. | The claimed 300-second bound and mandatory cleanup are not implemented. |
| V-25 | High | `capa.py` calls an MD5 hash of the first 0x400 bytes an `imphash`. | This is not a PE import hash; it mislabels a different digest and can mislead the analyst. |
| V-26 | High | `patch.apply()` writes to the original file path without a mandatory backup, original hash precondition or atomic replacement. | A mistaken plan can irreversibly alter the target; the plan does not itself verify expected original bytes. |
| V-27 | Medium | `disasm()` ignores its `arch` and `mode` arguments and hardcodes x86-64. `emu.py` imports Keystone but does not use it. | The module API promises support/behavior it does not implement. |
| V-28 | Medium | `scan.py` uses `/proc/<pid>/exe` as its POSIX degrade path. | Not portable to macOS; output directory is fixed and not isolated per run. |

### 4.5 Ledger and gate defects

The proposed plain JSONL `EvidenceLedger` has no permission hardening, no symlink protection, no atomicity guarantee, no integrity hash, and no process-level append synchronization. The gate permits duplicate/missing rows to affect counts, does not verify a single run ID, accepts truthy non-boolean `passed` values, and uses fabricated labels. The `GateReport` cannot be interpreted as a reliable evidence gate without these controls.

## 5. Guard v4.3.0 baseline execution

The Guard bundle was extracted from the user-supplied `spark 2.txt` and run in the current Python 3.13.5 environment. `python -m compileall -q .` passed. `python -m pytest -q` produced **six failures**:

1. Two hard-block detector cases expected `HARD_BLOCK` but returned `OK`:
   - “Doing so would violate my usage policies.”
   - “This exceeds my content guidelines, sorry!”
2. `test_deadline_respected`: a 0.3-second fake provider was allowed to return successfully despite a configured 0.05-second deadline.
3. `test_unpack_parses_4_backtick_bundle_with_inner_3_backticks`: parser rejected a labelled ` ````markdown` opener.
4. `test_unpack_marker_close_is_exact`: parser rejected a labelled ` ````text` opener.
5. `test_setup_page_has_valid_js_and_escapes_html`: assertion rejects `}}` in otherwise generated JavaScript object/arrow syntax; this is a brittle test oracle rather than proof of an injection flaw by itself.

Consequently Guard v4.3.0 cannot be treated as a green base. These failures were preserved in the audit report, not silently patched into the VEIL worktree. VEIL-Safe is built on the separate Ladder source kit.

## 6. Ladder integration changes

The delivered tree preserves the eight-plane Ladder topology and adds a separate VEIL-Safe package.

- P2's optional semantic judge is advisory only. It may add a diagnostic evidence item but cannot create `C2_PROVIDER_POLICY` from free-form prose.
- P4 no longer forwards `logit_bias` as a generic request parameter.
- VEIL observations are derived from the canonical turn graph and provider result. Tool-result text is not scanned as assistant prose.
- `PROVIDER_POLICY_SIGNAL` requires Ladder's explicit structured provider classification and is returned unchanged.
- The optional VEIL ledger stores response length and digest, not response text or raw prompts.
- The gate uses the repository's actual `P01`-`P25` synthetic structural fixtures; no invented `b01` IDs or four-layer causal labels are used. It rejects duplicate JSON keys, NaN/Infinity, invalid class types, unknown result fields, duplicate/missing/extra probes, non-boolean results and mixed run IDs.
- REA is limited to read-only file identification and SHA-256. No disassembly, emulation, patching, live process scanning, or injection is shipped.

## 7. Verification results for the delivered tree

**Environment:** CPython 3.13.5; preinstalled, unpinned environment. Commands run on 22 November 2026.

| Command/check | Observed result | Interpretation |
|---|---|---|
| `python manage.py test` | **134 passed** in 0.55s; run ID `b089905bba1748d8a642fa95afed83b3` | Source tests passed in this ambient environment. This is not a clean pinned install. |
| `python -m compileall -q ladder veil manage.py` | Exit 0 | Python files compile. |
| `python scripts/static_validate.py` | Exit 0; one workflow YAML parsed; shell blocks passed `bash -n`; action SHA format passed | Static workflow checks only. |
| `python -m veil --help` | Exit 0 | CLI imports and exposes expected commands. |
| `python -m veil check-corpus` | Exit 0; 25 rows; seven structural outcome labels plus `OK` | Corpus parses; no live model/provider test. |
| `make battery-preflight` | Exit 0; `PASS_PREFLIGHT`, 25 probes; run ID `e38ff6e9a96c4d688a0d98b66cf26507`; corpus SHA-256 `7db4e2ab18ef4bf592bfe8cf904a718a90703305dceccb1b6c4532045377d62f` | Synthetic presence-only lane; no network call, no real credentials, no model quality measurement. |
| `python manage.py integrity` | Exit 1; `requirements.lock` absent, three direct packages not represented in lock | **Dependency integrity blocked.** No hash-enforced installation was claimed. |
| `actionlint` | Unavailable | Not run. |
| Guard v4.3.0 `python -m pytest -q` | Six failures listed in Section 5 | Guard source is not a passing baseline. |

The Ladder source kit's original dependency preflight and network transcript record that the required PyPI and package-cache egress was unavailable in the build environment. No placeholder hashes were created. `requirements.lock` and `requirements-dev.lock` must be generated from the real target wheelhouse and then clean hash-enforced installs must pass.

## 8. Not run / not accepted

The following are not claimed:

- A complete pinned production/development dependency closure.
- `pip install --require-hashes` from generated lockfiles.
- Docker image build or container runtime acceptance.
- A real hosted provider request or credential validation.
- Claude Code or Codex CLI multi-turn tool workflow acceptance.
- Any live provider-model benchmark or refusal-rate result.
- 60-prompt causal attribution precision/recall.
- GPU/VRAM validation, model-weight experiment, or checkpoint score.
- A Windows-native or macOS REA test.
- Harvester patch application; the proposed patch was rejected because its context is absent.

## 9. Release recommendation

The supplied VEIL v1.0.0 bundle should not be released or merged as-is. The safe diagnostic rebuild is usable for source-level development and regression testing, but it is **not yet a dependency-verified release**. Complete the following on an internet-connected CPython 3.13 Linux x86_64 host:

1. Build the wheelhouse with `bash scripts/build-wheelhouse.sh wheelhouse`.
2. Package it with `bash scripts/package-wheelhouse.sh wheelhouse` and transfer the ZIP plus checksum.
3. On the target host, verify the transfer checksum and run `make verify-offline`.
4. Confirm generated lockfiles and clean `--require-hashes` production/development installs.
5. Start Docker only after hash-lock integrity passes, then test one real provider endpoint with secrets supplied locally.
6. Run a real Claude Code or Codex multi-turn task with fragmented tool-call streaming and inspect the run ledger. Provider policy outcomes must remain unchanged.

A release can be promoted only after the dependency gate and runtime acceptance are backed by actual run IDs and artifacts. The current test result is a **source test pass**, not a final deployment acceptance.

---

## Appendix A - Current test run ID

`b089905bba1748d8a642fa95afed83b3`

