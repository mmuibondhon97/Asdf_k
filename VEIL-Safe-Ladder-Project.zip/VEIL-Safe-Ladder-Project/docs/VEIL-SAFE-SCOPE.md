# VEIL-Safe 1.0.0 - Scope and Operational Contract

## Purpose

VEIL-Safe is the diagnostic and evidence layer shipped with this Ladder source tree. It provides protocol-grounded outcome observations, a strict evidence gate, a metadata-only hash-chained ledger, and bounded read-only file identification.

It is intentionally not the refusal-circumvention design in the proposed VEIL v1.0.0 bundle. It does not attempt to defeat provider policy, turn a provider refusal into a successful response, suppress refusal text, rewrite trusted system instructions, alter safety-related request parameters, or modify model weights.

## Components

| Component | Contract |
|---|---|
| `veil/provenance/features.py` | Extracts structural metadata from a canonical request graph and provider result. It stores response length and SHA-256, not response text. |
| `veil/provenance/classify.py` | Maps Ladder's existing structural outcome class to a diagnostic signal. It does not infer causal mechanisms from prose. |
| `veil/provenance/policy.py` | Returns a non-bypass operational action. Explicit provider policy signals are returned unchanged. |
| `veil/observe.py` | Builds the metadata payload attached to an attempt. |
| `veil/gate/gate.py` | Validates exact result coverage against the repository's real 25 synthetic protocol fixtures. Requires boolean outcomes and a run ID. |
| `veil/ledger/hashchain.py` | Stores allow-listed metadata in a SHA-256 chained JSONL file. It is tamper-evident, not tamper-proof. |
| `veil/rea/identify.py` | Read-only signature identification and hashing for common executable/container/document formats. No execution, patching, process inspection, or injection. |
| `veil/cli.py` | `check-corpus`, `evaluate`, `verify-ledger`, and `identify` commands. |

## Classification semantics

The signal names are diagnostic mappings of Ladder outcome classes, not claims about a model's internal causal mechanism:

- `COMPLETE`: Ladder classifies the provider result as complete.
- `PROVIDER_POLICY_SIGNAL`: explicit provider metadata or finish-reason indicates a provider policy decision. The provider's result is preserved; no route-around is attempted.
- `TRANSPORT_FAILURE`: structural transport failure.
- `INCOMPLETE_RESPONSE`: incomplete or malformed upstream response.
- `TOOL_CONTRACT_MISMATCH`: a request with an explicit mandatory tool contract was not satisfied.
- `EVIDENCE_LIMITATION`: a structured evidence envelope contains populated unknowns or limitations.
- `PROVIDER_CONFIGURATION`: authentication or provider configuration failure.
- `INVALID_REQUEST`: malformed or unsupported request.
- `UNDETERMINED`: no defensible structural signal is available.

A phrase such as “I cannot help”, “however”, “typically”, “as an AI”, or “it depends” is not sufficient evidence to assign a cause. A local language-model judge is advisory only and cannot manufacture a provider-policy outcome.

## Gate contract

The source corpus is `data/probes.jsonl`. Its IDs are `P01` through `P25`; each row is a synthetic protocol fixture with an expected structural outcome class. It is not a live provider benchmark, does not measure refusal rates, and does not establish a causal refusal taxonomy.

The evaluator rejects missing, duplicate, unexpected, malformed, non-boolean, missing-run-ID, and mixed-run-ID rows. A passing report requires exactly one passing result for every expected fixture in one run. Passing this gate proves only that the submitted result set matches the declared fixture outcomes; it is not provider capability evidence.

## Ledger contract

Set `VEIL_AUDIT_LEDGER` to enable the optional ledger. The ledger accepts a strict metadata allow-list and refuses raw prompts, raw response text, arbitrary nested objects, and unknown fields. It stores a response digest and metadata only.

The SHA-256 chain detects edits, deletions, reordered entries, and malformed rows unless an actor rewrites and recomputes the entire chain. It is therefore tamper-evident, not tamper-proof. The process lock is local to one Python process; run the service as one worker when using this ledger. Do not have independent processes append to the same file. On POSIX, the file is set to mode `0600`; a newly created ledger directory is set to `0700`. Existing parent-directory permissions are not changed.

If the configured ledger cannot be written, the request fails closed with an evidence-ledger error rather than silently losing the audit event.

## Read-only REA boundary

`python -m veil identify FILE` inspects file signatures and computes SHA-256. The current function does not parse all headers, disassemble code, emulate code, patch files, attach to a process, scan process memory, or inject/hook a process. It rejects symlinks and non-regular files and enforces a file-size bound.

## Deliberate exclusions

The original proposed bundle included provider-policy circumvention, safety-off provider parameters, refusal-onset logit bias, refusal/disclaimer scrubbing, forced answer-prefills, removal of all system messages, refusal-weight ablation, multi-directional surgery, executable patching and process injection. Those are not included in VEIL-Safe. The exclusion is deliberate and reflected in tests and operational policy: an explicit provider policy decision is not automatically retried on another lane or transformed into a compliant response.

## Run commands

From the repository root:

```bash
python -m veil check-corpus
python -m veil evaluate results.jsonl --run-id RUN_ID
python -m veil verify-ledger ~/.ladder/veil-audit.jsonl
python -m veil identify ./sample.bin
```

The service-side ledger is opt-in:

```dotenv
VEIL_AUDIT_LEDGER=~/.ladder/veil-audit.jsonl
```

Restart the single-worker Ladder service after changing environment configuration.
