# VEIL-Safe / Ladder build status

**Build date:** 22 November 2026
**Build status:** SOURCE-TESTED / DEPENDENCY-INTEGRITY BLOCKED
**Python:** CPython 3.13.5 (ambient, preinstalled and not dependency-pinned)

## Verified in this environment

- `python manage.py test`: 134 passed, 0.55 s, run ID `b089905bba1748d8a642fa95afed83b3`.
- `python -m compileall -q ladder veil manage.py`: exit 0.
- `python scripts/static_validate.py`: YAML parse, workflow shell `bash -n`, and action SHA format checks passed. `actionlint` was not installed.
- `python -m veil --help`: exit 0.
- `python -m veil check-corpus`: 25 source fixtures parsed; seven structural classes plus OK.
- `make battery-preflight`: PASS_PREFLIGHT, 25 synthetic fixtures, run ID `e38ff6e9a96c4d688a0d98b66cf26507`, corpus SHA-256 `7db4e2ab18ef4bf592bfe8cf904a718a90703305dceccb1b6c4532045377d62f`. This uses a presence-only dummy lane and makes no network/provider call.
- Source ZIP input checksum was independently recomputed and matched its supplied sidecar; ZIP integrity passed before rebuild.

## Still blocked or not run

- `python manage.py integrity` is BLOCKED: generated `requirements.lock` and `requirements-dev.lock` are absent because real target wheel artifacts could not be fetched in this environment.
- No hashes were fabricated. No clean `--require-hashes` install has been completed.
- No Docker image build/runtime, real provider/API-key call, Claude Code/Codex live session, or GPU/model-weight experiment was run.
- No live refusal-rate, causal attribution, or model-quality score is claimed.
- Guard v4.3.0 baseline has six test failures in its own suite; see `docs/VEIL-REBUILD-AUDIT.md`.

## Product boundary

VEIL-Safe is the policy-preserving diagnostic extension. It preserves explicit provider policy outcomes. It does not implement the proposed provider-policy bypass, refusal suppression, prompt steering, safety-off settings, refusal-token bias, model-weight ablation, executable patching, process scanning, or injection.

The source package is ready for source review and local regression work. It must not be represented as a fully dependency-verified production release until the wheelhouse build, generated locks, clean locked installs, and runtime acceptance pass.
