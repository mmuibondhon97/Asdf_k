# Ladder source rebuild and audit report

Date: 2026-11-21

## Project identity and scope

The source project is `ladder`, not the previously discussed LiteLLM Gateway.
The supplied `guard` v4.2.1 and v4.3.0 bundles were treated as reference-only
material. The maintained project is built around the eight-plane P0–P7
protocol architecture and the corrected follow-up specification preserved in
the supplied text file.

The implementation is limited to local protocol reliability and transparent
agent-tool interoperability. It preserves provider policy/refusal decisions;
it does not implement safety circumvention, refusal suppression, prompt
pressure, safety-off provider parameters, Heretic ablation or weight surgery.
External adapters can only be recorded as disabled pending independent
validation; Ladder does not create or modify model weights.

## Code and test changes in this rebuild

- Retained the eight-plane ingress, normalization, classification,
  disposition, lane, reconstruction, metering and operator modules.
- Hardened OpenAI and Anthropic tool-call normalization to require bounded
  identifiers and JSON object arguments.
- Hardened stream and non-stream tool-call reconstruction: bounded indexes,
  function-only calls, JSON object argument validation, size limits, and
  fail-closed handling of malformed/incomplete tool calls.
- Preserved tool-execution error status in-band instead of sending a
  non-standard OpenAI `is_error` message property.
- Added a presence-only `sk-local` API key marker for keyless local
  OpenAI-compatible servers where the LiteLLM adapter requires an `api_key`
  argument to be present.
- Forwarded supported sampling and response options, including
  `max_completion_tokens`, `top_k`, penalties, `parallel_tool_calls` and
  stream usage options.
- Ensured `tool_choice=none` neither requires tool-capable lanes nor forwards
  unused tool schemas.
- Made cold-start lane ordering deterministic by configured order; cost is
  not a substitute for measurements.
- Added regression tests for the protocol and configuration edge cases.
- Replaced GitHub-first dependency instructions with a no-GitHub,
  two-phase wheelhouse transfer workflow. Added a wheelhouse packaging script.

## Current source-only verification

- `python -m pytest -q`: 112 passed on CPython 3.13.5 in the ambient,
  unpinned environment.
- Python compilation: PASS.
- Shell syntax checks: PASS.
- YAML parse and workflow shell syntax: PASS.
- Action SHA format/static controls: PASS; `actionlint` unavailable locally.
- Dry battery: PASS with a presence-only synthetic lane; no network call.
- Full offline release gate: correctly blocked (exit 2) because the actual
  target wheelhouse and `MANIFEST.sha256` were not supplied to this runtime.

## Release gate remaining

No generated pip locks, clean pinned installs, pinned integrity run, pinned
suite run, Docker build, live provider request or real agent session is claimed.
The final release can be emitted only after a real CPython 3.13 Linux x86_64
wheelhouse is downloaded, manifested, transferred and passed through
`make verify-offline`. No GitHub account, repository or Actions execution is
required for this process.


## VEIL-Safe integration update - 2026-11-22

The pasted VEIL v1.0.0 bundle was audited against the full supplied Guard v4.3.0 source. The declared battery, surgery, unpacker and Harvester seams were reconciled; H2, H3, H4 and H5 were disproved as written. A full findings ledger is in `docs/VEIL-REBUILD-AUDIT.md`.

Added `veil/` as a safe diagnostic extension: structural outcome mapping, exact result-set gate against the actual P01-P25 repository fixtures, optional metadata-only hash-chain evidence, and read-only file identification. The extension does not infer causal refusal layers from phrases, bypass provider policy, strip refusals or system prompts, set safety-off parameters, bias refusal tokens, or perform model-weight surgery / process injection.

The Ladder classifier's local semantic judge is advisory and cannot create C2 provider-policy status from prose. The lane parameter forwarder does not forward generic `logit_bias`. Provider policy decisions remain unchanged and are not automatically rerouted.

Latest source verification on CPython 3.13.5 (22 November 2026): `python manage.py test` passed **134 tests** (run ID `b089905bba1748d8a642fa95afed83b3`); `compileall`, workflow YAML/shell validation, VEIL CLI import, 25-row corpus check and synthetic presence-only battery preflight passed. `python manage.py integrity` remains blocked because real wheelhouse artifacts and generated hash locks are not present. No live provider, Docker, full locked install, or real agent session is claimed.


### Final gate hardening and latest rerun - 2026-11-22

The VEIL result evaluator and corpus loader now use strict JSON parsing: duplicate object keys and non-standard numeric constants are rejected; probe/result fields and label types are validated. Added regressions for duplicate JSON keys, `NaN`, malformed classes and unknown result fields. Latest `python manage.py test`: **134 passed** (run ID `b089905bba1748d8a642fa95afed83b3`, CPython 3.13.5, 0.55 s). Latest `make battery-preflight`: `PASS_PREFLIGHT` (run ID `e38ff6e9a96c4d688a0d98b66cf26507`, 25 synthetic fixtures, no network). `python manage.py integrity` exited 1, as expected, because hash lock generation is still blocked by the unavailable real wheel artifacts.
