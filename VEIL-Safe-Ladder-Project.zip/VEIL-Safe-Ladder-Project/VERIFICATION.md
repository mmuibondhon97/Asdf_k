# Verification status - VEIL-Safe 1.0.0

**Verification date:** 2026-11-22  
**Runtime:** CPython 3.13.5, current preinstalled environment (not a clean pinned install).

## Observed passing checks

| Check | Result | Run evidence |
|---|---|---|
| `python manage.py test` | PASS - 134 tests | run_id `b089905bba1748d8a642fa95afed83b3`; exit 0; 0.55s |
| `python -m compileall -q ladder veil manage.py` | PASS | exit 0 |
| `python scripts/static_validate.py` | PASS | 1 workflow YAML parsed; all embedded shell blocks passed `bash -n`; full action-SHA format check passed |
| `python -m veil --help` | PASS | exit 0 |
| `python -m veil check-corpus` | PASS | 25 source fixtures parsed; 7 structural class labels plus `OK` |
| `make battery-preflight` | PASS_PREFLIGHT | run_id `e38ff6e9a96c4d688a0d98b66cf26507`; corpus hash `7db4e2ab18ef4bf592bfe8cf904a718a90703305dceccb1b6c4532045377d62f`; presence-only fake lane; no network call |
| ZIP/checksum | PASS | source archive SHA-256 recorded in the release checksum file |

The run ID above identifies the latest explicit `manage.py test` run. The 25-probe preflight has its own run ID; it is synthetic presence-only evidence, not a provider battery.

## Explicitly blocked or not run

| Check | Status | Reason |
|---|---|---|
| `python manage.py integrity` | BLOCKED / expected nonzero | `requirements.lock` and `requirements-dev.lock` have not been generated from real wheel artifacts. |
| Clean production/dev `--require-hashes` install | NOT RUN | Requires complete real wheelhouse and generated locks. |
| `actionlint` | UNAVAILABLE | Binary not installed in this execution environment. The project static checker validates YAML, embedded shell syntax and action SHA formatting, but this is not a substitute for actionlint. |
| Live provider calls / real API credentials | NOT RUN | No provider credentials were supplied and no network model request was made. |
| Docker image build/runtime | NOT RUN | Not available as a verified execution target in this run. |
| Claude Code / Codex end-to-end session | NOT RUN | Requires operator client, local runtime and provider connection. |
| Live model capability battery / classifier precision-recall | NOT RUN | Synthetic preflight is not a model benchmark. |
| GPU, VRAM or model-weight tests | NOT RUN | No weights were loaded or modified. |

## Guard v4.3.0 comparison

The supplied Guard v4.3.0 source was separately compiled successfully, but its own test suite produced six failures in this environment. Details are in `docs/VEIL-REBUILD-AUDIT.md`. Guard v4.3.0 is therefore not treated as a passing integration base.

## Release gate

This is a **source-tested preflight package**, not a dependency-verified production release. Generate the wheelhouse on an internet-connected CPython 3.13 Linux x86_64 host, transfer it with its checksum, then run `make verify-offline`. Promote the release only when the script completes clean hash-enforced installs, tests, integrity checks and final package creation.
