"""Small single-user append-only, hash-chained evidence ledger.

Only a strict allow-list of metadata is accepted. Raw prompts, raw responses,
credentials, and arbitrary nested payloads are rejected. The chain is
TAMPER-EVIDENT, not tamper-proof: an attacker able to rewrite the whole file
can recompute it. POSIX file permissions are set to 0600; directory mode is
0700 when the directory is first created.
"""
from __future__ import annotations

import hashlib
import hmac
import json
import os
import stat
import threading
import time
import uuid
from dataclasses import dataclass
from pathlib import Path
from typing import Any, Mapping

_ZERO = "0" * 64
_ALLOWED = {
    "classification", "signal", "lane_id", "attempt", "latency_ms",
    "response_chars", "response_sha256", "tool_call_count",
    "returned_tool_names", "required_tool_names", "provider_finish_reason",
    "provider_refusal_present", "attribution",
}
_LOCK = threading.Lock()


def _unique_object(pairs):
    result = {}
    for key, value in pairs:
        if key in result:
            raise ValueError(f"duplicate JSON key: {key}")
        result[key] = value
    return result


def _canonical(obj: dict[str, Any]) -> bytes:
    return json.dumps(obj, sort_keys=True, separators=(",", ":"),
                      ensure_ascii=True, allow_nan=False).encode("utf-8")


@dataclass(frozen=True)
class LedgerVerification:
    ok: bool
    entries: int
    last_hash: str
    error: str | None = None

    def as_dict(self) -> dict:
        return {"ok": self.ok, "entries": self.entries,
                "last_hash": self.last_hash, "error": self.error}


class HashChainLedger:
    def __init__(self, path: str | Path):
        self.path = Path(path).expanduser()

    @staticmethod
    def _validate_event(event: Mapping[str, Any]) -> dict[str, Any]:
        if not isinstance(event, Mapping):
            raise TypeError("ledger event must be a mapping")
        if any(not isinstance(key, str) for key in event):
            raise ValueError("ledger event keys must be strings")
        unknown = set(event) - _ALLOWED
        if unknown:
            raise ValueError(f"ledger event contains disallowed field(s): {sorted(unknown)}")
        clean: dict[str, Any] = {}
        for key, value in event.items():
            if key in {"attempt", "latency_ms", "response_chars", "tool_call_count"}:
                if type(value) is not int or value < 0:
                    raise ValueError(f"{key} must be a non-negative integer")
            elif key == "response_sha256":
                if value is not None and (not isinstance(value, str) or len(value) != 64
                                          or value != value.lower()
                                          or any(c not in "0123456789abcdef" for c in value)):
                    raise ValueError("response_sha256 must be a lowercase SHA-256 hex digest or null")
            elif key in {"provider_refusal_present"}:
                if type(value) is not bool:
                    raise ValueError(f"{key} must be a boolean")
            elif key in {"returned_tool_names", "required_tool_names"}:
                if not isinstance(value, (list, tuple)) or not all(isinstance(x, str) and len(x) <= 128 for x in value):
                    raise ValueError(f"{key} must be a string array")
                value = list(value)
            elif value is not None and (not isinstance(value, str) or len(value) > 256):
                raise ValueError(f"{key} must be a short string or null")
            clean[key] = value
        return clean

    @staticmethod
    def _verify_bytes(raw: bytes) -> LedgerVerification:
        prev = _ZERO
        count = 0
        if not raw:
            return LedgerVerification(True, 0, prev)
        for line_no, line in enumerate(raw.splitlines(), 1):
            if not line:
                return LedgerVerification(False, count, prev, f"blank line at {line_no}")
            try:
                row = json.loads(
                    line,
                    object_pairs_hook=_unique_object,
                    parse_constant=lambda value: (_ for _ in ()).throw(ValueError(f"invalid numeric constant {value}")),
                )
            except (json.JSONDecodeError, ValueError):
                return LedgerVerification(False, count, prev, f"invalid or non-canonical JSON at line {line_no}")
            if not isinstance(row, dict):
                return LedgerVerification(False, count, prev, f"non-object row at {line_no}")
            claimed = row.pop("hash", None)
            sequence = row.get("sequence")
            previous_hash = row.get("previous_hash")
            run_id = row.get("run_id")
            timestamp = row.get("timestamp_unix")
            event_id = row.get("event_id")
            allowed_row_keys = {"sequence", "run_id", "event_id", "timestamp_unix", "previous_hash"} | _ALLOWED
            if (type(sequence) is not int or sequence != count + 1
                    or previous_hash != prev
                    or not isinstance(run_id, str) or not run_id or len(run_id) > 128
                    or not isinstance(event_id, str) or not event_id
                    or type(timestamp) not in (int, float)
                    or not __import__("math").isfinite(timestamp)
                    or set(row) - allowed_row_keys):
                return LedgerVerification(False, count, prev, f"row schema/sequence mismatch at line {line_no}")
            actual = hashlib.sha256(_canonical(row)).hexdigest()
            if not isinstance(claimed, str) or not hmac.compare_digest(claimed, actual):
                return LedgerVerification(False, count, prev, f"hash mismatch at line {line_no}")
            prev = actual
            count += 1
        return LedgerVerification(True, count, prev)

    def verify(self) -> LedgerVerification:
        if self.path.is_symlink():
            return LedgerVerification(False, 0, _ZERO, "ledger path is a symlink")
        if not self.path.exists():
            return LedgerVerification(True, 0, _ZERO)
        try:
            fd = os.open(self.path, os.O_RDONLY | getattr(os, "O_NOFOLLOW", 0))
            try:
                info = os.fstat(fd)
                if not stat.S_ISREG(info.st_mode):
                    return LedgerVerification(False, 0, _ZERO, "ledger path is not a regular file")
                chunks = []
                while True:
                    chunk = os.read(fd, 1024 * 1024)
                    if not chunk:
                        break
                    chunks.append(chunk)
                return self._verify_bytes(b"".join(chunks))
            finally:
                os.close(fd)
        except OSError as exc:
            return LedgerVerification(False, 0, _ZERO, f"ledger read failed: {type(exc).__name__}")

    def append(self, run_id: str, event: Mapping[str, Any]) -> dict:
        if not isinstance(run_id, str) or not run_id.strip() or len(run_id) > 128:
            raise ValueError("run_id is required and must be at most 128 characters")
        clean = self._validate_event(event)
        parent_existed = self.path.parent.exists()
        self.path.parent.mkdir(parents=True, exist_ok=True, mode=0o700)
        # Do not chmod an existing user-selected directory: it may be shared.
        if os.name == "posix" and not parent_existed:
            try:
                os.chmod(self.path.parent, 0o700)
            except OSError:
                pass
        flags = os.O_RDWR | os.O_APPEND | os.O_CREAT
        if hasattr(os, "O_NOFOLLOW"):
            flags |= os.O_NOFOLLOW
        with _LOCK:
            if self.path.is_symlink():
                raise OSError("refusing to append through a ledger symlink")
            fd = os.open(self.path, flags, 0o600)
            try:
                info = os.fstat(fd)
                if not stat.S_ISREG(info.st_mode):
                    raise OSError("ledger path is not a regular file")
                if hasattr(os, "fchmod"):
                    os.fchmod(fd, 0o600)
                # Verify through the same descriptor used for append. This
                # avoids reopening a path that could be swapped after O_NOFOLLOW.
                existing_parts = []
                os.lseek(fd, 0, os.SEEK_SET)
                remaining = info.st_size
                while remaining:
                    chunk = os.read(fd, min(1024 * 1024, remaining))
                    if not chunk:
                        raise OSError("ledger shortened while it was being verified")
                    existing_parts.append(chunk)
                    remaining -= len(chunk)
                existing = b"".join(existing_parts)
                check = self._verify_bytes(existing)
                if not check.ok:
                    raise OSError(f"refusing to append to corrupt ledger: {check.error}")
                row = {
                    "sequence": check.entries + 1,
                    "run_id": run_id,
                    "event_id": uuid.uuid4().hex,
                    "timestamp_unix": time.time(),
                    "previous_hash": check.last_hash,
                    **clean,
                }
                digest = hashlib.sha256(_canonical(row)).hexdigest()
                stored = dict(row, hash=digest)
                payload = _canonical(stored) + b"\n"
                offset = 0
                while offset < len(payload):
                    written = os.write(fd, payload[offset:])
                    if written <= 0:
                        raise OSError("short ledger write")
                    offset += written
                os.fsync(fd)
                return stored
            finally:
                os.close(fd)
