"""Bounded, read-only PE/ELF/Mach-O/file identification.

The file is opened read-only; symlinks and non-regular files are rejected.
This module never executes, patches, emulates, attaches to, or injects into a
process. It returns format metadata and a SHA-256 hash only.
"""
from __future__ import annotations

import hashlib
import os
import stat
import struct
from pathlib import Path

MAX_FILE_BYTES = 2 * 1024 * 1024 * 1024


def _pe_fields(head: bytes, file_size: int) -> dict:
    if len(head) < 0x40:
        return {"format": "PE", "valid_header": False, "reason": "short DOS header"}
    pe_offset = struct.unpack_from("<I", head, 0x3C)[0]
    if pe_offset > min(file_size - 24, 16 * 1024 * 1024):
        return {"format": "PE", "valid_header": False, "reason": "PE header offset outside bounded file region"}
    local = head
    if len(local) < pe_offset + 24:
        return {"format": "PE", "valid_header": False, "reason": "PE signature/header not present in bounded prefix"}
    if local[pe_offset:pe_offset + 4] != b"PE\x00\x00":
        return {"format": "DOS_MZ_OR_UNKNOWN", "valid_header": False, "reason": "missing PE signature"}
    machine, sections = struct.unpack_from("<HH", local, pe_offset + 4)
    return {"format": "PE", "valid_header": True,
            "machine": f"0x{machine:04x}", "section_count": sections}


def identify_file(path: str | Path, *, max_bytes: int = MAX_FILE_BYTES) -> dict:
    if type(max_bytes) is not int or max_bytes < 1:
        raise ValueError("max_bytes must be a positive integer")
    target = Path(path).expanduser()
    if target.is_symlink():
        raise ValueError("refusing to inspect a symlink")
    fd = os.open(target, os.O_RDONLY | getattr(os, "O_NOFOLLOW", 0))
    try:
        info = os.fstat(fd)
        if not stat.S_ISREG(info.st_mode):
            raise ValueError("target is not a regular file")
        if info.st_size > max_bytes:
            raise ValueError(f"file exceeds configured inspection limit ({max_bytes} bytes)")
        head = os.read(fd, 16 * 1024 * 1024)
        os.lseek(fd, 0, os.SEEK_SET)
        digest = hashlib.sha256()
        while True:
            chunk = os.read(fd, 1024 * 1024)
            if not chunk:
                break
            digest.update(chunk)
    finally:
        os.close(fd)

    if head.startswith(b"MZ"):
        details = _pe_fields(head, info.st_size)
    elif head.startswith(b"\x7fELF"):
        details = {"format": "ELF", "class_bits": 64 if len(head) > 4 and head[4] == 2 else 32 if len(head) > 4 and head[4] == 1 else None}
    elif head[:4] in (b"\xfe\xed\xfa\xce", b"\xce\xfa\xed\xfe", b"\xfe\xed\xfa\xcf", b"\xcf\xfa\xed\xfe", b"\xca\xfe\xba\xbe"):
        details = {"format": "MACH_O_OR_FAT"}
    elif head.startswith(b"PK\x03\x04"):
        details = {"format": "ZIP"}
    elif head.startswith(b"%PDF-"):
        details = {"format": "PDF"}
    else:
        details = {"format": "UNKNOWN"}
    return {"path": str(target.resolve()), "size_bytes": info.st_size,
            "sha256": digest.hexdigest(), **details, "read_only": True}
