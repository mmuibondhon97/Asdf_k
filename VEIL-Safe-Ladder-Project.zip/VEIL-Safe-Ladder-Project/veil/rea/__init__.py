"""Read-only binary identification. No patching, execution, or injection."""
from .identify import identify_file

__all__ = ["identify_file"]
