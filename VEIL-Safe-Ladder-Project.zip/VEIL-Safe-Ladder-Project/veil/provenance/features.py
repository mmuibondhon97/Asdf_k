"""Extract only protocol-structural features from a Ladder result.

The response text is never stored here. A SHA-256 digest is retained to let
operators correlate repeated content without exposing the content itself.
No lexical search is performed: phrases such as "I can't", "however", or
"typically" are not reliable evidence of a refusal's cause.
"""
from __future__ import annotations

import hashlib
from dataclasses import asdict, dataclass

from ladder.types import CanonicalTurnGraph, ProviderResult


@dataclass(frozen=True)
class StructuralFeatures:
    finish_reason: str | None
    stream_complete: bool
    provider_refusal_present: bool
    response_chars: int
    response_sha256: str | None
    tool_call_count: int
    returned_tool_names: tuple[str, ...]
    required_tool_names: tuple[str, ...]
    available_tool_names: tuple[str, ...]

    def as_dict(self) -> dict:
        result = asdict(self)
        for key in ("returned_tool_names", "required_tool_names", "available_tool_names"):
            result[key] = list(result[key])
        return result


def extract(graph: CanonicalTurnGraph, result: ProviderResult) -> StructuralFeatures:
    text = result.text if isinstance(result.text, str) else ""
    digest = hashlib.sha256(text.encode("utf-8")).hexdigest() if text else None
    returned = tuple(sorted({call.name for call in result.tool_calls if call.name}))
    contract = graph.tool_contract
    required = set(contract.required_names)
    if contract.required_name:
        required.add(contract.required_name)
    return StructuralFeatures(
        finish_reason=result.finish_reason,
        stream_complete=bool(result.stream_complete),
        provider_refusal_present=bool(result.provider_refusal) or result.finish_reason in {"content_filter", "safety"},
        response_chars=len(text),
        response_sha256=digest,
        tool_call_count=len(result.tool_calls),
        returned_tool_names=returned,
        required_tool_names=tuple(sorted(required)),
        available_tool_names=tuple(sorted(set(contract.available_tools))),
    )
