"""Map existing structural Ladder classes to observational signals.

Important: these are outcome labels, not causal claims. Weight alignment,
knowledge gaps, and client-side injection cannot be distinguished from
ordinary prose using lexical markers. They remain NOT_ESTABLISHED unless
independent, controlled evidence is supplied by an operator.
"""
from __future__ import annotations

from dataclasses import asdict, dataclass
from enum import Enum

from ladder.types import Classification, OutcomeClass
from .features import StructuralFeatures


class Signal(str, Enum):
    COMPLETE = "COMPLETE"
    PROVIDER_POLICY_SIGNAL = "PROVIDER_POLICY_SIGNAL"
    TRANSPORT_FAILURE = "TRANSPORT_FAILURE"
    INCOMPLETE_RESPONSE = "INCOMPLETE_RESPONSE"
    TOOL_CONTRACT_MISMATCH = "TOOL_CONTRACT_MISMATCH"
    EVIDENCE_LIMITATION = "EVIDENCE_LIMITATION"
    PROVIDER_CONFIGURATION = "PROVIDER_CONFIGURATION"
    INVALID_REQUEST = "INVALID_REQUEST"
    UNDETERMINED = "UNDETERMINED"


@dataclass(frozen=True)
class Observation:
    signal: Signal
    source_class: str
    attribution: str
    provider_policy_preserved: bool
    features: StructuralFeatures

    def as_dict(self) -> dict:
        data = asdict(self)
        data["signal"] = self.signal.value
        data["features"] = self.features.as_dict()
        return data


_MAP = {
    OutcomeClass.OK: Signal.COMPLETE,
    OutcomeClass.C1_TRANSPORT: Signal.TRANSPORT_FAILURE,
    OutcomeClass.C2_PROVIDER_POLICY: Signal.PROVIDER_POLICY_SIGNAL,
    OutcomeClass.C3_INCOMPLETE: Signal.INCOMPLETE_RESPONSE,
    OutcomeClass.C4_CAPABILITY: Signal.TOOL_CONTRACT_MISMATCH,
    OutcomeClass.C5_EVIDENCE: Signal.EVIDENCE_LIMITATION,
    OutcomeClass.C6_PROVIDER_CONFIG: Signal.PROVIDER_CONFIGURATION,
    OutcomeClass.C7_INVALID_REQUEST: Signal.INVALID_REQUEST,
}


def classify(classification: Classification, features: StructuralFeatures) -> Observation:
    """Return an observation without changing or suppressing the response.

    `PROVIDER_POLICY_SIGNAL` is emitted only when Ladder has already received
    an explicit structured provider signal. This function does not inspect
    response prose and does not classify text-only refusals.
    """
    signal = _MAP.get(classification.category, Signal.UNDETERMINED)
    if signal is Signal.PROVIDER_POLICY_SIGNAL and not (
        features.provider_refusal_present or features.finish_reason in {"content_filter", "safety"}
    ):
        # A semantic/judge-only label is not sufficient to claim a provider
        # policy event. Keep the outcome conservative and non-causal.
        signal = Signal.UNDETERMINED
    return Observation(
        signal=signal,
        source_class=classification.category.value,
        attribution="STRUCTURAL_SIGNAL_ONLY" if signal is not Signal.UNDETERMINED else "NOT_ESTABLISHED",
        provider_policy_preserved=(signal is Signal.PROVIDER_POLICY_SIGNAL),
        features=features,
    )
