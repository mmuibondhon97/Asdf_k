"""Non-bypass handling rules for observed outcomes.

This module documents/returns operational handling only. It never converts a
provider policy signal into a lane escalation, prompt rewrite, refusal scrub,
or model-weight operation.
"""
from __future__ import annotations

from dataclasses import dataclass
from enum import Enum

from .classify import Signal


class SafeAction(str, Enum):
    RETURN_UNCHANGED = "RETURN_UNCHANGED"
    RETRY_SAME_LANE_ONCE = "RETRY_SAME_LANE_ONCE"
    TRY_CAPABILITY_COMPATIBLE_LANE = "TRY_CAPABILITY_COMPATIBLE_LANE"
    RETURN_EVIDENCE_LIMITATION = "RETURN_EVIDENCE_LIMITATION"
    STOP_CONFIGURATION = "STOP_CONFIGURATION"
    STOP_INVALID_REQUEST = "STOP_INVALID_REQUEST"
    RETURN_INCOMPLETE_ERROR = "RETURN_INCOMPLETE_ERROR"
    NO_CAUSAL_INFERENCE = "NO_CAUSAL_INFERENCE"


@dataclass(frozen=True)
class SafeDisposition:
    action: SafeAction
    retry_allowed: bool
    note: str


def disposition(signal: Signal, same_lane_retries: int = 0) -> SafeDisposition:
    if same_lane_retries < 0:
        raise ValueError("same_lane_retries cannot be negative")
    if signal is Signal.COMPLETE:
        return SafeDisposition(SafeAction.RETURN_UNCHANGED, False, "return complete response unchanged")
    if signal is Signal.PROVIDER_POLICY_SIGNAL:
        return SafeDisposition(SafeAction.RETURN_UNCHANGED, False,
                               "preserve the provider policy response; do not reroute to override it")
    if signal is Signal.TRANSPORT_FAILURE:
        return (SafeDisposition(SafeAction.RETRY_SAME_LANE_ONCE, True, "one bounded same-lane transport retry")
                if same_lane_retries == 0 else
                SafeDisposition(SafeAction.NO_CAUSAL_INFERENCE, False, "transport retry exhausted"))
    if signal is Signal.INCOMPLETE_RESPONSE:
        return (SafeDisposition(SafeAction.RETRY_SAME_LANE_ONCE, True, "one bounded retry before any response is committed")
                if same_lane_retries == 0 else
                SafeDisposition(SafeAction.RETURN_INCOMPLETE_ERROR, False, "incomplete response; never synthesize completion"))
    if signal is Signal.TOOL_CONTRACT_MISMATCH:
        return SafeDisposition(SafeAction.TRY_CAPABILITY_COMPATIBLE_LANE, False,
                               "a lane change is permitted only for an explicit tool/capability contract")
    if signal is Signal.EVIDENCE_LIMITATION:
        return SafeDisposition(SafeAction.RETURN_EVIDENCE_LIMITATION, False,
                               "preserve populated unknowns and limitations")
    if signal is Signal.PROVIDER_CONFIGURATION:
        return SafeDisposition(SafeAction.STOP_CONFIGURATION, False,
                               "fix credentials or provider configuration; do not retry blindly")
    if signal is Signal.INVALID_REQUEST:
        return SafeDisposition(SafeAction.STOP_INVALID_REQUEST, False,
                               "return the request error; do not route malformed input repeatedly")
    return SafeDisposition(SafeAction.NO_CAUSAL_INFERENCE, False,
                           "insufficient structural evidence; do not guess a cause")
