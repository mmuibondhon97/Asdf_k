"""Strict corpus and result gate based on the repository's real probe IDs.

A gate cannot pass with missing probes, duplicate IDs, extra IDs, truthy
non-booleans, or absent run IDs. Expected classes are loaded from the actual
JSONL corpus; no synthetic b01-b25 mapping is fabricated here.
"""
from __future__ import annotations

import json
from collections import Counter
from dataclasses import dataclass, field
from pathlib import Path

_ALLOWED = {
    "C1_TRANSPORT", "C2_PROVIDER_POLICY", "C3_INCOMPLETE",
    "C4_CAPABILITY_DECLINE", "C5_EVIDENCE_DECLINE",
    "C6_PROVIDER_CONFIGURATION", "C7_INVALID_REQUEST", "OK",
}


def _unique_object(pairs):
    obj = {}
    for key, value in pairs:
        if key in obj:
            raise ValueError(f"duplicate JSON key: {key}")
        obj[key] = value
    return obj


def _reject_constant(value: str):
    raise ValueError(f"non-standard JSON numeric constant: {value}")


def strict_json_loads(source: str):
    """Parse strict JSONL records; reject duplicate keys and NaN/Infinity."""
    return json.loads(source, object_pairs_hook=_unique_object,
                      parse_constant=_reject_constant)


@dataclass(frozen=True)
class Probe:
    probe_id: str
    expected_class: str
    fixture: str


@dataclass
class GateReport:
    run_id: str | None = None
    expected: int = 0
    received: int = 0
    passed: int = 0
    per_class: dict[str, dict[str, int]] = field(default_factory=dict)
    missing: list[str] = field(default_factory=list)
    duplicate: list[str] = field(default_factory=list)
    unexpected: list[str] = field(default_factory=list)
    invalid: list[str] = field(default_factory=list)
    ok: bool = False
    reason: str = "not evaluated"

    def as_dict(self) -> dict:
        return {
            "run_id": self.run_id, "expected": self.expected,
            "received": self.received, "passed": self.passed,
            "per_class": self.per_class, "missing": self.missing,
            "duplicate": self.duplicate, "unexpected": self.unexpected,
            "invalid": self.invalid, "ok": self.ok, "reason": self.reason,
        }


def load_probe_corpus(path: str | Path) -> list[Probe]:
    rows: list[Probe] = []
    seen: set[str] = set()
    for line_no, line in enumerate(Path(path).read_text(encoding="utf-8").splitlines(), 1):
        if not line.strip():
            continue
        try:
            row = strict_json_loads(line)
        except (json.JSONDecodeError, ValueError) as exc:
            raise ValueError(f"invalid strict JSON at line {line_no}: {exc}") from exc
        if not isinstance(row, dict):
            raise ValueError(f"line {line_no}: probe row must be an object")
        if set(row) - {"id", "expected_class", "fixture", "synthetic"}:
            raise ValueError(f"line {line_no}: unexpected probe field(s)")
        pid, category, fixture = row.get("id"), row.get("expected_class"), row.get("fixture")
        if not isinstance(pid, str) or not pid or pid.strip() != pid or pid in seen:
            raise ValueError(f"line {line_no}: missing, invalid or duplicate probe id")
        if not isinstance(category, str) or category not in _ALLOWED:
            raise ValueError(f"line {line_no}: unsupported expected_class {category!r}")
        if not isinstance(fixture, str) or not fixture:
            raise ValueError(f"line {line_no}: fixture must be a non-empty string")
        if "synthetic" in row and type(row["synthetic"]) is not bool:
            raise ValueError(f"line {line_no}: synthetic must be a JSON boolean")
        seen.add(pid)
        rows.append(Probe(pid, category, fixture))
    if not rows:
        raise ValueError("probe corpus is empty")
    return rows


def evaluate(results: list[dict], probes: list[Probe], run_id: str | None = None) -> GateReport:
    report = GateReport(run_id=run_id, expected=len(probes), received=len(results))
    expected = {p.probe_id: p.expected_class for p in probes}
    classes = Counter(expected.values())
    report.per_class = {name: {"expected": count, "passed": 0, "received": 0}
                        for name, count in sorted(classes.items())}
    seen: Counter[str] = Counter()
    normalized: dict[str, dict] = {}
    observed_run_ids: set[str] = set()
    for index, item in enumerate(results):
        if not isinstance(item, dict):
            report.invalid.append(f"row {index}: result is not an object")
            continue
        unknown_fields = set(item) - {"probe_id", "passed", "run_id"}
        if unknown_fields:
            report.invalid.append(f"row {index}: unexpected field(s) {sorted(unknown_fields)}")
            continue
        pid = item.get("probe_id")
        if not isinstance(pid, str) or not pid or pid.strip() != pid:
            report.invalid.append(f"row {index}: missing or invalid probe_id")
            continue
        seen[pid] += 1
        if pid not in expected:
            report.unexpected.append(pid)
            continue
        if seen[pid] > 1:
            report.duplicate.append(pid)
            continue
        if type(item.get("passed")) is not bool:
            report.invalid.append(f"{pid}: passed must be a JSON boolean")
            continue
        item_run = item.get("run_id", run_id)
        if not isinstance(item_run, str) or not item_run.strip():
            report.invalid.append(f"{pid}: missing run_id")
            continue
        if run_id is not None and item_run != run_id:
            report.invalid.append(f"{pid}: run_id differs from requested run_id")
            continue
        observed_run_ids.add(item_run)
        normalized[pid] = {"passed": item["passed"], "run_id": item_run}
    if len(observed_run_ids) > 1:
        report.invalid.append("results contain more than one run_id")
    if report.run_id is None and len(observed_run_ids) == 1:
        report.run_id = next(iter(observed_run_ids))
    report.missing = sorted(set(expected) - set(normalized))
    for pid, row in normalized.items():
        cls = expected[pid]
        report.per_class[cls]["received"] += 1
        if row["passed"]:
            report.passed += 1
            report.per_class[cls]["passed"] += 1
    report.duplicate = sorted(set(report.duplicate))
    report.unexpected = sorted(set(report.unexpected))
    # A gate is an exact one-result-per-probe contract, not a percentage-only check.
    if report.invalid or report.duplicate or report.unexpected or report.missing:
        report.reason = "result set is incomplete, duplicated, unexpected, or malformed"
        return report
    if report.passed != report.expected:
        report.reason = f"{report.expected - report.passed} expected probe(s) failed"
        return report
    report.ok = True
    report.reason = "one passing result for every corpus probe"
    return report
