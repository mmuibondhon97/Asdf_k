"""Build a VEIL diagnostic payload attached to each Ladder attempt."""
from __future__ import annotations

from ladder.types import CanonicalTurnGraph, Classification, OutcomeClass, ProviderResult
from .provenance.classify import classify
from .provenance.features import StructuralFeatures, extract


def observation_payload(graph: CanonicalTurnGraph, result: ProviderResult | None,
                        classification: Classification) -> dict:
    if result is not None:
        features = extract(graph, result)
    else:
        # A provider exception can still carry an explicit structured policy
        # code. Ladder's P2 classifier uses C2 only for that trusted signal.
        explicit_policy = (
            classification.category is OutcomeClass.C2_PROVIDER_POLICY
            and any(item.source in {"provider", "provider_policy"}
                    for item in classification.evidence)
        )
        required = set(graph.tool_contract.required_names)
        if graph.tool_contract.required_name:
            required.add(graph.tool_contract.required_name)
        features = StructuralFeatures(
            finish_reason=None,
            stream_complete=False,
            provider_refusal_present=explicit_policy,
            response_chars=0,
            response_sha256=None,
            tool_call_count=0,
            returned_tool_names=(),
            required_tool_names=tuple(sorted(required)),
            available_tool_names=tuple(sorted(set(graph.tool_contract.available_tools))),
        )
    return classify(classification, features).as_dict()
