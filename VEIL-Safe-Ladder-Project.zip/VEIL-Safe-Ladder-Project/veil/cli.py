from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path

from . import __version__
from .gate import evaluate, load_probe_corpus, strict_json_loads
from .ledger import HashChainLedger
from .rea import identify_file


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(prog="veil", description="VEIL-Safe diagnostics and evidence tools")
    parser.add_argument("--version", action="version", version=f"VEIL-Safe {__version__}")
    sub = parser.add_subparsers(dest="command", required=True)

    corpus = sub.add_parser("check-corpus", help="validate the repository's actual synthetic protocol corpus")
    corpus.add_argument("--probes", type=Path, default=Path("data/probes.jsonl"))

    gate = sub.add_parser("evaluate", help="strictly evaluate a JSONL result set against the source corpus")
    gate.add_argument("results", type=Path)
    gate.add_argument("--probes", type=Path, default=Path("data/probes.jsonl"))
    gate.add_argument("--run-id", default=None)

    ledger = sub.add_parser("verify-ledger", help="verify an existing VEIL hash-chain ledger")
    ledger.add_argument("path", type=Path)

    ident = sub.add_parser("identify", help="read-only binary/file identification")
    ident.add_argument("path", type=Path)
    ident.add_argument("--max-bytes", type=int, default=2 * 1024 * 1024 * 1024)

    args = parser.parse_args(argv)
    if args.command == "check-corpus":
        probes = load_probe_corpus(args.probes)
        print(json.dumps({"ok": True, "probe_count": len(probes),
                          "classes": sorted({p.expected_class for p in probes})}, indent=2))
        return 0
    if args.command == "evaluate":
        probes = load_probe_corpus(args.probes)
        rows = []
        try:
            for line_no, line in enumerate(args.results.read_text(encoding="utf-8").splitlines(), 1):
                if line.strip():
                    try:
                        rows.append(strict_json_loads(line))
                    except (json.JSONDecodeError, ValueError) as exc:
                        raise ValueError(f"invalid strict JSON in result file at line {line_no}: {exc}") from exc
        except (OSError, ValueError) as exc:
            print(json.dumps({"ok": False, "error": str(exc)}, indent=2))
            return 2
        report = evaluate(rows, probes, args.run_id)
        print(json.dumps(report.as_dict(), indent=2, sort_keys=True))
        return 0 if report.ok else 1
    if args.command == "verify-ledger":
        report = HashChainLedger(args.path).verify()
        print(json.dumps(report.as_dict(), indent=2, sort_keys=True))
        return 0 if report.ok else 1
    if args.command == "identify":
        result = identify_file(args.path, max_bytes=args.max_bytes)
        print(json.dumps(result, indent=2, sort_keys=True))
        return 0
    return 2


if __name__ == "__main__":
    raise SystemExit(main())
