"""VEIL-Safe: Verification, Evidence and Integrity Layer for Ladder.

This package observes protocol-level outcomes. It does not attempt to
circumvent provider policy, alter model weights, suppress refusal text,
rewrite system instructions, or change safety-related request parameters.
"""
__version__ = "1.0.0"
