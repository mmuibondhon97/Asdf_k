# Probe corpus and measurement protocol

`data/probes.jsonl` contains 25 synthetic protocol fixtures. Each row has a
stable probe ID, an expected topology label and a fixture name. These are
contract fixtures, not prompts submitted to providers and not evidence that a
model answered any task.

## Labels

- `C1_TRANSPORT`: transport and upstream availability failures.
- `C2_PROVIDER_POLICY`: an explicit provider policy/refusal signal.
- `C3_INCOMPLETE`: response or stream did not complete cleanly.
- `C4_CAPABILITY_DECLINE`: a mandatory, explicit tool contract was not met.
- `C5_EVIDENCE_DECLINE`: an explicitly requested structured evidence envelope
  contains populated unknowns or limitations.
- `C6_PROVIDER_CONFIGURATION`: provider authentication/configuration failure.
- `C7_INVALID_REQUEST`: invalid client/upstream request shape or parameter.
- `OK`: complete response satisfying its declared contract.

`python manage.py battery` is deliberately a **dry preflight**. It verifies the
corpus count and unique IDs, hashes the corpus, and confirms lane activation
from local configuration/credential presence only. It performs no network
calls and does not validate remote credentials or model quality. Every run
prints its own `run_id` and corpus SHA-256.

## Live evaluation status

No live provider battery or real Claude Code/Codex CLI task run is claimed by
this repository emission. The acceptance target of 23/25 and the zero-hard-
failure C2 core-set target remain unmeasured. A hand-labelled 120-turn dataset
has not been supplied, so C4 recall and C2 precision have not been computed.
Do not substitute the classifier model card's metrics for a Ladder evaluation.

The operator's isolated one-lane probe requires `LADDER_LIVE=1`, an explicit
`POST /setup/probe` action, and performs exactly one benign completion request
without invoking the router. It is a connectivity check, not a refusal test.
