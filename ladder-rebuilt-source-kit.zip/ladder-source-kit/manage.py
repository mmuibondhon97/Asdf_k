#!/usr/bin/env python3
from __future__ import annotations

import argparse
import hashlib
import importlib.metadata
import json
import os
import re
import subprocess
import sys
import tempfile
import time
import uuid
from pathlib import Path

ROOT = Path(__file__).resolve().parent
sys.path.insert(0, str(ROOT))

def cmd_run(args) -> int:
    from ladder.config import Settings
    settings = Settings.from_env()
    if settings.bind_host != "127.0.0.1":
        print("refusing non-loopback bind", file=sys.stderr)
        return 2
    import uvicorn
    print(f"ladder listening on http://127.0.0.1:{settings.bind_port}")
    uvicorn.run("ladder.main:app", host="127.0.0.1", port=settings.bind_port,
                access_log=False, proxy_headers=False, forwarded_allow_ips="")
    return 0


def cmd_test(args) -> int:
    run_id = uuid.uuid4().hex
    print(f"TEST run_id={run_id}", flush=True)
    result = subprocess.call([sys.executable, "-m", "pytest", "-q"] + args.pytest_args, cwd=ROOT)
    print(f"TEST_RESULT run_id={run_id} exit_code={result}", flush=True)
    return result


def _requirements_source(dev: bool) -> Path:
    return ROOT / ("requirements-dev.txt" if dev else "requirements.txt")


def _requirements_lock(dev: bool) -> Path:
    return ROOT / ("requirements-dev.lock" if dev else "requirements.lock")


def _parse_hash_lock(path: Path) -> tuple[dict[str, tuple[str, set[str]]], list[str]]:
    """Parse the deliberately small pip --require-hashes lock format."""
    errors: list[str] = []
    if not path.is_file():
        return {}, [f"{path.name} missing; generate it from real wheel artifacts"]
    logical = re.sub(r"\\\s*\n\s*", " ", path.read_text(encoding="utf-8"))
    entries: dict[str, tuple[str, set[str]]] = {}
    for raw in logical.splitlines():
        line = raw.strip()
        if not line or line.startswith("#"):
            continue
        match = re.fullmatch(r"([A-Za-z0-9_.-]+)==([A-Za-z0-9_.+-]+)(?:\s+(.*))?", line)
        if not match:
            errors.append(f"invalid or unpinned lock entry: {line}")
            continue
        name, version, tail = match.groups()
        tail = tail or ""
        hashes = set(re.findall(r"--hash=sha256:([0-9a-fA-F]{64})", tail))
        residue = re.sub(r"--hash=sha256:[0-9a-fA-F]{64}", "", tail).strip()
        if not hashes:
            errors.append(f"{name}=={version} has no valid SHA-256 artifact hash")
        if residue:
            errors.append(f"{name}=={version} contains unsupported lock options: {residue}")
        normalized = name.lower().replace("_", "-")
        if normalized in entries:
            errors.append(f"duplicate lock entry: {normalized}")
        entries[normalized] = (version, hashes)
    return entries, errors


def _direct_pins(path: Path) -> tuple[dict[str, str], list[str]]:
    """Read exact pins, following local pip -r includes recursively."""
    pins: dict[str, str] = {}
    errors: list[str] = []
    visited: set[Path] = set()

    def visit(current: Path) -> None:
        current = current.resolve()
        if current in visited:
            return
        visited.add(current)
        try:
            lines = current.read_text(encoding="utf-8").splitlines()
        except OSError as exc:
            errors.append(f"cannot read requirement include {current}: {exc}")
            return
        for raw in lines:
            line = raw.strip()
            if not line or line.startswith("#"):
                continue
            include = re.fullmatch(r"(?:-r|--requirement)\s+(.+)", line)
            if include:
                visit(current.parent / include.group(1).strip())
                continue
            if line.startswith("-"):
                errors.append(f"unsupported requirement option: {line}")
                continue
            match = re.fullmatch(r"([A-Za-z0-9_.-]+)==([A-Za-z0-9_.+-]+)", line)
            if not match:
                errors.append(f"source requirement is not exactly pinned: {line}")
                continue
            name, version = match.groups()
            normalized = name.lower().replace("_", "-")
            if normalized in pins and pins[normalized] != version:
                errors.append(f"conflicting source pins for {normalized}: {pins[normalized]} and {version}")
            pins[normalized] = version

    visit(path)
    return pins, errors


def cmd_integrity(args) -> int:
    run_id = uuid.uuid4().hex
    source = _requirements_source(args.dev)
    lock = _requirements_lock(args.dev)
    findings: list[tuple[str, str]] = []
    if not source.is_file():
        findings.append(("CRITICAL", f"{source.name} missing"))
    else:
        pins, pin_errors = _direct_pins(source)
        findings.extend(("CRITICAL", item) for item in pin_errors)
        locked, lock_errors = _parse_hash_lock(lock)
        findings.extend(("CRITICAL", item) for item in lock_errors)
        for name, expected in pins.items():
            if name not in locked:
                findings.append(("CRITICAL", f"{name}=={expected} missing from {lock.name}"))
            elif locked[name][0] != expected:
                findings.append(("CRITICAL", f"{name} lock={locked[name][0]}, source_pin={expected}"))
        if locked and not lock_errors:
            for name, (expected, hashes) in sorted(locked.items()):
                try:
                    installed = importlib.metadata.version(name)
                except importlib.metadata.PackageNotFoundError:
                    findings.append(("CRITICAL", f"{name}=={expected} is not installed"))
                    continue
                if installed != expected:
                    findings.append(("CRITICAL", f"{name} installed={installed}, lock={expected}"))
                else:
                    findings.append(("PASS", f"{name}=={expected} installed; {len(hashes)} artifact hash(es) recorded"))
    if source.is_file() and lock.is_file():
        check = subprocess.run([sys.executable, "-m", "pip", "check"], capture_output=True, text=True)
        if check.returncode:
            findings.append(("CRITICAL", "pip check failed: " + (check.stdout + check.stderr).strip().replace("\n", "; ")))
        else:
            findings.append(("PASS", "pip check: installed dependency metadata is consistent"))
    order = {"PASS": 0, "INFO": 1, "WARN": 2, "CRITICAL": 3}
    worst = max((x[0] for x in findings), key=lambda x: order[x], default="PASS")
    for level, message in findings:
        print(f"[{level}] {message}")
    source_sha = hashlib.sha256(source.read_bytes()).hexdigest() if source.is_file() else "missing"
    lock_sha = hashlib.sha256(lock.read_bytes()).hexdigest() if lock.is_file() else "missing"
    print(f"integrity={worst} run_id={run_id} source_sha256={source_sha} lock_sha256={lock_sha}")
    return 1 if worst in ("WARN", "CRITICAL") else 0

def _wheel_or_sdist_identity(path: Path) -> tuple[str, str] | None:
    name = path.name
    if name.endswith(".whl"):
        parts = name.split("-")
        if len(parts) >= 5:
            return parts[0].lower().replace("_", "-"), parts[1]
    try:
        from packaging.utils import parse_sdist_filename
        pkg, version = parse_sdist_filename(name)
        return str(pkg).lower().replace("_", "-"), str(version)
    except Exception:
        m = re.match(r"^(.+?)-([0-9][^-]*)(?:\.tar\.gz|\.zip|\.tar\.bz2)$", name)
        if m:
            return m.group(1).lower().replace("_", "-"), m.group(2)
    return None


def _manifest_wheels(wheelhouse: Path) -> tuple[list[Path], list[str]]:
    """Validate safe manifest paths, verify bytes, and return listed wheel artifacts."""
    manifest = wheelhouse / "MANIFEST.sha256"
    if not manifest.is_file():
        return [], [f"{manifest} missing"]
    rows: list[tuple[str, str]] = []
    errors: list[str] = []
    for line in manifest.read_text(encoding="utf-8").splitlines():
        if not line.strip():
            continue
        match = re.fullmatch(r"([0-9a-fA-F]{64})  ([A-Za-z0-9_.+-]+)", line)
        if not match:
            errors.append(f"invalid or unsafe sha256sum manifest row: {line}")
            continue
        digest, filename = match.groups()
        candidate = wheelhouse / filename
        if candidate.is_symlink() or not candidate.is_file():
            errors.append(f"manifest artifact missing or symlinked: {filename}")
            continue
        if candidate.resolve().parent != wheelhouse.resolve():
            errors.append(f"manifest path escapes wheelhouse: {filename}")
            continue
        if candidate.suffix != ".whl":
            errors.append(f"manifest contains non-wheel artifact: {filename}")
            continue
        rows.append((digest.lower(), filename))
    if errors:
        return [], errors
    if not rows:
        return [], ["manifest contains no wheel artifacts"]
    check = subprocess.run(["sha256sum", "-c", "MANIFEST.sha256"], cwd=wheelhouse,
                           capture_output=True, text=True)
    if check.returncode:
        return [], ["wheelhouse transfer manifest failed: " +
                    (check.stdout + check.stderr).strip().replace("\n", "; ")]
    return [wheelhouse / filename for _digest, filename in rows], []


def _write_lock_from_wheels(source: Path, out: Path, artifacts: list[Path]) -> int:
    """Write a complete pinned hash lock from exact wheel bytes."""
    try:
        from pip._vendor.packaging.utils import parse_wheel_filename
    except ImportError as exc:
        print(f"pip packaging support unavailable: {exc}", file=sys.stderr); return 2
    grouped: dict[str, set[str]] = {}
    for artifact in artifacts:
        try:
            package, version, _build, _tags = parse_wheel_filename(artifact.name)
        except Exception as exc:
            print(f"invalid wheel filename {artifact.name}: {exc}", file=sys.stderr); return 2
        digest = hashlib.sha256(artifact.read_bytes()).hexdigest()
        spec = f"{str(package).lower().replace('_', '-')}=={version}"
        grouped.setdefault(spec, set()).add(digest)
    direct, errors = _direct_pins(source)
    if errors:
        print("\n".join(errors), file=sys.stderr); return 2
    for package, version in direct.items():
        if f"{package}=={version}" not in grouped:
            print(f"direct pin absent from wheel artifacts: {package}=={version}", file=sys.stderr); return 1
    rows = [
        "# Generated from actual wheel files; source artifacts are verified by wheelhouse/MANIFEST.sha256.",
        "# MANIFEST.sha256 is transfer integrity only; this file is the pip installation lock.",
        "# Complete resolved closure for CPython 3.13 Linux x86_64.",
        "# Install with pip install --no-index --find-links wheelhouse --require-hashes -r " + out.name,
    ]
    for spec in sorted(grouped):
        rows.append(spec + " \\")
        hashes = sorted(grouped[spec])
        for index, digest in enumerate(hashes):
            suffix = " \\" if index < len(hashes) - 1 else ""
            rows.append(f"    --hash=sha256:{digest}{suffix}")
    tmp = out.with_suffix(out.suffix + ".tmp")
    tmp.write_text("\n".join(rows) + "\n", encoding="utf-8", newline="\n")
    os.chmod(tmp, 0o600); os.replace(tmp, out)
    print(f"wrote {out.name}: {len(grouped)} distributions, {sum(len(v) for v in grouped.values())} real wheel hashes")
    return 0


def cmd_lock(args) -> int:
    """Generate hash locks from actual wheel artifacts."""
    source, out = _requirements_source(args.dev), _requirements_lock(args.dev)
    if not source.is_file():
        print(f"{source.name} missing", file=sys.stderr); return 2
    if args.from_manifest:
        if not args.wheelhouse:
            print("--from-manifest requires --wheelhouse", file=sys.stderr); return 2
        wheelhouse = Path(args.wheelhouse).resolve()
        if not wheelhouse.is_dir():
            print(f"wheelhouse directory not found: {wheelhouse}", file=sys.stderr); return 2
        manifest_artifacts, errors = _manifest_wheels(wheelhouse)
        if errors:
            print("\n".join(errors), file=sys.stderr); return 2
        # Resolve only this requirements file's closure from the manifest-verified
        # wheelhouse. pip copies the selected wheel bytes to a temp directory;
        # every selected digest must be present in the verified manifest set.
        manifest_hashes = {hashlib.sha256(item.read_bytes()).hexdigest() for item in manifest_artifacts}
        with tempfile.TemporaryDirectory(prefix="ladder-manifest-lock-") as td:
            selected = Path(td) / "selected"; selected.mkdir()
            command = [sys.executable, "-m", "pip", "download", "--no-index",
                       "--only-binary=:all:", "--find-links", str(wheelhouse),
                       "--dest", str(selected), "-r", str(source)]
            print("lock_resolver=verified manifest wheelhouse")
            rc = subprocess.call(command, cwd=ROOT)
            if rc:
                print("pip could not resolve this requirement closure from verified wheels", file=sys.stderr)
                return rc
            selected_wheels = [item for item in selected.iterdir()
                               if item.is_file() and item.suffix == ".whl"]
            if not selected_wheels:
                print("no selected wheel artifacts; no lockfile written", file=sys.stderr); return 1
            unmanifested = [item.name for item in selected_wheels
                            if hashlib.sha256(item.read_bytes()).hexdigest() not in manifest_hashes]
            if unmanifested:
                print("resolver selected bytes absent from verified manifest: " + ", ".join(unmanifested),
                      file=sys.stderr); return 1
            return _write_lock_from_wheels(source, out, selected_wheels)
    with tempfile.TemporaryDirectory(prefix="ladder-lock-") as td:
        dest = Path(td) / "artifacts"; dest.mkdir()
        command = [sys.executable, "-m", "pip", "download", "--only-binary=:all:", "--dest", str(dest)]
        if args.wheelhouse:
            wheelhouse = Path(args.wheelhouse).resolve()
            if not wheelhouse.is_dir():
                print(f"wheelhouse directory not found: {wheelhouse}", file=sys.stderr); return 2
            command += ["--no-index", "--find-links", str(wheelhouse)]
        command += ["-r", str(source)]
        print("lock_resolver=" + ("offline wheelhouse" if args.wheelhouse else "configured pip index"))
        rc = subprocess.call(command, cwd=ROOT)
        if rc:
            print("pip could not resolve complete binary dependency closure; no lockfile written", file=sys.stderr); return rc
        artifacts = [x for x in dest.iterdir() if x.is_file() and x.suffix == ".whl"]
        if not artifacts:
            print("no wheel artifacts downloaded; no lockfile written", file=sys.stderr); return 1
        return _write_lock_from_wheels(source, out, artifacts)


def cmd_install(args) -> int:
    lock = _requirements_lock(args.dev)
    if not lock.is_file():
        print(f"{lock.name} missing; create it from actual wheel artifacts first", file=sys.stderr)
        return 2
    command = [sys.executable, "-m", "pip", "install"]
    if args.wheelhouse:
        wheelhouse = Path(args.wheelhouse).resolve()
        if not wheelhouse.is_dir():
            print(f"wheelhouse directory not found: {wheelhouse}", file=sys.stderr)
            return 2
        command += ["--no-index", "--find-links", str(wheelhouse)]
    command += ["--require-hashes", "-r", str(lock)]
    return subprocess.call(command, cwd=ROOT)

def cmd_battery(args) -> int:
    from ladder.config import Settings, load_lanes
    run_id = uuid.uuid4().hex
    corpus = ROOT / "data" / "probes.jsonl"
    try:
        rows = [json.loads(line) for line in corpus.read_text(encoding="utf-8").splitlines() if line.strip()]
    except (OSError, json.JSONDecodeError) as exc:
        print(f"FAIL corpus_read run_id={run_id} error={type(exc).__name__}")
        return 1
    digest = hashlib.sha256(corpus.read_bytes()).hexdigest()
    ids = [row.get("id") for row in rows]
    allowed = {"C1_TRANSPORT", "C2_PROVIDER_POLICY", "C3_INCOMPLETE",
               "C4_CAPABILITY_DECLINE", "C5_EVIDENCE_DECLINE", "C6_PROVIDER_CONFIGURATION",
               "C7_INVALID_REQUEST", "OK"}
    invalid_rows = [row.get("id") for row in rows if row.get("synthetic") is not True
                    or row.get("expected_class") not in allowed or not row.get("fixture")]
    if len(rows) != 25 or len(set(ids)) != 25 or invalid_rows:
        print(f"FAIL corpus_integrity run_id={run_id} count={len(rows)} unique={len(set(ids))} invalid={invalid_rows}")
        return 1
    try:
        settings = Settings.from_env()
        lanes = load_lanes(settings)
    except (ValueError, OSError) as exc:
        print(f"FAIL lane_manifest run_id={run_id} error={type(exc).__name__}: {exc}")
        return 1
    print(f"DRY battery run_id={run_id} corpus_sha256={digest} probes={len(rows)}")
    print(f"lane_presence={len(lanes)} (presence only; no network call or credential validation)")
    if not lanes:
        print("result=FAIL_NO_ACTIVE_LANES")
        return 1
    print("result=PASS_PREFLIGHT; provider capability, classifier quality and live-session acceptance remain unrun")
    return 0


def _sha256_file(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        while chunk := handle.read(1024 * 1024):
            digest.update(chunk)
    return digest.hexdigest()


def cmd_build(args) -> int:
    """Register an existing external adapter; never train or modify model weights."""
    if not args.artifact_dir or not args.parameter_manifest or not args.base_commit or not args.base_repo:
        print("registration requires --artifact-dir, --parameter-manifest, --base-repo and --base-commit",
              file=sys.stderr)
        print("This step does not run Heretic or perform refusal-suppression/abliteration.", file=sys.stderr)
        return 2
    directory = Path(args.artifact_dir).resolve()
    manifest_path = Path(args.parameter_manifest).resolve()
    base_repo = Path(args.base_repo).resolve()
    if not directory.is_dir() or not manifest_path.is_file() or not base_repo.is_dir():
        print("artifact directory, JSON parameter manifest and base Git repository must exist", file=sys.stderr)
        return 2
    try:
        param_manifest_obj = json.loads(manifest_path.read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError) as exc:
        print(f"parameter manifest must be readable JSON: {exc}", file=sys.stderr)
        return 2
    if not isinstance(param_manifest_obj, dict):
        print("parameter manifest must contain a JSON object", file=sys.stderr)
        return 2
    if not re.fullmatch(r"[0-9a-fA-F]{40}|[0-9a-fA-F]{64}", args.base_commit):
        print("base commit must be a full 40- or 64-character Git object ID", file=sys.stderr)
        return 2
    try:
        verified_commit = subprocess.check_output(
            ["git", "-C", str(base_repo), "rev-parse", "--verify", f"{args.base_commit}^{{commit}}"],
            text=True, stderr=subprocess.DEVNULL).strip().lower()
    except (OSError, subprocess.CalledProcessError):
        print("base commit could not be verified in --base-repo", file=sys.stderr)
        return 2
    if verified_commit != args.base_commit.lower():
        print("Git resolved a different object ID; exact base commit required", file=sys.stderr)
        return 2

    files = []
    tree_paths = sorted(directory.rglob("*"))
    if any(path.is_symlink() for path in tree_paths):
        print("adapter artifact tree must not contain symlinks", file=sys.stderr)
        return 2
    for path in (x for x in tree_paths if x.is_file()):
        files.append({"path": str(path.relative_to(directory)), "size": path.stat().st_size,
                      "sha256": _sha256_file(path)})
    if not files:
        print("artifact directory is empty", file=sys.stderr)
        return 2
    tree_hash = hashlib.sha256(json.dumps(files, sort_keys=True, separators=(",", ":")).encode()).hexdigest()
    manifest = {
        "run_id": uuid.uuid4().hex, "base_model": args.base_model,
        "base_repo": str(base_repo), "base_commit": verified_commit,
        "artifact_dir": str(directory), "parameter_manifest": str(manifest_path),
        "parameter_manifest_sha256": _sha256_file(manifest_path),
        "files": files, "artifact_tree_sha256": tree_hash,
        "enabled": False, "registration_type": "external_task_adapter",
        "created_unix": time.time(),
        "note": "Registration only. No training, weight modification, merge, or refusal-suppression operation was performed.",
    }
    out_dir = ROOT / "artifacts"
    out_dir.mkdir(mode=0o700, exist_ok=True)
    if os.name == "posix":
        os.chmod(out_dir, 0o700)
    safe_model_name = re.sub(r"[^A-Za-z0-9_.-]+", "_", args.base_model).strip("._-") or "model"
    out = out_dir / f"{safe_model_name}-{tree_hash[:12]}.manifest.json"
    tmp = out.with_suffix(out.suffix + ".tmp")
    try:
        tmp.write_text(json.dumps(manifest, indent=2) + "\n", encoding="utf-8")
        if os.name == "posix":
            os.chmod(tmp, 0o600)
        os.replace(tmp, out)
    except BaseException:
        try:
            tmp.unlink()
        except OSError:
            pass
        raise
    print(f"registered disabled adapter manifest: {out}")
    print(f"run_id={manifest['run_id']} artifact_tree_sha256={tree_hash}")
    return 0


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(prog="ladder")
    sub = parser.add_subparsers(dest="command", required=True)
    sub.add_parser("run")
    test = sub.add_parser("test")
    test.add_argument("pytest_args", nargs=argparse.REMAINDER)
    integrity = sub.add_parser("integrity")
    integrity.add_argument("--dev", action="store_true", help="verify the development lock and environment")
    lock = sub.add_parser("lock")
    lock.add_argument("--dev", action="store_true", help="lock requirements-dev.txt instead of production requirements")
    lock.add_argument("--wheelhouse", help="wheelhouse directory")
    lock.add_argument("--from-manifest", action="store_true",
                      help="generate lock only from wheel files listed in a verified MANIFEST.sha256")
    install = sub.add_parser("install")
    install.add_argument("--dev", action="store_true", help="install the development lock")
    install.add_argument("--wheelhouse", help="install offline from this wheelhouse directory")
    sub.add_parser("battery")
    build = sub.add_parser("build")
    build.add_argument("base_model")
    build.add_argument("--base-commit")
    build.add_argument("--base-repo")
    build.add_argument("--artifact-dir")
    build.add_argument("--parameter-manifest")
    args = parser.parse_args(argv)
    return {"run": cmd_run, "test": cmd_test, "integrity": cmd_integrity,
            "lock": cmd_lock, "install": cmd_install, "battery": cmd_battery, "build": cmd_build}[args.command](args)


if __name__ == "__main__":
    raise SystemExit(main())
