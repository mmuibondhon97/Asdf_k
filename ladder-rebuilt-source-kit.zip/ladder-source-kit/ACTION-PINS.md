# GitHub Actions immutable pins

The workflow uses full commit SHAs and semver comments:

- `actions/checkout` `3d3c42e5aac5ba805825da76410c181273ba90b1` — `v7.0.1`
  https://github.com/actions/checkout/commit/3d3c42e5aac5ba805825da76410c181273ba90b1
- `actions/setup-python` `6d4fd22b20465ccc0f7354476588e8df7c9ca0e0` — `v7.1.0`
  https://github.com/actions/setup-python/commit/6d4fd22b20465ccc0f7354476588e8df7c9ca0e0
- `actions/upload-artifact` `cf430e030ddbb5b0abf93d22962f4752f3646cd9` — `v7.0.2`
  https://github.com/actions/upload-artifact/commit/cf430e030ddbb5b0abf93d22962f4752f3646cd9

The version-to-commit associations were checked against public repository references
during this review. `scripts/static_validate.py` enforces SHA length/hex syntax and
the required semver comment; it does not make a network request.


The hosted workflow also obtains `rhysd/actionlint` v1.7.12 for Linux amd64 and
verifies the release archive SHA-256 before execution:
`8aca8db96f1b94770f1b0d72b6dddcb1ebb8123cb3712530b08cc387b349a3d8`.
