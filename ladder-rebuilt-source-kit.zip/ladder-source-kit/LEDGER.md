# Evidence ledger

The ledger is append-only JSON Lines at `LADDER_LEDGER` (default
`~/.ladder/ledger.jsonl`). On POSIX, the file is created and reset to mode
`0600`. Each record is flushed and `fsync`'d before routing continues. If a
ledger append fails, the affected request fails closed with an evidence-ledger
error rather than silently proceeding without its required audit event.

## Event fields

| Field | Meaning |
|---|---|
| `event_id` | Unique ledger record identifier |
| `run_id` | One routing/probe execution identifier |
| `request_id` | P0 request identifier |
| `lane_id` | Lane that produced the recorded outcome |
| `attempt` | Attempt number within the run |
| `class` | P2 classification or isolated probe status |
| `evidence` | Structured source/code/excerpt/confidence records where present |
| `latency_ms` | Measured elapsed time for the attempt |
| `session_id_hash` | SHA-256 of session-affinity key; raw key is not logged |
| `timestamp_unix` | Event timestamp |

Credential values from configured environment variables are redacted before
write. Generic bearer/API-key patterns are also redacted. The ledger may still
contain excerpts from assistant output; treat it as potentially sensitive
operational data and restrict backups and access accordingly.

There is no built-in deletion or remote export. Back up and rotate the file
using the operator's local retention policy. Never publish a ledger containing
user prompts, tool output, provider metadata or diagnostics without reviewing
and redacting it first.
