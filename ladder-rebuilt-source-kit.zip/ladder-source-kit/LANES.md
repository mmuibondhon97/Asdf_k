# Lane and dependency register

This register distinguishes runtime packages, optional diagnostic components,
provider/model lanes, and external repositories. A repository's license does
not automatically license its linked dependencies or model weights.

## Ladder runtime

| Component | Version / pin | License | Status |
|---|---|---|---|
| ladder | 0.1.0 | MIT | This project; see `LICENSE` |
| Python | 3.11+ | PSF | Runtime requirement |
| FastAPI | 0.165.0 | MIT | Exact runtime pin in `requirements.txt` |
| LiteLLM | 1.110.2 | MIT | Exact runtime pin in `requirements.txt` |
| Uvicorn | 0.54.0 | BSD-3-Clause | Exact runtime pin in `requirements.txt` |
| HTTPX | 0.28.1 | BSD-3-Clause | Development/test dependency |
| pytest | 9.2.0 | MIT | Development/test dependency |

The exact release pins and published license metadata were checked against
package registries on 2026-11-21. The local container used for the test run
had different installed versions; see `VERIFICATION.md` and use
`python manage.py integrity` to check the target machine. `requirements.lock`
is intentionally not checked in until `python manage.py lock` computes real
artifact hashes for the target platform and Python version.

Registry references: [FastAPI 0.165.0](https://pypi.org/project/fastapi/0.165.0/),
[LiteLLM 1.110.2](https://pypi.org/project/litellm/1.110.2/),
[Uvicorn 0.54.0](https://pypi.org/project/uvicorn/0.54.0/),
[HTTPX 0.28.1](https://pypi.org/project/httpx/0.28.1/), and
[pytest 9.2.0](https://pypi.org/project/pytest/9.2.0/).

## Optional classifier

| Component | License / terms | Status |
|---|---|---|
| `VINAY-UMRETHE/Refusal-Classifier-V2` | Apache-2.0 as represented by its model card | Optional, not bundled, not downloaded, not evaluated here |

The model card describes five labels and English-language limitations. Its
reported metrics are model-card claims, not Ladder measurements. An immutable
model commit must be selected and recorded before enabling the optional
`HuggingFaceRefusalJudge`; no revision hash is asserted in this repository.

## Excluded model-modification projects

| Project | Upstream license | Ladder treatment |
|---|---|---|
| [`p-e-w/heretic`](https://github.com/p-e-w/heretic) | AGPL-3.0-or-later | Not bundled, invoked, modified, served, or used to alter model weights |
| [`PurpleDoubleD/locally-uncensored`](https://github.com/PurpleDoubleD/locally-uncensored) | AGPL-3.0-only | External desktop project; not bundled or invoked |

Ladder does not ship an abliteration pipeline, refusal-suppression adapter, or
safety-off provider parameter path. Anyone separately modifying or network-
serving an AGPL component must review the applicable license and source-offer
obligations for that exact distribution and deployment. No blanket claim is
made about model-weight licensing; each model card and provider agreement must
be checked independently before a model is registered as a lane.

## Field maps and reverse-engineering tool collections

| Repository | Repository license / treatment |
|---|---|
| `morluto/awesome-reverse-engineering` | CC0 list; listed tools retain their own licenses |
| `reacher-z/Awesome-REA` | MIT list; linked software retains its own licenses |

The Stage 1–8 tools supplied in the project brief (Detect-It-Easy, PE-bear,
pefile, LIEF, Capstone, Ghidra, radare2, Rizin/Cutter, Keystone, Unicorn,
angr, x64dbg, PE-sieve, Hollows Hunter, capa, FLOSS, Detours, Frida,
Ultimate-ASI-Loader, HijackLibs, System Informer and ViGEmBus) are not
runtime dependencies of an LLM wire-protocol proxy. None is downloaded,
bundled, linked or invoked by this build. Their individual licenses must be
reviewed before separate use or redistribution.

## Provider and model lanes

No provider lane is enabled by default. Configure each lane explicitly in
`LADDER_LANES_JSON` or the local config store. For every production lane,
record at least:

- provider and exact model identifier;
- provider/model license or service terms and the date checked;
- model revision or immutable artifact identity when locally hosted;
- context, tool, streaming, JSON and modality capabilities;
- locality and base URL (loopback for local endpoints);
- key environment-variable name (never the key value);
- artifact manifest and SHA-256 for locally built adapters.

A provider model name is not a software version pin. Do not infer weight
licenses from the provider SDK or the repository that hosts a model.
