from __future__ import annotations

from dataclasses import dataclass, field
from enum import Enum
from typing import Any


class OutcomeClass(str, Enum):
    C1_TRANSPORT = "C1_TRANSPORT"
    C2_PROVIDER_POLICY = "C2_PROVIDER_POLICY"
    C3_INCOMPLETE = "C3_INCOMPLETE"
    C4_CAPABILITY = "C4_CAPABILITY_DECLINE"
    C5_EVIDENCE = "C5_EVIDENCE_DECLINE"
    C6_PROVIDER_CONFIG = "C6_PROVIDER_CONFIGURATION"
    C7_INVALID_REQUEST = "C7_INVALID_REQUEST"
    OK = "OK"


class Action(str, Enum):
    RETURN = "RETURN"
    RETRY_SAME = "RETRY_SAME"
    TRY_NEXT_COMPATIBLE = "TRY_NEXT_COMPATIBLE"
    ERROR = "ERROR"


@dataclass(frozen=True)
class TextBlock:
    text: str


@dataclass(frozen=True)
class OpaqueBlock:
    kind: str
    payload: Any


@dataclass(frozen=True)
class ToolCall:
    call_id: str
    name: str
    arguments_json: str
    tool_index: int = 0

    def arguments(self) -> Any:
        import json
        return json.loads(self.arguments_json)


@dataclass(frozen=True)
class ToolResult:
    call_id: str
    content: Any
    is_error: bool = False


@dataclass
class Turn:
    turn_id: str
    role: str
    blocks: list[TextBlock | OpaqueBlock | ToolCall | ToolResult] = field(default_factory=list)


@dataclass(frozen=True)
class ToolContract:
    available_tools: tuple[str, ...] = ()
    required: bool = False
    required_name: str | None = None
    source: str = "none"
    required_names: tuple[str, ...] = ()


@dataclass
class CanonicalTurnGraph:
    conversation_id: str
    turns: list[Turn]
    tool_contract: ToolContract = field(default_factory=ToolContract)
    source_format: str = "openai"
    expect_evidence_envelope: bool = False

    def assistant_prose(self) -> str:
        """Assistant-authored text only. Tool results are intentionally excluded."""
        parts: list[str] = []
        for turn in self.turns:
            if turn.role == "assistant":
                parts.extend(block.text for block in turn.blocks if isinstance(block, TextBlock))
        return "\n".join(parts)

    def to_openai_messages(self) -> list[dict[str, Any]]:
        """Serialize the canonical graph to OpenAI chat messages without flattening tools."""
        out: list[dict[str, Any]] = []
        for turn in self.turns:
            if turn.role == "tool":
                for block in turn.blocks:
                    if isinstance(block, ToolResult):
                        content = block.content
                        # OpenAI Chat Completions has no standard `is_error` field
                        # on tool messages. Preserve this signal in-band instead
                        # of sending an unsupported top-level property.
                        if block.is_error:
                            marker = "[Tool execution reported an error]"
                            if isinstance(content, str):
                                content = marker + "\n" + content
                            elif isinstance(content, list):
                                content = [{"type": "text", "text": marker}, *content]
                            else:
                                import json
                                content = marker + "\n" + json.dumps(content, ensure_ascii=False)
                        out.append({"role": "tool", "tool_call_id": block.call_id,
                                    "content": content})
                continue

            text_parts: list[str] = []
            structured_parts: list[dict[str, Any]] = []
            tool_calls: list[dict[str, Any]] = []
            for block in turn.blocks:
                if isinstance(block, TextBlock):
                    text_parts.append(block.text)
                    structured_parts.append({"type": "text", "text": block.text})
                elif isinstance(block, OpaqueBlock):
                    payload = block.payload if isinstance(block.payload, dict) else {"data": block.payload}
                    # Translate common Anthropic image blocks to OpenAI image_url blocks.
                    if block.kind in ("image", "input_image"):
                        source = payload.get("source", {})
                        if isinstance(source, dict) and source.get("type") == "base64":
                            media = source.get("media_type", "application/octet-stream")
                            url = f"data:{media};base64,{source.get('data', '')}"
                        elif isinstance(source, dict) and source.get("type") == "url":
                            url = source.get("url", "")
                        else:
                            url = payload.get("image_url", "")
                        structured_parts.append({"type": "image_url", "image_url": {"url": url}})
                    else:
                        structured_parts.append({"type": block.kind, **payload})
                elif isinstance(block, ToolCall):
                    tool_calls.append({"id": block.call_id, "type": "function", "function": {
                        "name": block.name, "arguments": block.arguments_json}})
                elif isinstance(block, ToolResult):
                    content = block.content
                    if block.is_error:
                        marker = "[Tool execution reported an error]"
                        if isinstance(content, str):
                            content = marker + "\n" + content
                        elif isinstance(content, list):
                            content = [{"type": "text", "text": marker}, *content]
                        else:
                            import json
                            content = marker + "\n" + json.dumps(content, ensure_ascii=False)
                    out.append({"role": "tool", "tool_call_id": block.call_id,
                                "content": content})

            message: dict[str, Any] = {"role": turn.role}
            if structured_parts:
                if all(part.get("type") == "text" for part in structured_parts):
                    message["content"] = "\n".join(text_parts)
                else:
                    message["content"] = structured_parts
            else:
                message["content"] = ""
            if tool_calls:
                message["tool_calls"] = tool_calls
            out.append(message)
        return out


@dataclass(frozen=True)
class RequestContext:
    request_id: str
    session_id: str | None
    deadline_monotonic: float
    output_token_budget: int
    requested_model: str | None = None


@dataclass(frozen=True)
class Budget:
    attempts_left: int
    seconds_left: float
    output_tokens_left: int


@dataclass(frozen=True)
class Evidence:
    source: str
    code: str
    excerpt: str = ""
    confidence: float | None = None


@dataclass(frozen=True)
class Classification:
    category: OutcomeClass
    evidence: tuple[Evidence, ...] = ()
    source: str = "structural"
    confidence: float = 1.0


@dataclass(frozen=True)
class Disposition:
    action: Action
    reason: str
    status_code: int = 200


@dataclass
class ProviderResult:
    text: str = ""
    tool_calls: list[ToolCall] = field(default_factory=list)
    finish_reason: str | None = None
    usage: dict[str, Any] = field(default_factory=dict)
    provider_refusal: str | None = None
    stream_complete: bool = True


@dataclass(frozen=True)
class LaneCapabilities:
    tools: bool = False
    streaming: bool = True
    json_mode: bool = False
    modalities: tuple[str, ...] = ("text",)


@dataclass(frozen=True)
class Lane:
    id: str
    provider: str
    model: str
    api_key_env: str = ""
    base_url: str | None = None
    enabled: bool = True
    needs_key: bool = True
    locality: str = "remote"
    cost_weight: float = 1.0
    capabilities: LaneCapabilities = field(default_factory=LaneCapabilities)
    artifact_manifest: str | None = None


@dataclass
class AttemptRecord:
    attempt: int
    lane_id: str
    category: str
    elapsed_ms: int
    evidence: list[dict[str, Any]] = field(default_factory=list)


@dataclass
class RouteResult:
    ok: bool
    provider_result: ProviderResult | None = None
    lane: Lane | None = None
    attempts: int = 0
    classification: Classification | None = None
    diagnostics: list[AttemptRecord] = field(default_factory=list)
    error_code: str | None = None
    error_message: str | None = None
    status_code: int = 200
    run_id: str = ""
