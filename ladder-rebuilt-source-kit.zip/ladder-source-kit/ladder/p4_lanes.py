from __future__ import annotations

import os
import threading
from collections import OrderedDict
from typing import Any

from ladder.types import Lane


# LiteLLM's OpenAI-compatible provider may require api_key to be present even
# when a local server ignores its value. This marker is not a credential.
LOCAL_PRESENCE_KEY = "sk-local"


class SessionAffinity:
    """Process-local affinity with bounded LRU eviction."""
    def __init__(self, max_sessions: int = 2048) -> None:
        if max_sessions < 1:
            raise ValueError("max_sessions must be positive")
        self.max_sessions = max_sessions
        self._lock = threading.Lock()
        self._by_session: OrderedDict[str, str] = OrderedDict()

    def get(self, session_id: str | None) -> str | None:
        if not session_id:
            return None
        with self._lock:
            lane = self._by_session.get(session_id)
            if lane is not None:
                self._by_session.move_to_end(session_id)
            return lane

    def set(self, session_id: str | None, lane_id: str) -> None:
        if not session_id:
            return
        with self._lock:
            self._by_session[session_id] = lane_id
            self._by_session.move_to_end(session_id)
            while len(self._by_session) > self.max_sessions:
                self._by_session.popitem(last=False)

    def forget(self, session_id: str | None) -> None:
        if not session_id:
            return
        with self._lock:
            self._by_session.pop(session_id, None)


def rank_lanes(lanes: list[Lane], profiles: dict[str, dict[str, Any]],
               require_tools: bool = False, require_streaming: bool = False,
               require_json: bool = False,
               required_modalities: set[str] | None = None) -> list[Lane]:
    """Order compatible lanes from P6 measurements without depending on P6 code."""
    modalities = required_modalities or set()
    compatible = [lane for lane in lanes
                  if (not require_tools or lane.capabilities.tools)
                  and (not require_streaming or lane.capabilities.streaming)
                  and (not require_json or lane.capabilities.json_mode)
                  and modalities.issubset(set(lane.capabilities.modalities))]
    configured_order = {lane.id: index for index, lane in enumerate(lanes)}

    def key(lane: Lane) -> tuple[float, float, float, int]:
        row = profiles.get(lane.id) or {}
        fallback = configured_order.get(lane.id, len(configured_order))
        samples = float(row.get("samples", 0) or 0)
        if samples <= 0:
            # No evidence yet: configured order is the deterministic cold start.
            return (0.5, float("inf"), 0.0, fallback)
        rate = (float(row.get("ok", 0) or 0) + 1.0) / (samples + 2.0)
        mean_latency = float(row.get("latency_ms", 0) or 0) / samples
        return (-rate, mean_latency, lane.cost_weight, fallback)

    return sorted(compatible, key=key)


def build_lane_kwargs(lane: Lane, messages: list[dict[str, Any]], request: dict[str, Any],
                      timeout: float, output_token_budget: int, stream: bool = False) -> dict[str, Any]:
    token_field = "max_completion_tokens" if request.get("max_completion_tokens") is not None else "max_tokens"
    requested_tokens = request.get(token_field, output_token_budget)
    kwargs: dict[str, Any] = {
        "model": lane.model,
        "messages": messages,
        "timeout": max(timeout, 0.1),
        token_field: min(int(requested_tokens), output_token_budget),
        "stream": stream,
    }
    key = os.environ.get(lane.api_key_env, "") if lane.api_key_env else ""
    if key:
        kwargs["api_key"] = key
    elif not lane.needs_key and lane.base_url:
        # Presence-only placeholder for local OpenAI-compatible servers.
        kwargs["api_key"] = LOCAL_PRESENCE_KEY
    if lane.base_url:
        kwargs["api_base"] = lane.base_url

    for name in ("temperature", "top_p", "top_k", "stop", "seed", "response_format",
                 "frequency_penalty", "presence_penalty", "logit_bias", "user",
                 "parallel_tool_calls"):
        if request.get(name) is not None:
            kwargs[name] = request[name]
    if stream and isinstance(request.get("stream_options"), dict):
        kwargs["stream_options"] = request["stream_options"]

    # `tool_choice=none` explicitly tells the provider not to call a tool. Do not
    # require a tool-capable lane or send unused tool schemas in that case.
    if request.get("response_format") is not None and not lane.capabilities.json_mode:
        raise ValueError(f"lane {lane.id} does not advertise JSON-mode support")
    tools = request.get("tools")
    if tools and request.get("tool_choice") != "none":
        if not lane.capabilities.tools:
            raise ValueError(f"lane {lane.id} does not advertise tool support")
        kwargs["tools"] = tools
        if request.get("tool_choice") is not None:
            kwargs["tool_choice"] = request["tool_choice"]
    return kwargs
