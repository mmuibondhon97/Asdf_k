"""Strict JSON helpers for protocol payloads and tool arguments."""
from __future__ import annotations

import json
from typing import Any


def _reject_constant(value: str) -> None:
    raise ValueError(f"non-standard JSON constant is not permitted: {value}")


def _unique_object(pairs: list[tuple[str, Any]]) -> dict[str, Any]:
    result: dict[str, Any] = {}
    for key, value in pairs:
        if key in result:
            raise ValueError(f"duplicate JSON object key is not permitted: {key}")
        result[key] = value
    return result


def strict_json_loads(value: str | bytes) -> Any:
    """Parse RFC-compatible JSON; reject NaN/Infinity and duplicate object keys."""
    return json.loads(value, object_pairs_hook=_unique_object, parse_constant=_reject_constant)


def strict_json_object(value: str, label: str) -> dict[str, Any]:
    parsed = strict_json_loads(value)
    if not isinstance(parsed, dict):
        raise ValueError(f"{label} must decode to a JSON object")
    return parsed
