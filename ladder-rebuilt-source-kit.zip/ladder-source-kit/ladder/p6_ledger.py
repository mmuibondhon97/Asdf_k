from __future__ import annotations

import json
import os
import re
import stat
import time
import threading
from pathlib import Path
from typing import Any

_SECRET = re.compile(r"(?i)(sk-[A-Za-z0-9_-]{8,}|Bearer\s+\S+|api[_-]?key\s*[:=]\s*\S+)")


def redact(value: Any) -> Any:
    if isinstance(value, str):
        return _SECRET.sub("[REDACTED]", value)[:240]
    if isinstance(value, list):
        return [redact(x) for x in value]
    if isinstance(value, dict):
        return {str(k): ("[REDACTED]" if any(s in str(k).lower() for s in ("key", "token", "secret")) else redact(v))
                for k, v in value.items()}
    return value


class EvidenceLedger:
    def __init__(self, path: Path, secrets: tuple[str, ...] = ()):
        self.path = path
        self.secrets = tuple(x for x in secrets if x)
        self._lock = threading.Lock()

    def append(self, event: dict[str, Any]) -> None:
        event = dict(event)
        if not event.get("run_id"):
            raise ValueError("ledger event requires a run_id")
        event.setdefault("event_id", __import__("uuid").uuid4().hex)
        self.path.parent.mkdir(parents=True, exist_ok=True)
        payload = dict(event)
        payload.setdefault("timestamp_unix", time.time())
        clean = redact(payload)
        for secret in sorted(self.secrets, key=len, reverse=True):
            clean = _replace_secret(clean, secret)
        line = json.dumps(clean, ensure_ascii=True, separators=(",", ":")) + "\n"
        flags = os.O_WRONLY | os.O_CREAT | os.O_APPEND
        if hasattr(os, "O_NOFOLLOW"):
            flags |= os.O_NOFOLLOW
        with self._lock:
            if self.path.is_symlink():
                raise OSError("refusing to append through a ledger symlink")
            fd = os.open(self.path, flags, 0o600)
            try:
                if not stat.S_ISREG(os.fstat(fd).st_mode):
                    raise OSError("ledger path is not a regular file")
                if hasattr(os, "fchmod"):
                    os.fchmod(fd, 0o600)
                data = line.encode("utf-8")
                offset = 0
                while offset < len(data):
                    written = os.write(fd, data[offset:])
                    if written <= 0:
                        raise OSError("short ledger write")
                    offset += written
                os.fsync(fd)
            finally:
                os.close(fd)


def _replace_secret(value: Any, secret: str) -> Any:
    if isinstance(value, str):
        return value.replace(secret, "[REDACTED]")
    if isinstance(value, list):
        return [_replace_secret(item, secret) for item in value]
    if isinstance(value, dict):
        return {key: _replace_secret(item, secret) for key, item in value.items()}
    return value
