from __future__ import annotations

import json
import os
import threading
import time
import tempfile
from pathlib import Path
from typing import Any

from ladder.p6_drift import drift_alarm


class FingerprintMeter:
    """Reliability/latency profile. Provider policy outcomes are not a routing score."""
    def __init__(self, path: Path):
        self.path = path
        self._lock = threading.Lock()
        self._data: dict[str, dict[str, Any]] = {}
        if path.is_file():
            try:
                raw = json.loads(path.read_text(encoding="utf-8"))
                if isinstance(raw, dict):
                    self._data = raw
            except (OSError, json.JSONDecodeError):
                self._data = {}

    def record(self, lane_id: str, category: str, latency_ms: int, run_id: str = "") -> None:
        # C2 must not improve or damage a lane's routing rank: it is a provider
        # policy decision, not a transport/implementation quality measurement.
        if category == "C2_PROVIDER_POLICY":
            return
        with self._lock:
            row = self._data.setdefault(lane_id, {"ok": 0, "fail": 0, "latency_ms": 0,
                                                  "samples": 0, "sample_events": []})
            row["samples"] = row.get("samples", 0) + 1
            row["latency_ms"] = row.get("latency_ms", 0) + max(latency_ms, 0)
            success = category in ("OK", "C5_EVIDENCE_DECLINE")
            if success:
                row["ok"] = row.get("ok", 0) + 1
            else:
                row["fail"] = row.get("fail", 0) + 1
            events = row.setdefault("sample_events", [])
            events.append({"run_id": run_id, "timestamp_unix": time.time(),
                           "class": category, "latency_ms": max(latency_ms, 0),
                           "success": success})
            # Keep bounded per-run provenance while the cumulative counters remain available.
            del events[:-1000]
            self._persist_locked()

    def _persist_locked(self) -> None:
        self.path.parent.mkdir(parents=True, exist_ok=True)
        fd, tmp = tempfile.mkstemp(prefix=".ladder-metrics-", suffix=".tmp", dir=str(self.path.parent))
        try:
            with os.fdopen(fd, "w", encoding="utf-8", newline="\n") as fh:
                json.dump(self._data, fh, indent=2, sort_keys=True)
                fh.write("\n")
                fh.flush()
                os.fsync(fh.fileno())
            os.chmod(tmp, 0o600)
            os.replace(tmp, self.path)
            if os.name == "posix":
                dfd = os.open(self.path.parent, os.O_RDONLY)
                try:
                    os.fsync(dfd)
                finally:
                    os.close(dfd)
        except BaseException:
            try:
                os.unlink(tmp)
            except OSError:
                pass
            raise


    def snapshot(self) -> list[dict[str, Any]]:
        """Return secret-free operational lane profiles for the local operator surface."""
        with self._lock:
            data = json.loads(json.dumps(self._data))
        result: list[dict[str, Any]] = []
        for lane_id, row in sorted(data.items()):
            if not isinstance(row, dict):
                continue
            samples = max(int(row.get("samples", 0) or 0), 0)
            successes = max(int(row.get("ok", 0) or 0), 0)
            failures = max(int(row.get("fail", 0) or 0), 0)
            latency_total = max(float(row.get("latency_ms", 0) or 0), 0.0)
            events = row.get("sample_events", [])
            events = [event for event in events if isinstance(event, dict)
                      and isinstance(event.get("success"), bool)] if isinstance(events, list) else []
            class_counts: dict[str, int] = {}
            for event in events:
                category = str(event.get("class", "UNKNOWN"))
                class_counts[category] = class_counts.get(category, 0) + 1
            # Compare the most recent 25 observations with all preceding
            # retained observations. Require 25 in each side before alerting.
            drift = False
            if len(events) >= 50:
                baseline, current = events[:-25], events[-25:]
                base_rate = sum(bool(x["success"]) for x in baseline) / len(baseline)
                current_rate = sum(bool(x["success"]) for x in current) / len(current)
                drift = drift_alarm(base_rate, len(baseline), current_rate, len(current), sigma=2.0)
            result.append({
                "lane_id": lane_id, "samples": samples, "successes": successes,
                "failures": failures,
                "success_rate": (successes / samples) if samples else None,
                "mean_latency_ms": (latency_total / samples) if samples else None,
                "class_counts_retained": class_counts,
                "recent_run_ids": [str(x.get("run_id", "")) for x in events[-25:]
                                   if x.get("run_id")],
                "drift_alarm_2sigma": drift,
            })
        return result

    def ranking_profiles(self) -> dict[str, dict[str, float]]:
        """Expose only the numeric observations needed by P4's lane ranker."""
        with self._lock:
            return {
                lane_id: {
                    "samples": float(row.get("samples", 0) or 0),
                    "ok": float(row.get("ok", 0) or 0),
                    "fail": float(row.get("fail", 0) or 0),
                    "latency_ms": float(row.get("latency_ms", 0) or 0),
                }
                for lane_id, row in self._data.items() if isinstance(row, dict)
            }


