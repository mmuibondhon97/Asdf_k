from __future__ import annotations

import hashlib
import json
import time
import uuid
from typing import Any

from ladder.jsonutil import strict_json_loads
from ladder.types import RequestContext


class IngressError(ValueError):
    def __init__(self, message: str, status_code: int = 400):
        super().__init__(message)
        self.status_code = status_code


def parse_body(raw: bytes, max_bytes: int) -> dict[str, Any]:
    if len(raw) > max_bytes:
        raise IngressError("request body exceeds configured size limit", 413)
    try:
        body = strict_json_loads(raw.decode("utf-8"))
    except (UnicodeDecodeError, ValueError) as exc:
        raise IngressError("request body must be valid UTF-8 JSON", 400) from exc
    if not isinstance(body, dict):
        raise IngressError("request body must be a JSON object", 400)
    return body


def _derived_session_id(body: dict[str, Any]) -> str | None:
    """Derive an opaque stable fallback from the first prompt when the client sends no ID.

    This is a lane-affinity hint only, not an identity or authorization token.
    Only a SHA-256 digest is retained; raw prompt content is not persisted.
    """
    messages = body.get("messages")
    if not isinstance(messages, list):
        return None
    first = next((m for m in messages if isinstance(m, dict) and m.get("role") == "user"), None)
    if first is None and messages:
        first = messages[0]
    if first is None:
        return None
    encoded = json.dumps(first, ensure_ascii=False, sort_keys=True, separators=(",", ":")).encode("utf-8")
    return "derived-" + hashlib.sha256(encoded).hexdigest()


def request_context(headers, body: dict[str, Any], settings,
                    request_model: str | None = None) -> RequestContext:
    request_id = (headers.get("x-request-id") or "").strip()
    if not request_id or len(request_id) > 128 or any(ord(c) < 32 for c in request_id):
        request_id = uuid.uuid4().hex

    metadata = body.get("metadata") if isinstance(body.get("metadata"), dict) else {}
    ladder_meta = body.get("ladder") if isinstance(body.get("ladder"), dict) else {}
    session_id = (headers.get("x-ladder-session") or ladder_meta.get("session_id") or
                  body.get("conversation_id") or metadata.get("conversation_id"))
    if session_id is None:
        session_id = _derived_session_id(body)
    if session_id is not None:
        session_id = str(session_id)[:256]

    if body.get("max_tokens") is not None and body.get("max_completion_tokens") is not None:
        raise IngressError("max_tokens and max_completion_tokens are mutually exclusive", 400)
    requested_tokens = body.get("max_tokens", body.get("max_completion_tokens", settings.output_token_budget))
    if isinstance(requested_tokens, bool):
        raise IngressError("max_tokens must be a positive integer", 400)
    try:
        parsed_tokens = int(requested_tokens)
    except (TypeError, ValueError):
        raise IngressError("max_tokens must be a positive integer", 400)
    if parsed_tokens < 1 or str(parsed_tokens) != str(requested_tokens).strip():
        raise IngressError("max_tokens must be a positive integer", 400)
    token_budget = min(parsed_tokens, settings.output_token_budget)
    deadline = time.monotonic() + settings.deadline_seconds
    return RequestContext(request_id, session_id, deadline, token_budget, request_model)
