from __future__ import annotations

import ipaddress
import json
import math
import os
import re
import tempfile
from dataclasses import asdict, dataclass
from pathlib import Path
from typing import Any
from urllib.parse import urlsplit

from ladder.jsonutil import strict_json_loads
from ladder.types import Lane, LaneCapabilities


@dataclass(frozen=True)
class Settings:
    bind_host: str = "127.0.0.1"
    bind_port: int = 8080
    auth_tokens: tuple[str, ...] = ()
    max_attempts: int = 6
    deadline_seconds: float = 120.0
    output_token_budget: int = 4096
    max_request_bytes: int = 8 * 1024 * 1024
    max_response_chars: int = 2_000_000
    config_path: Path = Path("~/.ladder/config.json").expanduser()
    ledger_path: Path = Path("~/.ladder/ledger.jsonl").expanduser()
    metrics_path: Path = Path("~/.ladder/metrics.json").expanduser()
    allow_setup_mutations: bool = True
    live_enabled: bool = False

    @classmethod
    def from_env(cls) -> "Settings":
        load_env_file(Path(os.environ.get("LADDER_DOTENV", ".env")))
        host = os.environ.get("LADDER_BIND_HOST", "127.0.0.1")
        if host != "127.0.0.1":
            raise ValueError("LADDER_BIND_HOST must be exactly 127.0.0.1; non-loopback binds are forbidden")
        tokens = tuple(x.strip() for x in os.environ.get("LADDER_AUTH_TOKENS", "").split(",") if x.strip())

        def bounded_int(env_name: str, default: int, minimum: int, maximum: int) -> int:
            raw = os.environ.get(env_name, str(default))
            try:
                value = int(raw)
            except ValueError as exc:
                raise ValueError(f"{env_name} must be an integer") from exc
            if not minimum <= value <= maximum:
                raise ValueError(f"{env_name} must be between {minimum} and {maximum}")
            return value

        try:
            deadline = float(os.environ.get("LADDER_DEADLINE_S", "120"))
        except ValueError as exc:
            raise ValueError("LADDER_DEADLINE_S must be numeric") from exc
        if not math.isfinite(deadline) or not 1.0 <= deadline <= 600.0:
            raise ValueError("LADDER_DEADLINE_S must be between 1 and 600 seconds")
        return cls(
            bind_host=host,
            bind_port=bounded_int("LADDER_BIND_PORT", 8080, 1, 65535),
            auth_tokens=tokens,
            max_attempts=bounded_int("LADDER_MAX_ATTEMPTS", 6, 1, 16),
            deadline_seconds=deadline,
            output_token_budget=bounded_int("LADDER_TOKEN_BUDGET", 4096, 1, 65536),
            max_request_bytes=bounded_int("LADDER_MAX_REQUEST_BYTES", 8 * 1024 * 1024, 1024, 32 * 1024 * 1024),
            max_response_chars=bounded_int("LADDER_MAX_RESPONSE_CHARS", 2_000_000, 1024, 16_000_000),
            config_path=Path(os.environ.get("LADDER_CONFIG", "~/.ladder/config.json")).expanduser(),
            ledger_path=Path(os.environ.get("LADDER_LEDGER", "~/.ladder/ledger.jsonl")).expanduser(),
            metrics_path=Path(os.environ.get("LADDER_METRICS", "~/.ladder/metrics.json")).expanduser(),
            allow_setup_mutations=os.environ.get("LADDER_SETUP_MUTATIONS", "1") == "1",
            live_enabled=os.environ.get("LADDER_LIVE", "0") == "1",
        )


def load_env_file(path: Path) -> int:
    """Small `.env` reader: KEY=value and simple quotes; process env wins."""
    if not path.is_file():
        return 0
    count = 0
    for raw in path.read_text(encoding="utf-8").splitlines():
        line = raw.strip()
        if not line or line.startswith("#"):
            continue
        if line.startswith("export "):
            line = line[7:].lstrip()
        if "=" not in line:
            continue
        key, value = line.split("=", 1)
        key, value = key.strip(), value.strip()
        if not key or not re.fullmatch(r"[A-Za-z_][A-Za-z0-9_]*", key):
            continue
        if len(value) >= 2 and value[0] == value[-1] and value[0] in "\"'":
            value = value[1:-1]
        if key not in os.environ:
            os.environ[key] = value
        count += 1
    return count


def _strict_bool(item: dict[str, Any], key: str, default: bool) -> bool:
    value = item.get(key, default)
    if type(value) is not bool:
        raise ValueError(f"lane field {key!r} must be a JSON boolean")
    return value


def lane_from_dict(item: dict[str, Any]) -> Lane:
    if not isinstance(item, dict):
        raise ValueError("lane definition must be an object")
    lane_id = item.get("id")
    model = item.get("model")
    provider = item.get("provider", "openai")
    if not isinstance(lane_id, str) or not re.fullmatch(r"[A-Za-z0-9][A-Za-z0-9_.-]{0,63}", lane_id):
        raise ValueError("lane id must be 1–64 safe ASCII letters, digits, dot, underscore or hyphen")
    if not isinstance(model, str) or not model.strip() or len(model) > 256 or any(ord(c) < 32 for c in model):
        raise ValueError(f"lane {lane_id}: model must be a non-empty, single-line string")
    if not isinstance(provider, str) or not re.fullmatch(r"[A-Za-z0-9_.-]{1,64}", provider):
        raise ValueError(f"lane {lane_id}: provider name is invalid")

    api_key_env = item.get("api_key_env", "")
    if not isinstance(api_key_env, str) or (api_key_env and not re.fullmatch(r"[A-Z_][A-Z0-9_]{0,127}", api_key_env)):
        raise ValueError(f"lane {lane_id}: api_key_env must be an uppercase environment-variable name")
    needs_key = _strict_bool(item, "needs_key", True)
    if needs_key and not api_key_env:
        raise ValueError(f"lane {lane_id}: needs_key=true requires api_key_env")

    locality = item.get("locality", "remote")
    if locality not in ("local", "remote"):
        raise ValueError(f"lane {lane_id}: locality must be 'local' or 'remote'")
    base_url = item.get("base_url")
    if base_url is not None:
        if not isinstance(base_url, str) or len(base_url) > 2048:
            raise ValueError(f"lane {lane_id}: base_url must be a URL string")
        parsed = urlsplit(base_url)
        if not parsed.hostname or parsed.username or parsed.password or parsed.query or parsed.fragment:
            raise ValueError(f"lane {lane_id}: base_url cannot contain credentials, query or fragment")
        host_is_loopback = parsed.hostname.lower() == "localhost"
        try:
            host_is_loopback = host_is_loopback or ipaddress.ip_address(parsed.hostname).is_loopback
        except ValueError:
            pass
        if parsed.scheme != "https" and not (parsed.scheme == "http" and host_is_loopback):
            raise ValueError(f"lane {lane_id}: base_url must use HTTPS, or HTTP on loopback only")
        if locality == "local" and not host_is_loopback:
            raise ValueError(f"lane {lane_id}: a local lane base_url must resolve to loopback")

    caps = item.get("capabilities") or {}
    if not isinstance(caps, dict):
        raise ValueError(f"lane {lane_id}: capabilities must be an object")
    tools = _strict_bool(caps, "tools", False)
    streaming = _strict_bool(caps, "streaming", True)
    json_mode = _strict_bool(caps, "json_mode", False)
    modalities = caps.get("modalities", ["text"])
    if not isinstance(modalities, list) or not all(isinstance(x, str) and x for x in modalities):
        raise ValueError(f"lane {lane_id}: modalities must be a string array")
    cost_weight = item.get("cost_weight", 1.0)
    if isinstance(cost_weight, bool):
        raise ValueError(f"lane {lane_id}: cost_weight must be numeric")
    try:
        cost_weight = float(cost_weight)
    except (TypeError, ValueError) as exc:
        raise ValueError(f"lane {lane_id}: cost_weight must be numeric") from exc
    if not math.isfinite(cost_weight) or cost_weight <= 0:
        raise ValueError(f"lane {lane_id}: cost_weight must be finite and greater than zero")
    return Lane(
        id=lane_id, provider=provider, model=model.strip(), api_key_env=api_key_env,
        base_url=base_url, enabled=_strict_bool(item, "enabled", True),
        needs_key=needs_key, locality=locality, cost_weight=cost_weight,
        capabilities=LaneCapabilities(tools, streaming, json_mode, tuple(modalities)),
        artifact_manifest=item.get("artifact_manifest"),
    )


def lane_to_dict(lane: Lane) -> dict[str, Any]:
    return {
        "id": lane.id, "provider": lane.provider, "model": lane.model,
        "api_key_env": lane.api_key_env, "base_url": lane.base_url,
        "enabled": lane.enabled, "needs_key": lane.needs_key,
        "locality": lane.locality, "cost_weight": lane.cost_weight,
        "capabilities": {
            "tools": lane.capabilities.tools,
            "streaming": lane.capabilities.streaming,
            "json_mode": lane.capabilities.json_mode,
            "modalities": list(lane.capabilities.modalities),
        },
        "artifact_manifest": lane.artifact_manifest,
    }


def load_lanes(settings: Settings, include_inactive: bool = False) -> list[Lane]:
    raw: Any = None
    if settings.config_path.is_file():
        try:
            obj = strict_json_loads(settings.config_path.read_text(encoding="utf-8"))
            raw = obj.get("lanes", []) if isinstance(obj, dict) else []
        except (OSError, ValueError):
            raw = []
    if raw is None:
        raw = []
    if not raw and os.environ.get("LADDER_LANES_JSON"):
        try:
            raw = strict_json_loads(os.environ["LADDER_LANES_JSON"])
        except ValueError as exc:
            raise ValueError("LADDER_LANES_JSON must be valid JSON") from exc
    if not isinstance(raw, list):
        raise ValueError("lane configuration must be a JSON array")
    if len(raw) > 64:
        raise ValueError("at most 64 lane definitions may be configured")
    seen: set[str] = set()
    lanes: list[Lane] = []
    for item in raw:
        lane = lane_from_dict(item)
        if lane.id in seen:
            raise ValueError(f"duplicate lane id: {lane.id}")
        seen.add(lane.id)
        if include_inactive or (lane.enabled and
                                (not lane.needs_key or (lane.api_key_env and os.environ.get(lane.api_key_env)))):
            lanes.append(lane)
    return lanes


def save_lanes(settings: Settings, lanes: list[Lane]) -> Path:
    if len(lanes) > 64:
        raise ValueError("at most 64 lane definitions may be configured")
    validated = [lane_from_dict(lane_to_dict(lane)) for lane in lanes]
    if len({lane.id for lane in validated}) != len(validated):
        raise ValueError("lane IDs must be unique")
    path = settings.config_path
    path.parent.mkdir(parents=True, exist_ok=True)
    payload = {"lanes": [lane_to_dict(x) for x in validated]}
    fd, tmp = tempfile.mkstemp(prefix=".ladder-", suffix=".tmp", dir=str(path.parent))
    try:
        with os.fdopen(fd, "w", encoding="utf-8", newline="\n") as fh:
            json.dump(payload, fh, ensure_ascii=False, indent=2)
            fh.write("\n")
            fh.flush()
            os.fsync(fh.fileno())
        os.chmod(tmp, 0o600)
        os.replace(tmp, path)
        if os.name == "posix":
            dfd = os.open(path.parent, os.O_RDONLY)
            try:
                os.fsync(dfd)
            finally:
                os.close(dfd)
    except BaseException:
        try:
            os.unlink(tmp)
        except OSError:
            pass
        raise
    return path
