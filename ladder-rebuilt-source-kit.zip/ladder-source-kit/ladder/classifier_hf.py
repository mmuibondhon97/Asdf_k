"""Optional local Hugging Face classifier adapter.

Not imported by the runtime unless explicitly enabled. Install the optional
ML stack separately and pin a model revision before enabling it.
"""
from __future__ import annotations

from typing import Any


class HuggingFaceRefusalJudge:
    def __init__(self, model_id: str, revision: str, device: str | None = None,
                 max_length: int = 8192):
        if not revision or len(revision) < 20:
            raise ValueError("a full immutable model commit revision is required")
        self.model_id = model_id
        self.revision = revision
        self.device = device
        self.max_length = max_length
        self._tokenizer: Any = None
        self._model: Any = None
        self._torch: Any = None

    def _load(self) -> None:
        if self._model is not None:
            return
        try:
            import torch
            from transformers import AutoModelForSequenceClassification, AutoTokenizer
        except ImportError as exc:
            raise RuntimeError("optional classifier requires torch and transformers") from exc
        self._torch = torch
        self._tokenizer = AutoTokenizer.from_pretrained(self.model_id, revision=self.revision)
        self._model = AutoModelForSequenceClassification.from_pretrained(
            self.model_id, revision=self.revision)
        if self.device:
            self._model.to(self.device)
        self._model.eval()

    def predict(self, prompt: str, response: str) -> tuple[str, float]:
        self._load()
        encoded = self._tokenizer(prompt, response, return_tensors="pt", truncation=True,
                                  max_length=self.max_length)
        if self.device:
            encoded = {k: v.to(self.device) for k, v in encoded.items()}
        with self._torch.inference_mode():
            probs = self._torch.softmax(self._model(**encoded).logits[0], dim=-1)
        idx = int(self._torch.argmax(probs).item())
        labels = getattr(self._model.config, "id2label", {})
        label = str(labels.get(idx, labels.get(str(idx), "unknown"))).lower()
        return label, float(probs[idx].item())
