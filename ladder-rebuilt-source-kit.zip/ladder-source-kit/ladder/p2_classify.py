from __future__ import annotations

import json
from typing import Any, Protocol

from ladder.types import (CanonicalTurnGraph, Classification, Evidence,
                          OutcomeClass, ProviderResult)


class ResponseJudge(Protocol):
    """Optional local semantic classifier; it can label, never override C2 structure."""
    def predict(self, prompt: str, response: str) -> tuple[str, float]: ...


class NoJudge:
    def predict(self, prompt: str, response: str) -> tuple[str, float]:
        return "unavailable", 0.0


def _get(obj: Any, key: str, default: Any = None) -> Any:
    return obj.get(key, default) if isinstance(obj, dict) else getattr(obj, key, default)


def classify_exception(exc: BaseException) -> Classification:
    status = _get(exc, "status_code") or _get(_get(exc, "response"), "status_code")
    name = type(exc).__name__.lower()
    if isinstance(exc, (TimeoutError, ConnectionError, OSError)) or "timeout" in name or "connection" in name:
        return Classification(OutcomeClass.C1_TRANSPORT,
                              (Evidence("exception", type(exc).__name__),))
    try:
        status = int(status) if status is not None else None
    except (TypeError, ValueError):
        status = None
    if status == 429 or status in (408, 425) or (status is not None and status >= 500):
        return Classification(OutcomeClass.C1_TRANSPORT,
                              (Evidence("http", f"status={status}"),))
    if status in (401, 403):
        return Classification(OutcomeClass.C6_PROVIDER_CONFIG,
                              (Evidence("http", f"status={status}"),))

    # C2 from exceptions requires an explicit structured policy code/type.
    # Generic prose containing words such as "blocked" or "safety" is not enough.
    code_values = [_get(exc, key) for key in ("code", "error_code", "type", "error_type")]
    response = _get(exc, "response")
    body = _get(response, "body") if response is not None else None
    if isinstance(body, (bytes, str)):
        try:
            body = json.loads(body.decode("utf-8") if isinstance(body, bytes) else body)
        except (UnicodeDecodeError, json.JSONDecodeError):
            body = None
    if isinstance(body, dict):
        error = body.get("error", body)
        if isinstance(error, dict):
            code_values.extend(error.get(key) for key in ("code", "type", "error_code"))
    normalized_codes = {str(value).strip().lower().replace("-", "_")
                        for value in code_values if isinstance(value, (str, int, float))}
    policy_codes = {"content_filter", "moderation_blocked", "policy_violation",
                    "safety_blocked", "content_policy_violation"}
    if normalized_codes.intersection(policy_codes) or name in {
            "contentpolicyviolationerror", "moderationblockederror"}:
        return Classification(OutcomeClass.C2_PROVIDER_POLICY,
                              (Evidence("provider_policy", "explicit_structured_policy_signal"),))

    if status is not None and 400 <= status < 500:
        return Classification(OutcomeClass.C7_INVALID_REQUEST,
                              (Evidence("http", f"status={status}"),))
    return Classification(OutcomeClass.C1_TRANSPORT,
                          (Evidence("exception", type(exc).__name__),))


def _evidence_decline(graph: CanonicalTurnGraph, text: str) -> bool:
    if not graph.expect_evidence_envelope:
        return False
    try:
        obj = json.loads(text)
    except (json.JSONDecodeError, TypeError):
        return False
    if not isinstance(obj, dict):
        return False
    return any(isinstance(obj.get(k), (list, dict, str)) and bool(obj.get(k))
               for k in ("unknowns", "limitations"))


def classify_result(graph: CanonicalTurnGraph, result: ProviderResult,
                    judge: ResponseJudge | None = None) -> Classification:
    # Structured provider signals have precedence over all semantic judgments.
    if result.finish_reason in ("content_filter", "safety") or result.provider_refusal:
        return Classification(OutcomeClass.C2_PROVIDER_POLICY,
                              (Evidence("provider", f"finish_reason={result.finish_reason or 'refusal'}"),))

    if not result.stream_complete or result.finish_reason is None or result.finish_reason == "length":
        return Classification(OutcomeClass.C3_INCOMPLETE,
                              (Evidence("stream", f"incomplete finish_reason={result.finish_reason}"),))

    if graph.tool_contract.required:
        names = {call.name for call in result.tool_calls}
        required_names = set(graph.tool_contract.required_names)
        required_name = graph.tool_contract.required_name
        if required_name:
            required_names.add(required_name)
        unexpected = names.difference(graph.tool_contract.available_tools)
        missing = required_names.difference(names)
        if (not result.tool_calls or unexpected or missing):
            return Classification(OutcomeClass.C4_CAPABILITY,
                                  (Evidence("tool_contract", f"required_tools={sorted(required_names) or '*'}; missing={sorted(missing)}; received={sorted(names)}"),))

    if _evidence_decline(graph, result.text):
        return Classification(OutcomeClass.C5_EVIDENCE,
                              (Evidence("evidence_envelope", "unknowns/limitations populated"),))

    if not result.text.strip() and not result.tool_calls:
        return Classification(OutcomeClass.C3_INCOMPLETE,
                              (Evidence("response", "empty assistant completion"),))

    # Optional classifier examines only the current assistant prose. It never
    # receives tool_result blocks and it cannot trigger automatic safety override.
    if judge is not None and result.text.strip():
        prompt = "\n".join(b.text for t in graph.turns if t.role == "user"
                            for b in t.blocks if hasattr(b, "text"))
        try:
            label, confidence = judge.predict(prompt, result.text)
        except Exception:
            # An optional diagnostic model must not make an otherwise valid
            # provider response unavailable.
            label, confidence = "unavailable", 0.0
        label = label.lower()
        if label in ("full_refusal", "partial_refusal"):
            return Classification(OutcomeClass.C2_PROVIDER_POLICY,
                                  (Evidence("local_classifier", label, result.text[:160], confidence),),
                                  source="local_classifier", confidence=confidence)
        # A classifier cannot invent a missing tool contract. Capability
        # language without a mandatory expected tool is returned to the client
        # as an ordinary answer/limitation rather than triggering a lane switch.

    return Classification(OutcomeClass.OK)
