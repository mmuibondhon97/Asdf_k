from __future__ import annotations

import json
import uuid
from typing import Any

from ladder.jsonutil import strict_json_object
from ladder.types import (CanonicalTurnGraph, OpaqueBlock, TextBlock, ToolCall,
                          ToolContract, ToolResult, Turn)


class NormalizeError(ValueError):
    pass


def _tool_contract(tools: list[dict[str, Any]], choice: Any, source: str = "openai") -> ToolContract:
    names: list[str] = []
    for tool in tools:
        if not isinstance(tool, dict):
            continue
        fn = tool.get("function", tool)
        if isinstance(fn, dict) and fn.get("name"):
            names.append(str(fn["name"]))
    required = False
    required_name = None
    if source == "anthropic":
        if isinstance(choice, dict):
            kind = choice.get("type")
            required = kind in ("any", "tool")
            if kind == "tool":
                required_name = str(choice.get("name") or "") or None
    else:
        if choice == "required":
            required = True
        elif isinstance(choice, dict):
            fn = choice.get("function") or {}
            required_name = str(fn.get("name") or "") or None
            required = bool(required_name) or choice.get("type") == "required"
    return ToolContract(tuple(names), required, required_name, source if required else "optional",
                        (required_name,) if required_name else ())


def _content_blocks(content: Any) -> list[TextBlock | OpaqueBlock]:
    if content is None:
        return []
    if isinstance(content, str):
        return [TextBlock(content)]
    if isinstance(content, list):
        blocks: list[TextBlock | OpaqueBlock] = []
        for item in content:
            if isinstance(item, str):
                blocks.append(TextBlock(item))
            elif isinstance(item, dict):
                kind = str(item.get("type", "opaque"))
                if kind in ("text", "input_text", "output_text") and isinstance(item.get("text"), str):
                    blocks.append(TextBlock(item["text"]))
                else:
                    blocks.append(OpaqueBlock(kind, dict(item)))
            else:
                blocks.append(OpaqueBlock("opaque", item))
        return blocks
    return [OpaqueBlock("opaque", content)]


def _validate_openai_tools(tools: list[Any]) -> None:
    names: set[str] = set()
    for index, tool in enumerate(tools):
        if not isinstance(tool, dict) or tool.get("type", "function") != "function":
            raise NormalizeError(f"tools[{index}] must be a function tool object")
        fn = tool.get("function")
        if not isinstance(fn, dict):
            raise NormalizeError(f"tools[{index}].function must be an object")
        name = fn.get("name")
        if not isinstance(name, str) or not name.strip() or len(name) > 128 or any(ord(c) < 32 or ord(c) == 127 for c in name):
            raise NormalizeError(f"tools[{index}].function.name must be a non-empty string up to 128 characters")
        if name in names:
            raise NormalizeError(f"duplicate tool function name: {name}")
        names.add(name)
        parameters = fn.get("parameters")
        if parameters is not None and not isinstance(parameters, dict):
            raise NormalizeError(f"tools[{index}].function.parameters must be a JSON schema object")


def normalize_openai(payload: dict[str, Any]) -> CanonicalTurnGraph:
    messages = payload.get("messages")
    if not isinstance(messages, list) or not messages:
        raise NormalizeError("messages must be a non-empty array")
    tools = payload.get("tools") or []
    if not isinstance(tools, list):
        raise NormalizeError("tools must be an array")
    _validate_openai_tools(tools)
    if "n" in payload and (type(payload["n"]) is not int or payload["n"] != 1):
        raise NormalizeError("Ladder supports exactly one choice; n must be 1")
    if "stream" in payload and type(payload["stream"]) is not bool:
        raise NormalizeError("stream must be a JSON boolean")
    stream_options = payload.get("stream_options")
    if stream_options is not None and not isinstance(stream_options, dict):
        raise NormalizeError("stream_options must be an object")
    metadata = payload.get("metadata") if isinstance(payload.get("metadata"), dict) else {}
    ladder_meta = payload.get("ladder") if isinstance(payload.get("ladder"), dict) else {}
    choice = payload.get("tool_choice")
    names_available = {tool["function"]["name"] for tool in tools}
    if choice is not None:
        if isinstance(choice, str) and choice not in ("auto", "none", "required"):
            raise NormalizeError("tool_choice must be auto, none, required or a function selector")
        if isinstance(choice, dict):
            fn = choice.get("function")
            name = fn.get("name") if isinstance(fn, dict) else None
            if choice.get("type") != "function" or not isinstance(name, str) or name not in names_available:
                raise NormalizeError("tool_choice function selector must name a supplied function tool")
        elif not isinstance(choice, str):
            raise NormalizeError("tool_choice has an unsupported shape")
    contract = _tool_contract(tools, choice)
    required_names = ladder_meta.get("expected_tools")
    if required_names is not None:
        if not isinstance(required_names, list) or not required_names or not all(
                isinstance(x, str) and x for x in required_names):
            raise NormalizeError("expected_tools must be a non-empty array of tool-name strings")
        names = tuple(required_names)
        if any(name not in contract.available_tools for name in names):
            raise NormalizeError("every expected tool must be present in the supplied tools array")
        contract = ToolContract(tuple(contract.available_tools), True,
                                names[0] if len(names) == 1 else None,
                                "explicit_client_contract", names)
    if contract.required and not contract.available_tools:
        raise NormalizeError("a required tool contract needs at least one supplied tool")
    graph = CanonicalTurnGraph(
        conversation_id=str(payload.get("conversation_id") or metadata.get("conversation_id") or uuid.uuid4().hex),
        turns=[], tool_contract=contract,
        source_format="openai",
        expect_evidence_envelope=bool(ladder_meta.get("expect_evidence_envelope", False)),
    )
    for index, msg in enumerate(messages):
        if not isinstance(msg, dict) or msg.get("role") not in ("system", "developer", "user", "assistant", "tool"):
            raise NormalizeError(f"messages[{index}] has an unsupported or missing role")
        role = str(msg["role"])
        turn = Turn(f"turn-{index:04d}", role, [])
        if role == "tool":
            call_id = msg.get("tool_call_id")
            if not isinstance(call_id, str) or not call_id or len(call_id) > 256 or any(ord(c) < 32 for c in call_id):
                raise NormalizeError(f"messages[{index}] tool role requires a bounded string tool_call_id")
            is_error = msg.get("is_error", False)
            if type(is_error) is not bool:
                raise NormalizeError(f"messages[{index}].is_error must be a JSON boolean")
            turn.blocks.append(ToolResult(call_id, msg.get("content", ""), is_error))
        else:
            turn.blocks.extend(_content_blocks(msg.get("content")))
            for tool_index, item in enumerate(msg.get("tool_calls") or []):
                if not isinstance(item, dict):
                    raise NormalizeError(f"messages[{index}].tool_calls[{tool_index}] must be an object")
                if item.get("type", "function") != "function":
                    raise NormalizeError(f"messages[{index}].tool_calls[{tool_index}] must be a function call")
                fn = item.get("function") or {}
                if not isinstance(fn, dict):
                    raise NormalizeError(f"messages[{index}].tool_calls[{tool_index}].function must be an object")
                call_id, name = item.get("id"), fn.get("name")
                args = fn.get("arguments", "{}")
                if (not isinstance(call_id, str) or not call_id or len(call_id) > 256
                        or not isinstance(name, str) or not name or len(name) > 128
                        or not isinstance(args, str) or len(args) > 256_000):
                    raise NormalizeError("tool call needs bounded id, function.name and string function.arguments")
                if any(ord(char) < 32 for char in call_id + name):
                    raise NormalizeError("tool call ID and function name cannot contain control characters")
                try:
                    parsed_args = strict_json_object(args, "tool call function.arguments")
                except ValueError as exc:
                    raise NormalizeError("tool call function.arguments must contain a valid JSON object") from exc
                turn.blocks.append(ToolCall(call_id, name, args, tool_index))
        graph.turns.append(turn)
    return graph


def normalize_anthropic(payload: dict[str, Any]) -> CanonicalTurnGraph:
    if "stream" in payload and type(payload["stream"]) is not bool:
        raise NormalizeError("stream must be a JSON boolean")
    messages = payload.get("messages")
    if not isinstance(messages, list) or not messages:
        raise NormalizeError("messages must be a non-empty array")
    tools = payload.get("tools") or []
    if not isinstance(tools, list):
        raise NormalizeError("tools must be an array")
    openai_tools = []
    tool_names: set[str] = set()
    for index, tool in enumerate(tools):
        if not isinstance(tool, dict) or not isinstance(tool.get("name"), str) or not tool["name"].strip():
            raise NormalizeError(f"tools[{index}] must have a non-empty name")
        name = tool["name"]
        if len(name) > 128 or any(ord(c) < 32 or ord(c) == 127 for c in name) or name in tool_names:
            raise NormalizeError(f"tools[{index}] has an overlong or duplicate name")
        tool_names.add(name)
        schema = tool.get("input_schema", {"type": "object"})
        if not isinstance(schema, dict):
            raise NormalizeError(f"tools[{index}].input_schema must be an object")
        openai_tools.append({"type": "function", "function": {
            "name": name, "description": tool.get("description", ""), "parameters": schema}})
    choice = payload.get("tool_choice")
    if choice is not None:
        if not isinstance(choice, dict) or choice.get("type") not in ("auto", "any", "tool"):
            raise NormalizeError("Anthropic tool_choice must have type auto, any or tool")
        if choice.get("type") == "tool" and choice.get("name") not in tool_names:
            raise NormalizeError("Anthropic tool_choice names a tool not supplied in tools")
    metadata = payload.get("metadata") if isinstance(payload.get("metadata"), dict) else {}
    graph = CanonicalTurnGraph(
        conversation_id=str(payload.get("conversation_id") or metadata.get("conversation_id") or uuid.uuid4().hex),
        turns=[], tool_contract=_tool_contract(openai_tools, payload.get("tool_choice"), "anthropic"),
        source_format="anthropic",
        expect_evidence_envelope=bool(metadata.get("ladder_expect_evidence", False)),
    )
    if payload.get("system") is not None:
        sysblocks = _content_blocks(payload["system"])
        graph.turns.append(Turn("system-0000", "system", sysblocks))

    turn_index = 0
    for index, msg in enumerate(messages):
        if not isinstance(msg, dict) or msg.get("role") not in ("user", "assistant"):
            raise NormalizeError(f"messages[{index}] role must be user or assistant")
        blocks: list[Any] = []
        content = msg.get("content", "")
        items = content if isinstance(content, list) else [{"type": "text", "text": content}]
        for block_index, item in enumerate(items):
            if isinstance(item, str):
                blocks.append(TextBlock(item))
                continue
            if not isinstance(item, dict):
                blocks.append(OpaqueBlock("opaque", item))
                continue
            kind = item.get("type")
            if kind == "text" and isinstance(item.get("text"), str):
                blocks.append(TextBlock(item["text"]))
            elif kind == "tool_use":
                name = item.get("name")
                call_id = item.get("id")
                args = item.get("input", {})
                if (not isinstance(name, str) or not name or len(name) > 128
                        or not isinstance(call_id, str) or not call_id or len(call_id) > 256
                        or any(ord(char) < 32 for char in name + call_id)):
                    raise NormalizeError("Anthropic tool_use requires a bounded string ID and name")
                if not isinstance(args, dict):
                    raise NormalizeError("Anthropic tool_use input must be a JSON object")
                try:
                    serialized_args = json.dumps(args, ensure_ascii=False, separators=(",", ":"), allow_nan=False)
                except (TypeError, ValueError) as exc:
                    raise NormalizeError("Anthropic tool_use input must contain only JSON values") from exc
                if len(serialized_args) > 256_000:
                    raise NormalizeError("Anthropic tool_use input exceeds configured size limit")
                blocks.append(ToolCall(call_id, name, serialized_args, block_index))
            elif kind == "tool_result":
                call_id = item.get("tool_use_id")
                if not isinstance(call_id, str) or not call_id or len(call_id) > 256 or any(ord(c) < 32 for c in call_id):
                    raise NormalizeError("Anthropic tool_result requires a bounded string tool_use_id")
                is_error = item.get("is_error", False)
                if type(is_error) is not bool:
                    raise NormalizeError("Anthropic tool_result is_error must be a JSON boolean")
                blocks.append(ToolResult(call_id, item.get("content", ""), is_error))
            else:
                blocks.append(OpaqueBlock(str(kind or "opaque"), dict(item)))
        # Anthropic tool results are in user messages but become first-class tool nodes.
        pending: list[Any] = []
        result_index = 0
        for block in blocks:
            if isinstance(block, ToolResult):
                if pending:
                    graph.turns.append(Turn(f"turn-{turn_index:04d}", str(msg["role"]), pending))
                    turn_index += 1
                    pending = []
                graph.turns.append(Turn(f"tool-result-{turn_index:04d}-{result_index}", "tool", [block]))
                turn_index += 1
                result_index += 1
            else:
                pending.append(block)
        if pending or not blocks:
            graph.turns.append(Turn(f"turn-{turn_index:04d}", str(msg["role"]), pending))
            turn_index += 1
    return graph


def anthropic_tools_to_openai(tools: list[dict[str, Any]]) -> list[dict[str, Any]]:
    return [{"type": "function", "function": {
        "name": t["name"], "description": t.get("description", ""),
        "parameters": t.get("input_schema", {"type": "object"})}}
        for t in tools if isinstance(t, dict) and t.get("name")]


def anthropic_choice_to_openai(choice: Any) -> Any:
    if not isinstance(choice, dict):
        return "auto"
    kind = choice.get("type")
    if kind == "auto":
        return "auto"
    if kind == "any":
        return "required"
    if kind == "tool":
        return {"type": "function", "function": {"name": choice.get("name", "")}}
    return "auto"
