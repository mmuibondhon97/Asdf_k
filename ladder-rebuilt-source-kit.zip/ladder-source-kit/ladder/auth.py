from __future__ import annotations

import hmac
from typing import Sequence


def bearer_value(authorization: str | None, api_key: str | None = None) -> str:
    raw = (authorization or "").strip()
    if raw:
        scheme, sep, token = raw.partition(" ")
        if sep:
            return token.strip() if scheme.lower() == "bearer" else ""
        return raw
    return (api_key or "").strip()


def check_token(authorization: str | None, tokens: Sequence[str], api_key: str | None = None) -> bool:
    candidate = bearer_value(authorization, api_key)
    if not candidate or not tokens:
        return False
    candidate_b = candidate.encode("utf-8", errors="surrogatepass")
    matched = False
    for token in tokens:
        if token:
            matched |= hmac.compare_digest(candidate_b, token.encode("utf-8", errors="surrogatepass"))
    return matched
