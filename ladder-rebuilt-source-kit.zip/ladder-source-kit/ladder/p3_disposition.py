from __future__ import annotations

from ladder.types import Action, Classification, Disposition, OutcomeClass


def decide(classification: Classification, same_lane_retries: int) -> Disposition:
    category = classification.category
    if category in (OutcomeClass.OK, OutcomeClass.C5_EVIDENCE):
        return Disposition(Action.RETURN, "complete or explicitly evidence-limited response", 200)
    if category == OutcomeClass.C1_TRANSPORT:
        if same_lane_retries < 1:
            return Disposition(Action.RETRY_SAME, "one bounded retry for transport failure", 502)
        return Disposition(Action.TRY_NEXT_COMPATIBLE, "same-lane retry exhausted", 502)
    if category == OutcomeClass.C3_INCOMPLETE:
        if same_lane_retries < 1:
            return Disposition(Action.RETRY_SAME, "one identical retry for an uncommitted incomplete response", 502)
        return Disposition(Action.TRY_NEXT_COMPATIBLE, "same-lane incomplete retry exhausted", 502)
    if category == OutcomeClass.C4_CAPABILITY:
        return Disposition(Action.TRY_NEXT_COMPATIBLE,
                           "required tool contract not satisfied; preserve request and try a compatible lane", 409)
    if category == OutcomeClass.C2_PROVIDER_POLICY:
        return Disposition(Action.ERROR, "provider policy decision preserved; no automatic override", 422)
    if category == OutcomeClass.C6_PROVIDER_CONFIG:
        return Disposition(Action.ERROR, "provider authentication/configuration failure is not retryable", 502)
    if category == OutcomeClass.C7_INVALID_REQUEST:
        return Disposition(Action.ERROR, "invalid upstream request; routing cannot repair it", 400)
    return Disposition(Action.ERROR, "unhandled classification", 500)
