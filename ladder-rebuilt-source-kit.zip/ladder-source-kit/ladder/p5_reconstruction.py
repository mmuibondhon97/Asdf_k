from __future__ import annotations

import json
import time
from dataclasses import dataclass, field
from typing import Any, AsyncIterator

from ladder.jsonutil import strict_json_object
from ladder.types import ProviderResult, ToolCall


def getv(obj: Any, name: str, default: Any = None) -> Any:
    return obj.get(name, default) if isinstance(obj, dict) else getattr(obj, name, default)


@dataclass
class _PartialTool:
    call_id: str = ""
    call_type: str = "function"
    name: str = ""
    arguments: str = ""


@dataclass
class ToolCallAccumulator:
    """Reassembles OpenAI streaming tool deltas by choice and tool index."""
    max_argument_chars: int = 256_000
    max_total_argument_chars: int = 1_000_000
    max_tool_calls: int = 32
    _parts: dict[tuple[int, int], _PartialTool] = field(default_factory=dict)

    def feed(self, choice_index: int, deltas: list[Any]) -> None:
        for delta in deltas or []:
            index = getv(delta, "index")
            if isinstance(index, bool) or not isinstance(index, int) or not 0 <= index < self.max_tool_calls:
                raise ValueError("tool-call delta index must be a bounded non-negative integer")
            key = (int(choice_index), index)
            if key not in self._parts and len(self._parts) >= self.max_tool_calls:
                raise ValueError("tool-call count exceeded configured limit")
            part = self._parts.setdefault(key, _PartialTool())
            call_id = getv(delta, "id")
            call_type = getv(delta, "type")
            fn = getv(delta, "function", {}) or {}
            name = getv(fn, "name")
            args = getv(fn, "arguments")
            if call_id is not None:
                if not isinstance(call_id, str) or not call_id:
                    raise ValueError("tool-call ID must be a non-empty string")
                # IDs are generally provided once. Repetition must agree.
                if part.call_id and part.call_id != call_id:
                    raise ValueError(f"conflicting tool-call id at index {index}")
                part.call_id = call_id
                if len(part.call_id) > 256 or any(ord(char) < 32 for char in part.call_id):
                    raise ValueError("tool-call ID is invalid or exceeds configured size limit")
            if call_type:
                if str(call_type) != "function":
                    raise ValueError("only function tool calls are supported")
                part.call_type = str(call_type)
            if name is not None:
                if not isinstance(name, str) or not name:
                    raise ValueError("tool function name must be a non-empty string")
                part.name += name
                if len(part.name) > 128 or any(ord(char) < 32 for char in part.name):
                    raise ValueError("tool function name is invalid or exceeds configured size limit")
            if args is not None:
                if not isinstance(args, str):
                    raise ValueError("tool-call argument fragments must be strings")
                part.arguments += args
                if len(part.arguments) > self.max_argument_chars:
                    raise ValueError("tool arguments exceeded configured size limit")
                if sum(len(item.arguments) for item in self._parts.values()) > self.max_total_argument_chars:
                    raise ValueError("aggregate tool arguments exceeded configured size limit")

    def finalize(self) -> list[ToolCall]:
        result: list[ToolCall] = []
        for (choice_index, tool_index), part in sorted(self._parts.items()):
            if choice_index != 0:
                raise ValueError("only one choice (n=1) is supported")
            if not part.call_id or not part.name or not part.arguments:
                raise ValueError(f"tool call at index {tool_index} is incomplete")
            # JSON object validity is required before the call is delivered to a harness.
            strict_json_object(part.arguments, f"tool arguments at index {tool_index}")
            result.append(ToolCall(part.call_id, part.name, part.arguments, tool_index))
        return result


async def collect_litellm_stream(stream: AsyncIterator[Any], max_chars: int) -> ProviderResult:
    text_parts: list[str] = []
    acc = ToolCallAccumulator()
    finish_reason: str | None = None
    provider_refusal: str | None = None
    usage: dict[str, Any] = {}
    chars = 0
    async for chunk in stream:
        choices = getv(chunk, "choices", []) or []
        for choice in choices:
            choice_index = int(getv(choice, "index", 0) or 0)
            if choice_index != 0:
                raise ValueError("only one provider choice (n=1) is supported")
            delta = getv(choice, "delta", {}) or {}
            content = getv(delta, "content")
            if isinstance(content, str) and content:
                chars += len(content)
                if chars > max_chars:
                    raise ValueError("upstream response exceeded configured response-size limit")
                text_parts.append(content)
            refusal = getv(delta, "refusal")
            if refusal:
                provider_refusal = str(refusal)
            tool_deltas = getv(delta, "tool_calls", []) or []
            acc.feed(choice_index, tool_deltas)
            reason = getv(choice, "finish_reason")
            if reason is not None:
                finish_reason = str(reason)
        chunk_usage = getv(chunk, "usage")
        if chunk_usage is not None:
            usage = chunk_usage if isinstance(chunk_usage, dict) else {
                "prompt_tokens": getv(chunk_usage, "prompt_tokens"),
                "completion_tokens": getv(chunk_usage, "completion_tokens"),
                "total_tokens": getv(chunk_usage, "total_tokens"),
            }
    if finish_reason is None:
        return ProviderResult("".join(text_parts), [], None, usage, provider_refusal, False)
    try:
        calls = acc.finalize()
    except ValueError:
        return ProviderResult("".join(text_parts), [], finish_reason, usage, provider_refusal, False)
    return ProviderResult("".join(text_parts), calls, finish_reason, usage, provider_refusal, True)


def extract_nonstreaming(response: Any, max_chars: int = 2_000_000) -> ProviderResult:
    choices = getv(response, "choices", []) or []
    if not choices:
        return ProviderResult(stream_complete=False)
    if len(choices) != 1:
        raise ValueError("provider returned multiple choices; Ladder only supports n=1")
    choice = choices[0]
    message = getv(choice, "message", {}) or {}
    content = getv(message, "content")
    if isinstance(content, list):
        text = "".join(str(getv(x, "text", "")) for x in content if getv(x, "type") == "text")
    else:
        text = content if isinstance(content, str) else ""
    if len(text) > max_chars:
        raise ValueError("upstream response exceeded configured response-size limit")
    raw_calls = getv(message, "tool_calls", []) or []
    if not isinstance(raw_calls, list):
        raise ValueError("provider tool_calls must be an array")
    calls: list[ToolCall] = []
    if len(raw_calls) > 32:
        raise ValueError("tool-call count exceeded configured limit")
    total_argument_chars = 0
    for index, call in enumerate(raw_calls):
        if getv(call, "type", "function") != "function":
            raise ValueError("only function tool calls are supported")
        fn = getv(call, "function", {}) or {}
        args = getv(fn, "arguments", "{}")
        if isinstance(args, dict):
            args = json.dumps(args, ensure_ascii=False, separators=(",", ":"))
        if not isinstance(args, str):
            raise ValueError("provider returned non-string tool arguments")
        strict_json_object(args, "tool call arguments")
        call_id, name = str(getv(call, "id", "")), str(getv(fn, "name", ""))
        if (not call_id or len(call_id) > 256 or not name or len(name) > 128
                or any(ord(char) < 32 for char in call_id + name)):
            raise ValueError("tool call must include a bounded ID and function name")
        if len(args) > 256_000:
            raise ValueError("tool arguments exceeded configured size limit")
        total_argument_chars += len(args)
        if total_argument_chars > 1_000_000:
            raise ValueError("aggregate tool arguments exceeded configured size limit")
        calls.append(ToolCall(call_id, name, args, index))
    usage_obj = getv(response, "usage", {}) or {}
    usage = usage_obj if isinstance(usage_obj, dict) else {
        "prompt_tokens": getv(usage_obj, "prompt_tokens"),
        "completion_tokens": getv(usage_obj, "completion_tokens"),
        "total_tokens": getv(usage_obj, "total_tokens"),
    }
    return ProviderResult(text, calls, getv(choice, "finish_reason"), usage,
                          getv(message, "refusal"), True)


def _sse(obj: dict[str, Any]) -> str:
    return "data: " + json.dumps(obj, ensure_ascii=False, separators=(",", ":")) + "\n\n"


def openai_sse(result: ProviderResult, model: str, run_id: str,
                include_usage: bool = False, classification: str = "OK") -> list[str]:
    """Render a fully validated response into well-formed Chat Completions SSE."""
    chunk_id = "chatcmpl-" + run_id[:24]
    frames = [_sse({"id": chunk_id, "object": "chat.completion.chunk", "model": model,
                    "choices": [{"index": 0, "delta": {"role": "assistant"}, "finish_reason": None}]})]
    if result.text:
        frames.append(_sse({"id": chunk_id, "object": "chat.completion.chunk", "model": model,
                            "choices": [{"index": 0, "delta": {"content": result.text}, "finish_reason": None}]}))
    policy_result = classification == "C2_PROVIDER_POLICY" or bool(result.provider_refusal)
    if policy_result and result.provider_refusal:
        frames.append(_sse({"id": chunk_id, "object": "chat.completion.chunk", "model": model,
                            "choices": [{"index": 0, "delta": {"refusal": result.provider_refusal},
                                         "finish_reason": None}]}))
    if result.tool_calls and not policy_result:
        calls = [{"index": c.tool_index, "id": c.call_id, "type": "function",
                  "function": {"name": c.name, "arguments": c.arguments_json}}
                 for c in result.tool_calls]
        frames.append(_sse({"id": chunk_id, "object": "chat.completion.chunk", "model": model,
                            "choices": [{"index": 0, "delta": {"tool_calls": calls}, "finish_reason": None}]}))
    finish = ("content_filter" if policy_result
              else "tool_calls" if result.tool_calls else "stop")
    frames.append(_sse({"id": chunk_id, "object": "chat.completion.chunk", "model": model,
                        "choices": [{"index": 0, "delta": {}, "finish_reason": finish}]}))
    if include_usage:
        frames.append(_sse({"id": chunk_id, "object": "chat.completion.chunk", "model": model,
                            "choices": [], "usage": result.usage}))
    frames.append("data: [DONE]\n\n")
    return frames


def to_openai_response(result: ProviderResult, model: str, run_id: str,
                       lane_id: str, attempts: int, classification: str) -> dict[str, Any]:
    message: dict[str, Any] = {"role": "assistant", "content": result.text or None}
    if classification == "C2_PROVIDER_POLICY" or result.provider_refusal:
        message["refusal"] = result.provider_refusal or result.text or "Provider policy decision"
    policy_result = classification == "C2_PROVIDER_POLICY" or bool(result.provider_refusal)
    if result.tool_calls and not policy_result:
        message["tool_calls"] = [{"id": c.call_id, "type": "function",
                                  "function": {"name": c.name, "arguments": c.arguments_json}}
                                 for c in result.tool_calls]
    return {
        "id": "chatcmpl-" + run_id[:24], "object": "chat.completion", "created": int(time.time()),
        "model": model,
        "choices": [{"index": 0, "message": message,
                     "finish_reason": ("content_filter" if classification == "C2_PROVIDER_POLICY" or result.provider_refusal
                                       else "tool_calls" if result.tool_calls else "stop")}],
        "usage": result.usage,
        "ladder": {"run_id": run_id, "lane": lane_id, "attempts": attempts,
                   "classification": classification},
    }


def to_anthropic_response(result: ProviderResult, model: str, run_id: str,
                          lane_id: str, attempts: int, classification: str) -> dict[str, Any]:
    blocks: list[dict[str, Any]] = []
    policy_result = classification == "C2_PROVIDER_POLICY" or bool(result.provider_refusal)
    if result.text:
        blocks.append({"type": "text", "text": result.text})
    elif result.provider_refusal:
        blocks.append({"type": "text", "text": result.provider_refusal})
    if not policy_result:
        for call in result.tool_calls:
            blocks.append({"type": "tool_use", "id": call.call_id, "name": call.name,
                           "input": json.loads(call.arguments_json)})
    return {
        "id": "msg_" + run_id[:24], "type": "message", "role": "assistant",
        "content": blocks, "model": model,
        "stop_reason": "tool_use" if result.tool_calls and not policy_result else "end_turn",
        "stop_sequence": None,
        "usage": {"input_tokens": result.usage.get("prompt_tokens", 0),
                  "output_tokens": result.usage.get("completion_tokens", 0)},
    }


def anthropic_sse(result: ProviderResult, model: str, run_id: str,
                  lane_id: str, attempts: int, classification: str) -> list[str]:
    message = to_anthropic_response(result, model, run_id, lane_id, attempts, classification)
    content = message["content"]
    frames = ["event: message_start\ndata: " + json.dumps({
        "type": "message_start", "message": {k: v for k, v in message.items() if k not in ("content", "stop_reason", "_ladder")}
        | {"content": [], "stop_reason": None, "stop_sequence": None}}, ensure_ascii=False) + "\n\n"]
    for index, block in enumerate(content):
        frames.append("event: content_block_start\ndata: " + json.dumps({
            "type": "content_block_start", "index": index,
            "content_block": ({"type": "text", "text": ""} if block["type"] == "text"
                              else {"type": "tool_use", "id": block["id"], "name": block["name"], "input": {}})},
            ensure_ascii=False) + "\n\n")
        if block["type"] == "text":
            delta = {"type": "text_delta", "text": block["text"]}
        else:
            delta = {"type": "input_json_delta", "partial_json": json.dumps(block["input"], ensure_ascii=False, separators=(",", ":"))}
        frames.append("event: content_block_delta\ndata: " + json.dumps({
            "type": "content_block_delta", "index": index, "delta": delta}, ensure_ascii=False) + "\n\n")
        frames.append("event: content_block_stop\ndata: " + json.dumps({
            "type": "content_block_stop", "index": index}) + "\n\n")
    frames.append("event: message_delta\ndata: " + json.dumps({
        "type": "message_delta", "delta": {"stop_reason": message["stop_reason"], "stop_sequence": None},
        "usage": message["usage"]}, ensure_ascii=False) + "\n\n")
    frames.append("event: message_stop\ndata: {\"type\":\"message_stop\"}\n\n")
    return frames


def error_sse(error: dict[str, Any], anthropic: bool = False) -> str:
    if anthropic:
        return "event: error\ndata: " + json.dumps({"type": "error", "error": error}, ensure_ascii=False) + "\n\n"
    return _sse({"error": error})
