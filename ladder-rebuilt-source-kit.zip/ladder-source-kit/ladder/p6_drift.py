from __future__ import annotations

import math


def drift_z_score(baseline_rate: float, baseline_n: int,
                  current_rate: float, current_n: int) -> float:
    """Two-sample binomial-proportion z score for a rolling success-rate baseline."""
    if baseline_n <= 0 or current_n <= 0:
        return 0.0
    p0 = min(max(float(baseline_rate), 0.0), 1.0)
    p1 = min(max(float(current_rate), 0.0), 1.0)
    variance = p0 * (1.0 - p0) / baseline_n + p1 * (1.0 - p1) / current_n
    if variance <= 0:
        return 0.0 if p0 == p1 else math.inf
    return abs(p1 - p0) / math.sqrt(variance)


def drift_alarm(baseline_rate: float, baseline_n: int, current_rate: float,
                current_n: int, sigma: float = 2.0) -> bool:
    if sigma <= 0:
        raise ValueError("sigma threshold must be positive")
    return drift_z_score(baseline_rate, baseline_n, current_rate, current_n) > sigma
