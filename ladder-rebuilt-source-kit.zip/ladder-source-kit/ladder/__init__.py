"""ladder: a loopback-only, evidence-driven LLM protocol reliability proxy."""
__version__ = "0.1.0"
