"""Regression coverage for protocol-edge cases found during the rebuild audit."""

import asyncio

import pytest

from ladder.p1_normalize import NormalizeError, normalize_anthropic, normalize_openai
from ladder.p4_lanes import LOCAL_PRESENCE_KEY, build_lane_kwargs, rank_lanes
from ladder.p5_reconstruction import ToolCallAccumulator, collect_litellm_stream, extract_nonstreaming
from ladder.types import Lane, LaneCapabilities, ToolResult, Turn, CanonicalTurnGraph


def test_tool_error_round_trips_without_nonstandard_openai_is_error_field():
    graph = CanonicalTurnGraph("c", [Turn("t", "tool", [ToolResult("call_1", "permission denied", True)])])
    message = graph.to_openai_messages()[0]
    assert message["role"] == "tool"
    assert message["tool_call_id"] == "call_1"
    assert "is_error" not in message
    assert "[Tool execution reported an error]" in message["content"]
    assert "permission denied" in message["content"]


@pytest.mark.parametrize("arguments", ["[]", '"text"', "null", "42"])
def test_openai_tool_arguments_must_be_json_objects(arguments):
    with pytest.raises(NormalizeError, match="JSON object"):
        normalize_openai({"messages": [{"role": "assistant", "tool_calls": [{
            "id": "call_1", "type": "function",
            "function": {"name": "run", "arguments": arguments},
        }]}]})


def test_anthropic_tool_use_input_must_be_object():
    with pytest.raises(NormalizeError, match="JSON object"):
        normalize_anthropic({"messages": [{"role": "assistant", "content": [{
            "type": "tool_use", "id": "toolu_1", "name": "run", "input": ["not", "object"],
        }]}]})


@pytest.mark.parametrize("index", [-1, True, "0", 32])
def test_streaming_tool_index_must_be_bounded_integer(index):
    acc = ToolCallAccumulator()
    with pytest.raises(ValueError, match="index"):
        acc.feed(0, [{"index": index, "id": "c", "function": {"name": "f", "arguments": "{}"}}])


def test_streaming_rejects_non_function_tool_kind():
    acc = ToolCallAccumulator()
    with pytest.raises(ValueError, match="only function"):
        acc.feed(0, [{"index": 0, "type": "custom", "id": "c",
                      "function": {"name": "f", "arguments": "{}"}}])


@pytest.mark.parametrize("arguments", ["[]", '"str"', "null", "1"])
def test_streaming_rejects_non_object_arguments_at_finalize(arguments):
    acc = ToolCallAccumulator()
    acc.feed(0, [{"index": 0, "id": "c", "type": "function",
                  "function": {"name": "f", "arguments": arguments}}])
    with pytest.raises(ValueError, match="JSON object"):
        acc.finalize()


def test_nonstream_provider_rejects_non_array_tool_calls():
    response = {"choices": [{"message": {"content": "x", "tool_calls": {"bad": True}},
                             "finish_reason": "stop"}]}
    with pytest.raises(ValueError, match="array"):
        extract_nonstreaming(response)


def test_nonstream_provider_rejects_non_object_tool_arguments():
    response = {"choices": [{"message": {"tool_calls": [{"id": "c", "type": "function",
                 "function": {"name": "run", "arguments": "[]"}}]},
                 "finish_reason": "tool_calls"}]}
    with pytest.raises(ValueError, match="JSON object"):
        extract_nonstreaming(response)


def test_keyless_local_openai_lane_receives_only_presence_placeholder():
    lane = Lane("local", "openai", "openai/local-model", needs_key=False,
                base_url="http://127.0.0.1:8091/v1", locality="local")
    kwargs = build_lane_kwargs(lane, [], {}, 30, 128)
    assert kwargs["api_key"] == LOCAL_PRESENCE_KEY
    assert kwargs["api_base"] == lane.base_url


def test_max_completion_tokens_and_common_sampling_options_are_forwarded():
    lane = Lane("a", "openai", "openai/model", needs_key=False)
    request = {"max_completion_tokens": 75, "top_k": 20, "frequency_penalty": 0.2,
               "presence_penalty": 0.1, "parallel_tool_calls": False,
               "stream_options": {"include_usage": True}}
    kwargs = build_lane_kwargs(lane, [], request, 30, 100, stream=True)
    assert kwargs["max_completion_tokens"] == 75
    assert "max_tokens" not in kwargs
    assert kwargs["top_k"] == 20
    assert kwargs["frequency_penalty"] == 0.2
    assert kwargs["presence_penalty"] == 0.1
    assert kwargs["parallel_tool_calls"] is False
    assert kwargs["stream_options"] == {"include_usage": True}


def test_tool_choice_none_does_not_require_or_forward_tool_capability():
    lane = Lane("no-tools", "openai", "openai/model", needs_key=False,
                capabilities=LaneCapabilities(tools=False, streaming=True))
    request = {"tools": [{"type": "function", "function": {"name": "f"}}],
               "tool_choice": "none"}
    kwargs = build_lane_kwargs(lane, [], request, 30, 100)
    assert "tools" not in kwargs
    assert "tool_choice" not in kwargs
    assert rank_lanes([lane], {}, require_tools=False) == [lane]


def test_cold_start_lane_order_is_stable_and_not_cost_biased():
    expensive = Lane("first", "openai", "m1", needs_key=False, cost_weight=100)
    cheap = Lane("second", "openai", "m2", needs_key=False, cost_weight=0)
    assert [lane.id for lane in rank_lanes([expensive, cheap], {})] == ["first", "second"]


def test_stream_with_malformed_tool_args_is_marked_incomplete_not_callable():
    async def source():
        yield {"choices": [{"index": 0, "delta": {"tool_calls": [{
            "index": 0, "id": "c", "type": "function",
            "function": {"name": "run", "arguments": "[]"},
        }]}, "finish_reason": "tool_calls"}]}
    result = asyncio.run(collect_litellm_stream(source(), 1000))
    assert result.stream_complete is False
    assert result.tool_calls == []


def test_strict_json_rejects_nonstandard_constants_and_duplicate_keys():
    with pytest.raises(NormalizeError, match="valid JSON object"):
        normalize_openai({"messages": [{"role": "assistant", "tool_calls": [{
            "id": "call_1", "type": "function",
            "function": {"name": "run", "arguments": '{"x":NaN}'},
        }]}]})
    with pytest.raises(NormalizeError, match="valid JSON object"):
        normalize_openai({"messages": [{"role": "assistant", "tool_calls": [{
            "id": "call_1", "type": "function",
            "function": {"name": "run", "arguments": '{"x":1,"x":2}'},
        }]}]})


def test_openai_tool_result_requires_string_id_and_boolean_is_error():
    for message in (
        {"role": "tool", "tool_call_id": 7, "content": "x"},
        {"role": "tool", "tool_call_id": "call_1", "content": "x", "is_error": "false"},
    ):
        with pytest.raises(NormalizeError):
            normalize_openai({"messages": [message]})


def test_openai_tool_calls_reject_unsupported_types():
    with pytest.raises(NormalizeError, match="function call"):
        normalize_openai({"messages": [{"role": "assistant", "tool_calls": [{
            "id": "call_1", "type": "custom", "function": {"name": "run", "arguments": "{}"},
        }]}]})


def test_anthropic_tool_result_requires_boolean_error_flag():
    with pytest.raises(NormalizeError, match="JSON boolean"):
        normalize_anthropic({"messages": [{"role": "user", "content": [{
            "type": "tool_result", "tool_use_id": "toolu_1", "content": "bad", "is_error": 1,
        }]}]})


def test_strict_ingress_rejects_nonstandard_json_constants_and_conflicting_token_fields():
    from ladder.p0_ingress import IngressError, parse_body, request_context
    from ladder.config import Settings

    with pytest.raises(IngressError, match="valid UTF-8 JSON"):
        parse_body(b'{"temperature":NaN}', 1024)
    with pytest.raises(IngressError, match="mutually exclusive"):
        request_context({}, {"max_tokens": 10, "max_completion_tokens": 10}, Settings())


def test_anthropic_tool_use_rejects_non_json_numeric_values():
    with pytest.raises(NormalizeError, match="JSON values"):
        normalize_anthropic({"messages": [{"role": "assistant", "content": [{
            "type": "tool_use", "id": "toolu_1", "name": "run", "input": {"value": float("nan")},
        }]}]})


def test_lane_config_rejects_duplicate_json_object_keys(monkeypatch, tmp_path):
    from ladder.config import Settings, load_lanes
    monkeypatch.setenv("LADDER_LANES_JSON", '[{"id":"a","id":"b","model":"openai/m","needs_key":false}]')
    settings = Settings(config_path=tmp_path / "does-not-exist.json")
    with pytest.raises(ValueError, match="valid JSON") as exc:
        load_lanes(settings)
    assert "duplicate JSON object key" in str(exc.value.__cause__)
