import json
import os
import stat

from fastapi.testclient import TestClient

from ladder.auth import check_token
from ladder.config import Settings, save_lanes
from ladder.main import AppContext, create_app
from ladder.p6_meter import FingerprintMeter
from ladder.types import Lane, LaneCapabilities


def test_auth_non_ascii_token_is_supported_and_bad_credentials_fail_closed():
    assert check_token("Bearer 秘密-token", ["秘密-token"]) is True
    assert check_token("Bearer странный", ["ascii-token"]) is False
    assert check_token(None, ["ascii-token"]) is False


def test_config_write_is_atomic_and_private(tmp_path):
    path = tmp_path / "cfg" / "lanes.json"
    settings = Settings(config_path=path)
    lane = Lane("local", "openai", "openai/local", needs_key=False,
                capabilities=LaneCapabilities(tools=True))
    save_lanes(settings, [lane])
    assert json.loads(path.read_text())["lanes"][0]["id"] == "local"
    if os.name == "posix":
        assert stat.S_IMODE(path.stat().st_mode) == 0o600
    assert not list(path.parent.glob(".ladder-*.tmp"))


def test_metrics_file_is_private(tmp_path):
    path = tmp_path / "metrics.json"
    meter = FingerprintMeter(path)
    meter.record("a", "OK", 30)
    assert path.is_file()
    if os.name == "posix":
        assert stat.S_IMODE(path.stat().st_mode) == 0o600


def test_v1_requires_token_and_health_does_not_expose_lane_names(tmp_path):
    settings = Settings(auth_tokens=("test-secret",), config_path=tmp_path / "cfg.json",
                        ledger_path=tmp_path / "ledger.jsonl", metrics_path=tmp_path / "metrics.json")
    ctx = AppContext(settings, [Lane("secret-lane", "openai", "openai/m", needs_key=False)])
    client = TestClient(create_app(ctx))
    assert client.get("/v1/models").status_code == 401
    assert client.get("/v1/models", headers={"Authorization": "Bearer test-secret"}).status_code == 200
    health = client.get("/healthz").json()
    assert "secret-lane" not in json.dumps(health)


def test_setup_mutation_requires_ui_header_and_loopback_origin(tmp_path):
    settings = Settings(config_path=tmp_path / "cfg.json", ledger_path=tmp_path / "ledger.jsonl",
                        metrics_path=tmp_path / "metrics.json")
    client = TestClient(create_app(AppContext(settings, [])), base_url="http://127.0.0.1")
    body = {"lanes": [{"id": "local", "model": "openai/local", "needs_key": False}]}
    assert client.put("/setup/config", json=body).status_code == 403
    denied = client.put("/setup/config", json=body, headers={
        "X-Ladder-UI": "1", "Origin": "https://evil.example"})
    assert denied.status_code == 403
    accepted = client.put("/setup/config", json=body, headers={"X-Ladder-UI": "1"})
    assert accepted.status_code == 200


def test_i11_non_loopback_host_rejected_for_setup(tmp_path):
    settings = Settings(config_path=tmp_path / "cfg.json", ledger_path=tmp_path / "ledger.jsonl",
                        metrics_path=tmp_path / "metrics.json")
    client = TestClient(create_app(AppContext(settings, [])), base_url="http://127.0.0.1")
    response = client.get("/setup/", headers={"Host": "attacker.example"})
    # TestClient uses an in-process peer; a hostile Host is nevertheless rejected.
    assert response.status_code == 403


def test_live_lane_probe_is_disabled_by_default(tmp_path):
    settings = Settings(auth_tokens=(), config_path=tmp_path / "cfg.json",
                        ledger_path=tmp_path / "ledger.jsonl", metrics_path=tmp_path / "metrics.json",
                        live_enabled=False)
    lane = Lane("local", "openai", "openai/test", needs_key=False)
    client = TestClient(create_app(AppContext(settings, [lane])), base_url="http://127.0.0.1")
    response = client.post("/setup/probe", json={"lane_id": "local"}, headers={"X-Ladder-UI": "1"})
    assert response.status_code == 403


def test_lane_config_rejects_truthy_string_booleans_and_remote_http():
    from ladder.config import lane_from_dict
    base = {"id": "x", "model": "openai/m", "needs_key": False}
    try:
        lane_from_dict({**base, "capabilities": {"tools": "false"}})
    except ValueError as exc:
        assert "JSON boolean" in str(exc)
    else:
        raise AssertionError("string boolean was accepted")
    try:
        lane_from_dict({**base, "base_url": "http://provider.example/v1"})
    except ValueError as exc:
        assert "HTTPS" in str(exc)
    else:
        raise AssertionError("remote HTTP endpoint was accepted")


def test_setup_editor_shows_inactive_lane_without_round_tripping_secrets(tmp_path, monkeypatch):
    from ladder.config import load_lanes
    monkeypatch.delenv("LADDER_LANE_TEST_SECRET", raising=False)
    settings = Settings(config_path=tmp_path / "cfg.json", ledger_path=tmp_path / "ledger.jsonl",
                        metrics_path=tmp_path / "metrics.json")
    saved_lane = Lane("pending", "openai", "openai/pending", api_key_env="LADDER_LANE_TEST_SECRET",
                      needs_key=True, enabled=True)
    save_lanes(settings, [saved_lane])
    assert load_lanes(settings) == []
    configured = load_lanes(settings, include_inactive=True)
    assert [lane.id for lane in configured] == ["pending"]
    client = TestClient(create_app(AppContext(settings, [], configured_lanes=configured)),
                        base_url="http://127.0.0.1")
    page = client.get("/setup/")
    assert page.status_code == 200
    assert "pending" in page.text and "missing key" in page.text
    assert "LADDER_LANE_TEST_SECRET" in page.text  # env-var name only
    assert "replace-me" not in page.text
    assert "Probe</button>" not in page.text  # inactive lane cannot be probed


def test_ledger_repairs_permissive_existing_file_mode_and_rejects_symlink(tmp_path):
    from ladder.p6_ledger import EvidenceLedger

    path = tmp_path / "ledger.jsonl"
    path.write_text("", encoding="utf-8")
    if os.name == "posix":
        path.chmod(0o644)
    EvidenceLedger(path).append({"run_id": "ledger-mode-test", "class": "OK"})
    if os.name == "posix":
        assert stat.S_IMODE(path.stat().st_mode) == 0o600

    target = tmp_path / "target.jsonl"
    target.write_text("", encoding="utf-8")
    link = tmp_path / "link.jsonl"
    link.symlink_to(target)
    try:
        EvidenceLedger(link).append({"run_id": "ledger-symlink-test"})
    except OSError as exc:
        assert "symlink" in str(exc).lower() or "symbolic link" in str(exc).lower()
    else:
        raise AssertionError("ledger symlink was followed")



def test_keyless_local_setup_probe_passes_presence_key_to_litellm(tmp_path):
    calls = []
    async def completion(**kwargs):
        calls.append(kwargs)
        return {"choices": [{"message": {"content": "ok"}, "finish_reason": "stop"}]}

    settings = Settings(config_path=tmp_path / "cfg.json", ledger_path=tmp_path / "ledger.jsonl",
                        metrics_path=tmp_path / "metrics.json", live_enabled=True)
    lane = Lane("local", "openai", "openai/local", needs_key=False,
                base_url="http://127.0.0.1:8091/v1", locality="local")
    client = TestClient(create_app(AppContext(settings, [lane], completion=completion)),
                        base_url="http://127.0.0.1")
    response = client.post("/setup/probe", json={"lane_id": "local"}, headers={"X-Ladder-UI": "1"})
    assert response.status_code == 200
    from ladder.p4_lanes import LOCAL_PRESENCE_KEY
    assert calls[0]["api_key"] == LOCAL_PRESENCE_KEY
    assert calls[0]["api_base"] == lane.base_url
