import asyncio
import json

from ladder.p5_reconstruction import (ToolCallAccumulator, anthropic_sse,
                                      collect_litellm_stream, error_sse,
                                      openai_sse, to_anthropic_response)
from ladder.types import ProviderResult


def test_tool_delta_round_trip_fragmented_arguments_and_parallel_calls():
    acc = ToolCallAccumulator()
    acc.feed(0, [
        {"index": 0, "id": "call_a", "type": "function", "function": {"name": "read_", "arguments": '{"pa'}},
        {"index": 1, "id": "call_b", "type": "function", "function": {"name": "list_files", "arguments": '{"root":"."}'}},
    ])
    acc.feed(0, [
        {"index": 0, "function": {"name": "file", "arguments": 'th":"x.py"}'}},
    ])
    calls = acc.finalize()
    assert [c.call_id for c in calls] == ["call_a", "call_b"]
    assert calls[0].name == "read_file"
    assert json.loads(calls[0].arguments_json) == {"path": "x.py"}
    assert json.loads(calls[1].arguments_json) == {"root": "."}


def test_tool_delta_rejects_incomplete_or_oversized_arguments():
    acc = ToolCallAccumulator()
    acc.feed(0, [{"index": 0, "id": "call_x", "function": {"name": "f", "arguments": "{"}}])
    try:
        acc.finalize()
    except json.JSONDecodeError:
        pass
    else:
        raise AssertionError("invalid JSON must not become a callable tool request")
    small = ToolCallAccumulator(max_argument_chars=4)
    try:
        small.feed(0, [{"index": 0, "function": {"arguments": "12345"}}])
    except ValueError as exc:
        assert "size limit" in str(exc)
    else:
        raise AssertionError("tool argument size limit not enforced")


def test_stream_requires_terminal_finish_reason_and_complete_json():
    async def source():
        yield {"choices": [{"index": 0, "delta": {"content": "partial"}, "finish_reason": None}]}
    result = asyncio.run(collect_litellm_stream(source(), 1000))
    assert result.stream_complete is False


def test_openai_stream_contains_reconstructed_tool_array_and_single_done():
    result = ProviderResult("", [
        __import__("ladder.types", fromlist=["ToolCall"]).ToolCall("call_1", "run", '{"cmd":"ls"}', 0)
    ], "tool_calls", {}, None, True)
    frames = openai_sse(result, "model-x", "a" * 32)
    joined = "".join(frames)
    assert '"tool_calls"' in joined
    assert '"arguments":"{\\"cmd\\":\\"ls\\"}"' in joined
    assert joined.count("data: [DONE]") == 1


def test_error_stream_never_emits_done():
    assert "[DONE]" not in error_sse({"type": "failed", "message": "x"})


def test_anthropic_stream_uses_named_lifecycle_events():
    result = ProviderResult("ok", [], "stop", {"prompt_tokens": 1, "completion_tokens": 2})
    frames = anthropic_sse(result, "model-x", "b" * 32, "lane-a", 1, "OK")
    joined = "".join(frames)
    for name in ("message_start", "content_block_start", "content_block_delta", "message_delta", "message_stop"):
        assert f"event: {name}" in joined


def test_anthropic_response_maps_tool_arguments_to_object():
    from ladder.types import ToolCall
    response = to_anthropic_response(ProviderResult("", [ToolCall("t1", "read", '{"p":"x"}')], "tool_calls"),
                                     "m", "c" * 32, "lane", 1, "OK")
    assert response["content"][0] == {"type": "tool_use", "id": "t1", "name": "read", "input": {"p": "x"}}


def test_i3_tool_deltas_are_reconstructed_before_client_frame():
    from ladder.types import ToolCall
    result = ProviderResult("tail", [ToolCall("c", "run", '{"x":1}', 0)], "tool_calls")
    joined = "".join(openai_sse(result, "m", "d" * 32))
    assert '"name":"run"' in joined
    assert '"arguments":"{\\"x\\":1}"' in joined


def test_i2_tail_content_is_preserved_exactly_once():
    text = "answer body\n\nfinal tail sentence."
    frames = openai_sse(ProviderResult(text=text, finish_reason="stop"), "m", "e" * 32)
    import json

    emitted = []
    for frame in frames:
        if not frame.startswith("data: "):
            continue
        payload = frame[len("data: "):].strip()
        if payload == "[DONE]":
            continue
        event = json.loads(payload)
        for choice in event.get("choices", []):
            content = choice.get("delta", {}).get("content")
            if content:
                emitted.append(content)
    assert "".join(emitted) == text
    assert sum(frame == "data: [DONE]\n\n" for frame in frames) == 1


def test_provider_stream_rejects_multiple_choices_instead_of_merging():
    import asyncio
    from ladder.p5_reconstruction import collect_litellm_stream

    async def source():
        yield {"choices": [
            {"index": 0, "delta": {"content": "first"}, "finish_reason": "stop"},
            {"index": 1, "delta": {"content": "second"}, "finish_reason": "stop"},
        ]}

    try:
        asyncio.run(collect_litellm_stream(source(), 1024))
    except ValueError as exc:
        assert "n=1" in str(exc)
    else:
        raise AssertionError("multiple provider choices were silently merged")


def test_policy_classification_never_emits_tool_calls():
    from ladder.types import ToolCall
    from ladder.p5_reconstruction import to_anthropic_response, to_openai_response

    result = ProviderResult("not permitted", [ToolCall("call-1", "run", "{}")],
                            "content_filter")
    openai = to_openai_response(result, "m", "f" * 32, "lane", 1, "C2_PROVIDER_POLICY")
    assert "tool_calls" not in openai["choices"][0]["message"]
    assert openai["choices"][0]["finish_reason"] == "content_filter"
    anthropic = to_anthropic_response(result, "m", "f" * 32, "lane", 1, "C2_PROVIDER_POLICY")
    assert all(block["type"] != "tool_use" for block in anthropic["content"])
    assert anthropic["stop_reason"] == "end_turn"
