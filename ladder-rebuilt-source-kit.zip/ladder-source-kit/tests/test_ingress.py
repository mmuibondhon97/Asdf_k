from ladder.config import Settings
from ladder.p0_ingress import IngressError, parse_body, request_context


def test_request_body_size_limit():
    try:
        parse_body(b'{"a":1}', 4)
    except IngressError as exc:
        assert exc.status_code == 413
    else:
        raise AssertionError("body limit was not enforced")


def test_request_context_derives_stable_opaque_session_affinity():
    settings = Settings(output_token_budget=256, deadline_seconds=5)
    body = {"messages": [{"role": "user", "content": "same initial task"}], "max_tokens": 40}
    one = request_context({}, body, settings)
    two = request_context({}, body, settings)
    assert one.session_id == two.session_id
    assert "same initial task" not in one.session_id
    assert one.output_token_budget == 40


def test_invalid_token_budget_rejected():
    settings = Settings(output_token_budget=256)
    try:
        request_context({}, {"messages": [], "max_tokens": "2.5"}, settings)
    except IngressError:
        pass
    else:
        raise AssertionError("fractional output token budget was accepted")


def test_startup_refuses_non_loopback_bind(monkeypatch):
    monkeypatch.setenv("LADDER_BIND_HOST", "0.0.0.0")
    try:
        Settings.from_env()
    except ValueError as exc:
        assert "127.0.0.1" in str(exc)
    else:
        raise AssertionError("non-loopback bind was accepted")
