from pathlib import Path

from manage import _direct_pins, _parse_hash_lock


def test_hash_lock_parser_accepts_real_sha256_shape_and_continuations(tmp_path):
    lock = tmp_path / "requirements.lock"
    lock.write_text(
        "fastapi==0.165.0 \\\n    --hash=sha256:" + "a" * 64 + " \\\n    --hash=sha256:" + "b" * 64 + "\n",
        encoding="utf-8",
    )
    entries, errors = _parse_hash_lock(lock)
    assert not errors
    assert entries["fastapi"][0] == "0.165.0"
    assert len(entries["fastapi"][1]) == 2


def test_hash_lock_parser_rejects_missing_hash(tmp_path):
    lock = tmp_path / "requirements.lock"
    lock.write_text("fastapi==0.165.0\n", encoding="utf-8")
    entries, errors = _parse_hash_lock(lock)
    assert "fastapi" in entries
    assert any("no valid SHA-256" in error for error in errors)


def test_direct_pins_follow_recursive_requirements_includes(tmp_path):
    (tmp_path / "base.txt").write_text("fastapi==0.165.0\n", encoding="utf-8")
    (tmp_path / "dev.txt").write_text("-r base.txt\npytest==9.2.0\n", encoding="utf-8")
    pins, errors = _direct_pins(tmp_path / "dev.txt")
    assert not errors
    assert pins == {"fastapi": "0.165.0", "pytest": "9.2.0"}


def test_manifest_wheels_verifies_transfer_and_lock_uses_real_wheel_hash(tmp_path):
    import hashlib
    import subprocess
    from manage import _manifest_wheels, _write_lock_from_wheels

    wheelhouse = tmp_path / "wheelhouse"
    wheelhouse.mkdir()
    wheel = wheelhouse / "demo_pkg-1.0-py3-none-any.whl"
    payload = b"synthetic wheel fixture bytes"
    wheel.write_bytes(payload)
    digest = hashlib.sha256(payload).hexdigest()
    (wheelhouse / "MANIFEST.sha256").write_text(f"{digest}  {wheel.name}\n", encoding="utf-8")

    artifacts, errors = _manifest_wheels(wheelhouse)
    assert not errors and artifacts == [wheel]
    source = tmp_path / "requirements.txt"
    source.write_text("demo-pkg==1.0\n", encoding="utf-8")
    lock = tmp_path / "requirements.lock"
    assert _write_lock_from_wheels(source, lock, artifacts) == 0
    assert digest in lock.read_text(encoding="utf-8")


def test_manifest_wheels_rejects_tampered_artifact(tmp_path):
    from manage import _manifest_wheels
    wheelhouse = tmp_path / "wheelhouse"
    wheelhouse.mkdir()
    wheel = wheelhouse / "demo_pkg-1.0-py3-none-any.whl"
    wheel.write_bytes(b"original")
    import hashlib
    digest = hashlib.sha256(wheel.read_bytes()).hexdigest()
    (wheelhouse / "MANIFEST.sha256").write_text(f"{digest}  {wheel.name}\n", encoding="utf-8")
    wheel.write_bytes(b"tampered")
    artifacts, errors = _manifest_wheels(wheelhouse)
    assert artifacts == []
    assert any("manifest failed" in error for error in errors)
