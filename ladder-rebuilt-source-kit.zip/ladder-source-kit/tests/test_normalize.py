from ladder.p1_normalize import NormalizeError, normalize_anthropic, normalize_openai
from ladder.types import TextBlock, ToolCall, ToolResult


def test_openai_graph_preserves_tool_call_and_result_nodes_with_stable_ids():
    payload = {"messages": [
        {"role": "user", "content": "inspect this file"},
        {"role": "assistant", "content": "I will inspect it.", "tool_calls": [
            {"id": "call_abc", "type": "function", "function": {"name": "read_file", "arguments": '{"path":"a.py"}'}}
        ]},
        {"role": "tool", "tool_call_id": "call_abc", "content": "I can't interpret this comment"},
    ], "tools": [{"type": "function", "function": {"name": "read_file", "parameters": {"type": "object"}}}]}
    graph = normalize_openai(payload)
    assert graph.turns[1].turn_id == "turn-0001"
    assert isinstance(graph.turns[1].blocks[1], ToolCall)
    assert graph.turns[1].blocks[1].call_id == "call_abc"
    assert isinstance(graph.turns[2].blocks[0], ToolResult)
    assert graph.turns[2].blocks[0].call_id == "call_abc"
    assert graph.to_openai_messages()[1]["tool_calls"][0]["id"] == "call_abc"


def test_anthropic_tool_use_and_tool_result_are_first_class_and_system_is_preserved():
    graph = normalize_anthropic({
        "system": "Be precise.",
        "messages": [
            {"role": "user", "content": "Read a file."},
            {"role": "assistant", "content": [
                {"type": "text", "text": "Reading."},
                {"type": "tool_use", "id": "toolu_1", "name": "read_file", "input": {"path": "x"}},
            ]},
            {"role": "user", "content": [{"type": "tool_result", "tool_use_id": "toolu_1", "content": "contents"}]},
        ],
        "tools": [{"name": "read_file", "input_schema": {"type": "object"}}],
        "tool_choice": {"type": "tool", "name": "read_file"},
    })
    assert graph.turns[0].role == "system"
    assert isinstance(graph.turns[2].blocks[1], ToolCall)
    assert graph.turns[2].blocks[1].call_id == "toolu_1"
    assert any(t.role == "tool" and isinstance(t.blocks[0], ToolResult) for t in graph.turns)
    assert graph.tool_contract.required is True
    assert graph.tool_contract.required_name == "read_file"


def test_tool_auto_is_not_a_mandatory_contract():
    graph = normalize_openai({"messages": [{"role": "user", "content": "hello"}],
                              "tools": [{"type": "function", "function": {"name": "f"}}],
                              "tool_choice": "auto"})
    assert graph.tool_contract.required is False


def test_required_tool_must_be_supplied():
    try:
        normalize_openai({"messages": [{"role": "user", "content": "go"}],
                          "tools": [{"type": "function", "function": {"name": "read"}}],
                          "ladder": {"expected_tools": ["write"]}})
    except NormalizeError as exc:
        assert "present" in str(exc)
    else:
        raise AssertionError("unknown required tool must be rejected at ingress")


def test_mixed_text_and_image_blocks_do_not_break_serialization():
    graph = normalize_anthropic({"messages": [{"role": "user", "content": [
        {"type": "text", "text": "describe"},
        {"type": "image", "source": {"type": "url", "url": "https://example.invalid/i.png"}},
    ]}]})
    content = graph.to_openai_messages()[0]["content"]
    assert content[0] == {"type": "text", "text": "describe"}
    assert content[1]["type"] == "image_url"


def test_multiple_expected_tools_are_all_required():
    graph = normalize_openai({
        "messages": [{"role": "user", "content": "read and list"}],
        "tools": [
            {"type": "function", "function": {"name": "read_file"}},
            {"type": "function", "function": {"name": "list_files"}},
        ],
        "ladder": {"expected_tools": ["read_file", "list_files"]},
    })
    assert graph.tool_contract.required_names == ("read_file", "list_files")


def test_openai_rejects_multi_choice_and_non_boolean_stream():
    from ladder.p1_normalize import NormalizeError
    base = {"messages": [{"role": "user", "content": "hi"}]}
    for payload in ({**base, "n": 2}, {**base, "stream": "false"}):
        try:
            normalize_openai(payload)
        except NormalizeError:
            pass
        else:
            raise AssertionError("ambiguous request option was accepted")


def test_openai_rejects_malformed_tool_arguments_and_unknown_selector():
    base = {"messages": [{"role": "user", "content": "run"}],
            "tools": [{"type": "function", "function": {"name": "run"}}]}
    for payload in (
        {**base, "tool_choice": {"type": "function", "function": {"name": "missing"}}},
        {"messages": [{"role": "assistant", "tool_calls": [{"id": "c", "type": "function",
          "function": {"name": "run", "arguments": "{broken"}}]}]},
    ):
        try:
            normalize_openai(payload)
        except NormalizeError:
            pass
        else:
            raise AssertionError("malformed tool request was accepted")


def test_anthropic_rejects_tool_choice_for_missing_tool():
    try:
        normalize_anthropic({"messages": [{"role": "user", "content": "go"}],
                             "tools": [], "tool_choice": {"type": "tool", "name": "missing"}})
    except NormalizeError:
        pass
    else:
        raise AssertionError("unknown Anthropic tool selector was accepted")


def test_anthropic_stream_must_be_a_json_boolean():
    try:
        normalize_anthropic({"stream": "false", "messages": [{"role": "user", "content": "hi"}]})
    except NormalizeError as exc:
        assert "JSON boolean" in str(exc)
    else:
        raise AssertionError("string stream flag was accepted")
