import asyncio
import time

from ladder.config import Settings
from ladder.p1_normalize import normalize_openai
from ladder.router import RouteEngine
from ladder.types import (Lane, LaneCapabilities, RequestContext, ToolCall)


def _settings(tmp_path, max_attempts=6, deadline=2.0):
    return Settings(max_attempts=max_attempts, deadline_seconds=deadline,
                    output_token_budget=256, max_response_chars=4096,
                    config_path=tmp_path / "config.json",
                    ledger_path=tmp_path / "ledger.jsonl",
                    metrics_path=tmp_path / "metrics.json")


def _lane(lane_id, tools=False):
    return Lane(lane_id, "openai", f"openai/{lane_id}", needs_key=False,
                capabilities=LaneCapabilities(tools=tools, streaming=True))


def _ctx(session="s-1", seconds=2, model=None):
    return RequestContext("req-1", session, time.monotonic() + seconds, 128, model)


def _ok(text="hello"):
    return {"choices": [{"message": {"content": text}, "finish_reason": "stop"}], "usage": {}}


def test_c1_transport_retries_same_lane_once_then_returns(tmp_path):
    calls = []
    async def completion(**kwargs):
        calls.append(kwargs)
        if len(calls) == 1:
            raise TimeoutError("synthetic upstream timeout")
        return _ok("recovered")
    graph = normalize_openai({"messages": [{"role": "user", "content": "hi"}]})
    result = asyncio.run(RouteEngine(_settings(tmp_path), [_lane("a")], completion).route(graph, {}, _ctx()))
    assert result.ok is True
    assert result.attempts == 2
    assert len(calls) == 2
    assert calls[0]["model"] == calls[1]["model"]


def test_c2_provider_policy_is_not_rerouted(tmp_path):
    calls = []
    async def completion(**kwargs):
        calls.append(kwargs)
        return {"choices": [{"message": {"content": "not returned"}, "finish_reason": "content_filter"}]}
    graph = normalize_openai({"messages": [{"role": "user", "content": "request"}]})
    engine = RouteEngine(_settings(tmp_path), [_lane("a"), _lane("b")], completion)
    result = asyncio.run(engine.route(graph, {}, _ctx()))
    assert result.ok is False
    assert result.error_code == "C2_PROVIDER_POLICY"
    assert len(calls) == 1


def test_c4_tries_next_tool_capable_lane_and_replays_full_graph(tmp_path):
    calls = []
    async def completion(**kwargs):
        calls.append(kwargs)
        if kwargs["model"] == "openai/a":
            return {"choices": [{"message": {"content": "I'll do it"}, "finish_reason": "stop"}]}
        return {"choices": [{"message": {"content": None, "tool_calls": [
            {"id": "call_1", "type": "function", "function": {"name": "read_file", "arguments": '{"path":"a"}'}}
        ]}, "finish_reason": "tool_calls"}]}
    graph = normalize_openai({"messages": [
        {"role": "user", "content": "read file"},
    ], "tools": [{"type": "function", "function": {"name": "read_file", "parameters": {"type": "object"}}}],
        "tool_choice": "required"})
    lanes = [_lane("a", True), _lane("b", True)]
    result = asyncio.run(RouteEngine(_settings(tmp_path), lanes, completion).route(graph,
                          {"tools": [{"type": "function", "function": {"name": "read_file"}}],
                           "tool_choice": "required"}, _ctx()))
    assert result.ok is True
    assert result.lane.id == "b"
    assert result.provider_result.tool_calls[0].call_id == "call_1"
    assert calls[0]["messages"] == calls[1]["messages"]  # complete graph replayed at turn boundary


def test_i4_session_affinity_sticks_to_successful_lane(tmp_path):
    order = []
    async def completion(**kwargs):
        order.append(kwargs["model"])
        return _ok()
    graph = normalize_openai({"messages": [{"role": "user", "content": "same session"}]})
    engine = RouteEngine(_settings(tmp_path), [_lane("b"), _lane("a")], completion)
    first = asyncio.run(engine.route(graph, {}, _ctx("session-z")))
    second = asyncio.run(engine.route(graph, {}, _ctx("session-z")))
    assert first.ok and second.ok
    assert order[0] == order[1]
    assert engine.affinity.get("session-z") == first.lane.id


def test_i7_attempt_budget_is_bounded(tmp_path):
    calls = []
    async def completion(**kwargs):
        calls.append(kwargs)
        raise TimeoutError("always fail")
    graph = normalize_openai({"messages": [{"role": "user", "content": "hi"}]})
    result = asyncio.run(RouteEngine(_settings(tmp_path, max_attempts=1), [_lane("a"), _lane("b")],
                                     completion).route(graph, {}, _ctx()))
    assert result.ok is False
    assert result.attempts == 1
    assert len(calls) == 1


def test_deadline_exhaustion_makes_no_provider_call(tmp_path):
    calls = []
    async def completion(**kwargs):
        calls.append(kwargs)
        return _ok()
    graph = normalize_openai({"messages": [{"role": "user", "content": "hi"}]})
    result = asyncio.run(RouteEngine(_settings(tmp_path), [_lane("a")], completion).route(graph, {}, _ctx(seconds=-1)))
    assert result.ok is False
    assert result.error_code == "deadline_exceeded"
    assert calls == []


def test_i6_every_attempt_appends_classified_evidence_with_run_id(tmp_path):
    from ladder.p6_ledger import EvidenceLedger
    async def completion(**kwargs):
        return {"choices": [{"message": {"content": "filtered"}, "finish_reason": "content_filter"}]}
    settings = _settings(tmp_path)
    ledger = EvidenceLedger(settings.ledger_path)
    engine = RouteEngine(settings, [_lane("a")], completion, ledger=ledger)
    graph = normalize_openai({"messages": [{"role": "user", "content": "question"}]})
    result = asyncio.run(engine.route(graph, {}, _ctx()))
    assert not result.ok
    row = __import__("json").loads(settings.ledger_path.read_text().splitlines()[0])
    assert row["run_id"] == result.run_id
    assert row["class"] == "C2_PROVIDER_POLICY"
    assert row["evidence"][0]["source"] == "provider"


def test_i9_each_persisted_metric_sample_has_a_run_id(tmp_path):
    async def completion(**kwargs):
        return _ok()
    settings = _settings(tmp_path)
    graph = normalize_openai({"messages": [{"role": "user", "content": "hi"}]})
    result = asyncio.run(RouteEngine(settings, [_lane("a")], completion).route(graph, {}, _ctx()))
    metric = __import__("json").loads(settings.metrics_path.read_text())
    event = metric["a"]["sample_events"][0]
    assert event["run_id"] == result.run_id
    assert "timestamp_unix" in event


def test_i10_adapter_registration_uses_computed_artifact_hash(tmp_path, monkeypatch):
    import hashlib
    import json
    import manage
    monkeypatch.setattr(manage, "ROOT", tmp_path)
    artifact = tmp_path / "adapter"
    artifact.mkdir()
    weights = artifact / "adapter.bin"
    weights.write_bytes(b"small-test-artifact")
    param_manifest = tmp_path / "params.json"
    param_manifest.write_text('{"rank":8}', encoding="utf-8")
    base_repo = tmp_path / "base-repo"
    base_repo.mkdir()
    import subprocess
    subprocess.run(["git", "init", str(base_repo)], check=True, capture_output=True)
    subprocess.run(["git", "-C", str(base_repo), "config", "user.email", "test@example.invalid"], check=True)
    subprocess.run(["git", "-C", str(base_repo), "config", "user.name", "Test"], check=True)
    (base_repo / "model.txt").write_text("base", encoding="utf-8")
    subprocess.run(["git", "-C", str(base_repo), "add", "model.txt"], check=True)
    subprocess.run(["git", "-C", str(base_repo), "commit", "-m", "base"], check=True, capture_output=True)
    base_commit = subprocess.check_output(["git", "-C", str(base_repo), "rev-parse", "HEAD"], text=True).strip()
    rc = manage.cmd_build(__import__("argparse").Namespace(
        base_model="example/model", base_commit=base_commit, base_repo=str(base_repo),
        artifact_dir=str(artifact), parameter_manifest=str(param_manifest)))
    assert rc == 0
    manifest_path = next((tmp_path / "artifacts").glob("*.manifest.json"))
    manifest = json.loads(manifest_path.read_text())
    assert manifest["files"][0]["sha256"] == hashlib.sha256(b"small-test-artifact").hexdigest()
    assert manifest["enabled"] is False
    assert len(manifest["run_id"]) >= 16


def test_json_mode_request_filters_lanes_without_json_capability(tmp_path):
    calls = []
    async def completion(**kwargs):
        calls.append(kwargs)
        return _ok()
    graph = normalize_openai({"messages": [{"role": "user", "content": "return JSON"}]})
    lanes = [_lane("plain", False), Lane("json", "openai", "openai/json", needs_key=False,
             capabilities=LaneCapabilities(json_mode=True, streaming=True))]
    engine = RouteEngine(_settings(tmp_path), lanes, completion)
    result = asyncio.run(engine.route(graph, {"response_format": {"type": "json_object"}}, _ctx()))
    assert result.ok is True
    assert result.lane.id == "json"
    assert [item["model"] for item in calls] == ["openai/json"]


def test_image_request_filters_text_only_lanes(tmp_path):
    calls = []
    async def completion(**kwargs):
        calls.append(kwargs)
        return _ok()
    graph = normalize_openai({"messages": [{"role": "user", "content": [
        {"type": "text", "text": "describe this"},
        {"type": "image_url", "image_url": {"url": "https://example.invalid/image.png"}},
    ]}]})
    image_lane = Lane("vision", "openai", "openai/vision", needs_key=False,
                      capabilities=LaneCapabilities(modalities=("text", "image")))
    engine = RouteEngine(_settings(tmp_path), [_lane("text-only"), image_lane], completion)
    result = asyncio.run(engine.route(graph, {}, _ctx()))
    assert result.ok is True
    assert result.lane.id == "vision"
    assert [item["model"] for item in calls] == ["openai/vision"]


def test_tool_choice_none_can_use_lane_without_tool_support(tmp_path):
    calls = []
    async def completion(**kwargs):
        calls.append(kwargs)
        return _ok()
    graph = normalize_openai({"messages": [{"role": "user", "content": "ordinary answer"}],
        "tools": [{"type": "function", "function": {"name": "run"}}],
        "tool_choice": "none"})
    engine = RouteEngine(_settings(tmp_path), [_lane("plain", False)], completion)
    result = asyncio.run(engine.route(graph, {"tools": [{"type": "function", "function": {"name": "run"}}],
                                               "tool_choice": "none"}, _ctx()))
    assert result.ok is True
    assert calls[0].get("tools") is None
    assert calls[0].get("tool_choice") is None
