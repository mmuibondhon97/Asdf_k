import json
import time

from fastapi.testclient import TestClient

from ladder.config import Settings
from ladder.main import AppContext, create_app
from ladder.types import Lane, LaneCapabilities


def test_openai_chat_completion_and_anthropic_messages_use_wire_adapters(tmp_path):
    async def completion(**kwargs):
        if kwargs.get("stream"):
            raise AssertionError("non-stream request should use non-stream adapter")
        return {"choices": [{"message": {"content": "completed"}, "finish_reason": "stop"}],
                "usage": {"prompt_tokens": 2, "completion_tokens": 1, "total_tokens": 3}}

    settings = Settings(auth_tokens=("client-token",), config_path=tmp_path / "cfg.json",
                        ledger_path=tmp_path / "ledger.jsonl", metrics_path=tmp_path / "metrics.json")
    lane = Lane("local", "openai", "openai/test-model", needs_key=False,
                capabilities=LaneCapabilities(tools=True, streaming=True))
    client = TestClient(create_app(AppContext(settings, [lane], completion=completion)),
                        base_url="http://127.0.0.1")
    headers = {"Authorization": "Bearer client-token"}
    response = client.post("/v1/chat/completions", headers=headers,
                           json={"model": "test-model", "messages": [{"role": "user", "content": "hi"}]})
    assert response.status_code == 200
    assert response.json()["choices"][0]["message"]["content"] == "completed"
    anth = client.post("/v1/messages", headers=headers,
                       json={"model": "local", "max_tokens": 32,
                             "messages": [{"role": "user", "content": "hi"}]})
    assert anth.status_code == 200
    assert anth.json()["type"] == "message"
    assert anth.json()["content"][0]["text"] == "completed"


def test_c2_streaming_policy_response_is_preserved_without_retry(tmp_path):
    calls = []
    async def completion(**kwargs):
        calls.append(kwargs)
        async def source():
            yield {"choices": [{"index": 0, "delta": {"content": "provider policy explanation"}, "finish_reason": None}]}
            yield {"choices": [{"index": 0, "delta": {}, "finish_reason": "content_filter"}]}
        return source()
    settings = Settings(auth_tokens=("t",), config_path=tmp_path / "cfg.json",
                        ledger_path=tmp_path / "ledger.jsonl", metrics_path=tmp_path / "metrics.json")
    lanes = [Lane("first", "openai", "openai/first", needs_key=False),
             Lane("second", "openai", "openai/second", needs_key=False)]
    client = TestClient(create_app(AppContext(settings, lanes, completion=completion)),
                        base_url="http://127.0.0.1")
    response = client.post("/v1/chat/completions", headers={"Authorization": "Bearer t"},
        json={"model": "auto", "stream": True, "messages": [{"role": "user", "content": "hi"}]})
    assert response.status_code == 200
    assert "provider policy explanation" in response.text
    assert '"finish_reason":"content_filter"' in response.text
    assert response.text.count("[DONE]") == 1
    assert len(calls) == 1  # C2 is never automatically rerouted


def test_i12_exhaustion_is_one_error_frame_without_done(tmp_path):
    calls = []
    async def completion(**kwargs):
        calls.append(kwargs)
        raise ConnectionError("synthetic connection reset")
    settings = Settings(auth_tokens=("t",), max_attempts=1,
                        config_path=tmp_path / "cfg.json", ledger_path=tmp_path / "ledger.jsonl",
                        metrics_path=tmp_path / "metrics.json")
    lane = Lane("only", "openai", "openai/test", needs_key=False)
    client = TestClient(create_app(AppContext(settings, [lane], completion=completion)),
                        base_url="http://127.0.0.1")
    response = client.post("/v1/chat/completions", headers={"Authorization": "Bearer t"},
        json={"model": "only", "stream": True, "messages": [{"role": "user", "content": "hi"}]})
    assert response.status_code == 200  # exhaustion is carried as one SSE error frame
    assert response.text.count("data:") == 1
    assert "[DONE]" not in response.text
    assert len(calls) == 1


def test_i1_response_is_buffered_before_any_client_stream_frame(tmp_path):
    chunks_yielded = []
    async def completion(**kwargs):
        async def upstream():
            chunks_yielded.append("first")
            yield {"choices": [{"index": 0, "delta": {"content": "partial"}, "finish_reason": None}]}
            chunks_yielded.append("finish")
            yield {"choices": [{"index": 0, "delta": {}, "finish_reason": "stop"}]}
        return upstream()
    settings = Settings(auth_tokens=("t",), config_path=tmp_path / "cfg.json",
                        ledger_path=tmp_path / "ledger.jsonl", metrics_path=tmp_path / "metrics.json")
    lane = Lane("only", "openai", "openai/test", needs_key=False,
                capabilities=LaneCapabilities(streaming=True))
    client = TestClient(create_app(AppContext(settings, [lane], completion=completion)),
                        base_url="http://127.0.0.1")
    response = client.post("/v1/chat/completions", headers={"Authorization": "Bearer t"},
        json={"model": "only", "stream": True, "messages": [{"role": "user", "content": "hi"}]})
    assert response.status_code == 200
    assert chunks_yielded == ["first", "finish"]
    assert response.text.index('"content":"partial"') < response.text.index("[DONE]")
    assert response.text.count("partial") == 1


def test_http_ingress_rejects_oversized_body_during_stream_read(tmp_path):
    settings = Settings(auth_tokens=("t",), max_request_bytes=1024,
                        config_path=tmp_path / "cfg.json", ledger_path=tmp_path / "ledger.jsonl",
                        metrics_path=tmp_path / "metrics.json")
    lane = Lane("local", "openai", "openai/test", needs_key=False)
    client = TestClient(create_app(AppContext(settings, [lane])), base_url="http://127.0.0.1")
    response = client.post("/v1/chat/completions", headers={"Authorization": "Bearer t"},
                           content=b'{"messages":[],"padding":"' + b"x" * 2048 + b'"}')
    assert response.status_code == 413


def test_setup_metrics_endpoint_returns_only_operational_summary(tmp_path):
    from ladder.p6_meter import FingerprintMeter
    settings = Settings(config_path=tmp_path / "cfg.json", ledger_path=tmp_path / "ledger.jsonl",
                        metrics_path=tmp_path / "metrics.json")
    meter = FingerprintMeter(settings.metrics_path)
    meter.record("visible-lane", "OK", 50, "run-visible")
    ctx = AppContext(settings, [], meter=meter)
    client = TestClient(create_app(ctx), base_url="http://127.0.0.1")
    response = client.get("/setup/metrics")
    assert response.status_code == 200
    assert response.json()["lanes"][0]["lane_id"] == "visible-lane"
    assert "api_key" not in response.text.lower()
