from ladder.p6_meter import FingerprintMeter
from ladder.p4_lanes import rank_lanes
from ladder.p6_drift import drift_alarm, drift_z_score
from ladder.types import Lane
from unpack import extract, parse_bundle


def test_i8_fingerprint_changes_lane_order_after_samples(tmp_path):
    meter = FingerprintMeter(tmp_path / "metrics.json")
    lanes = [Lane("slow", "openai", "m1", needs_key=False), Lane("fast", "openai", "m2", needs_key=False)]
    assert [x.id for x in rank_lanes(lanes, meter.ranking_profiles())] == ["slow", "fast"]  # configured cold-start fallback
    for _ in range(9):
        meter.record("fast", "OK", 10, f"fast-run-{_}")
    for _ in range(9):
        meter.record("slow", "C1_TRANSPORT", 500, f"slow-run-{_}")
    assert [x.id for x in rank_lanes(lanes, meter.ranking_profiles())] == ["fast", "slow"]


def test_c2_policy_does_not_change_fingerprint():
    meter = FingerprintMeter(__import__("pathlib").Path("/nonexistent/ladder-metrics.json"))
    meter.record("lane", "C2_PROVIDER_POLICY", 500, "policy-run")
    assert rank_lanes([Lane("lane", "openai", "m", needs_key=False)], meter.ranking_profiles())[0].id == "lane"


def test_drift_alarm_detects_synthetic_three_sigma_shift():
    assert drift_z_score(0.95, 1000, 0.75, 1000) > 3
    assert drift_alarm(0.95, 1000, 0.75, 1000, sigma=2.0)
    assert not drift_alarm(0.95, 1000, 0.94, 1000, sigma=2.0)


def test_unpack_removes_exact_arrow_suffix_and_preserves_trailing_hyphen():
    bundle = """  <!-- FILE: README.md -->
````markdown
# test

```inner
not a fence
```
````
<!-- FILE: dir/name-.txt -->
````text
trailing hyphen in filename is meaningful
````
"""
    files = parse_bundle(bundle)
    assert [x.path for x in files] == ["README.md", "dir/name-.txt"]
    assert "```inner" in files[0].content


def test_unpack_rejects_traversal_and_symlink(tmp_path):
    try:
        parse_bundle("<!-- FILE: ../outside.py -->\n```python\nx=1\n```\n")
    except ValueError as exc:
        assert "unsafe" in str(exc)
    else:
        raise AssertionError("path traversal accepted")

    root = tmp_path / "root"
    root.mkdir()
    outside = tmp_path / "outside"
    outside.mkdir()
    (root / "escape").symlink_to(outside, target_is_directory=True)
    try:
        extract(parse_bundle("<!-- FILE: escape/pwn.py -->\n```python\nx=1\n```\n"), root)
    except ValueError as exc:
        assert "symlink" in str(exc)
    else:
        raise AssertionError("symlink escape accepted")


def test_meter_snapshot_reports_sample_provenance_and_two_sigma_drift(tmp_path):
    path = tmp_path / "metrics.json"
    meter = FingerprintMeter(path)
    events = []
    for index in range(100):
        events.append({"run_id": f"baseline-{index}", "success": index < 95,
                       "class": "OK" if index < 95 else "C1_TRANSPORT"})
    for index in range(25):
        events.append({"run_id": f"current-{index}", "success": index < 10,
                       "class": "C1_TRANSPORT"})
    meter._data["lane-a"] = {"ok": 105, "fail": 20, "samples": 125,
                              "latency_ms": 12500, "sample_events": events}
    snapshot = meter.snapshot()[0]
    assert snapshot["lane_id"] == "lane-a"
    assert snapshot["samples"] == 125
    assert snapshot["mean_latency_ms"] == 100
    assert snapshot["drift_alarm_2sigma"] is True
    assert len(snapshot["recent_run_ids"]) == 25


def test_session_affinity_is_bounded_lru():
    from ladder.p4_lanes import SessionAffinity

    affinity = SessionAffinity(max_sessions=2)
    affinity.set("one", "a")
    affinity.set("two", "b")
    assert affinity.get("one") == "a"  # refresh recency
    affinity.set("three", "c")
    assert affinity.get("two") is None
    assert affinity.get("one") == "a"
    assert affinity.get("three") == "c"
