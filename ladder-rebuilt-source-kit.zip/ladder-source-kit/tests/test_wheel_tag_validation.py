from scripts.check_wheel_tags import validate_artifacts


def test_accepts_matching_pure_python_wheel(tmp_path):
    wheel = tmp_path / "demo_pkg-1.0-py3-none-any.whl"; wheel.touch()
    accepted, errors = validate_artifacts([wheel])
    assert accepted == [wheel] and errors == []


def test_accepts_litellm_stable_abi_wheel_for_cp313(tmp_path):
    # LiteLLM 1.110.2 publishes cp310-abi3 wheels; abi3 remains compatible with
    # newer CPython versions, including the project's cp313 target.
    wheel = tmp_path / "litellm-1.110.2-cp310-abi3-manylinux_2_28_x86_64.whl"; wheel.touch()
    accepted, errors = validate_artifacts([wheel])
    assert accepted == [wheel] and errors == []


def test_rejects_cp312_wheel_by_filename(tmp_path):
    wheel = tmp_path / "demo_pkg-1.0-cp312-cp312-manylinux2014_x86_64.whl"; wheel.touch()
    accepted, errors = validate_artifacts([wheel])
    assert not accepted and any(wheel.name in error for error in errors)


def test_rejects_musllinux_wheel_by_filename(tmp_path):
    wheel = tmp_path / "demo_pkg-1.0-cp313-cp313-musllinux_1_2_x86_64.whl"; wheel.touch()
    accepted, errors = validate_artifacts([wheel])
    assert not accepted and any(wheel.name in error for error in errors)


def test_rejects_sdist_only_package_by_filename(tmp_path):
    sdist = tmp_path / "demo_pkg-1.0.tar.gz"; sdist.touch()
    accepted, errors = validate_artifacts([sdist])
    assert not accepted and any(sdist.name in error for error in errors)


def test_missing_direct_pin_is_reported_by_distribution_and_version():
    from scripts.check_wheel_tags import validate_direct_pins
    errors = validate_direct_pins([], {"fastapi": "0.165.0"})
    assert errors == ["missing compatible direct-pin wheel: fastapi==0.165.0"]


def test_manifest_file_is_metadata_not_a_wheel_artifact(tmp_path):
    from scripts.check_wheel_tags import validate_artifacts
    wheel = tmp_path / "demo_pkg-1.0-py3-none-any.whl"; wheel.touch()
    manifest = tmp_path / "MANIFEST.sha256"; manifest.write_text("metadata", encoding="utf-8")
    accepted, errors = validate_artifacts([wheel, manifest])
    assert accepted == [wheel] and errors == []
