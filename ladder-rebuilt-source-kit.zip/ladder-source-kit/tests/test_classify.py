from ladder.p1_normalize import normalize_openai
from ladder.p2_classify import classify_exception, classify_result
from ladder.types import OutcomeClass, ProviderResult


class HttpError(Exception):
    def __init__(self, status_code):
        self.status_code = status_code


def _graph(tool_choice=None, expect_evidence=False):
    payload = {"messages": [{"role": "user", "content": "do the task"}],
               "tools": [{"type": "function", "function": {"name": "read_file"}}],
               "tool_choice": tool_choice,
               "ladder": {"expect_evidence_envelope": expect_evidence}}
    return normalize_openai(payload)


def test_c1_transport_timeout_and_429():
    assert classify_exception(TimeoutError()).category is OutcomeClass.C1_TRANSPORT
    assert classify_exception(HttpError(429)).category is OutcomeClass.C1_TRANSPORT
    assert classify_exception(HttpError(503)).category is OutcomeClass.C1_TRANSPORT


def test_c2_provider_policy_is_structural():
    graph = _graph()
    assert classify_result(graph, ProviderResult("", finish_reason="content_filter")).category is OutcomeClass.C2_PROVIDER_POLICY
    assert classify_result(graph, ProviderResult("", finish_reason="stop", provider_refusal="blocked")).category is OutcomeClass.C2_PROVIDER_POLICY


def test_c3_incomplete_or_missing_finish_reason():
    graph = _graph()
    assert classify_result(graph, ProviderResult("some text", finish_reason="length")).category is OutcomeClass.C3_INCOMPLETE
    assert classify_result(graph, ProviderResult("some text", finish_reason=None)).category is OutcomeClass.C3_INCOMPLETE
    assert classify_result(graph, ProviderResult("", finish_reason="stop")).category is OutcomeClass.C3_INCOMPLETE


def test_c4_only_when_a_tool_was_contractually_required():
    required = _graph("required")
    optional = _graph("auto")
    no_tool = ProviderResult("Done", finish_reason="stop")
    assert classify_result(required, no_tool).category is OutcomeClass.C4_CAPABILITY
    assert classify_result(optional, no_tool).category is OutcomeClass.OK


def test_c5_requires_explicit_envelope_contract_and_populated_unknowns():
    response = ProviderResult('{"answer":"partial","unknowns":["not measured"]}', finish_reason="stop")
    assert classify_result(_graph(expect_evidence=True), response).category is OutcomeClass.C5_EVIDENCE
    assert classify_result(_graph(), response).category is OutcomeClass.OK


def test_tool_result_refusal_words_are_not_scanned_by_classifier():
    graph = normalize_openai({"messages": [
        {"role": "user", "content": "read file"},
        {"role": "assistant", "content": None, "tool_calls": [
            {"id": "c1", "type": "function", "function": {"name": "read_file", "arguments": "{}"}}
        ]},
        {"role": "tool", "tool_call_id": "c1", "content": "I can't do that; format unsupported"},
    ], "tools": [{"type": "function", "function": {"name": "read_file"}}]})

    class CapturingJudge:
        seen = None
        def predict(self, prompt, response):
            self.seen = (prompt, response)
            return "compliant", 0.99

    judge = CapturingJudge()
    result = ProviderResult("The file is readable.", finish_reason="stop")
    classification = classify_result(graph, result, judge)
    assert classification.category is OutcomeClass.OK
    assert "I can't" not in judge.seen[0]
    assert "unsupported" not in judge.seen[1]


def test_c6_provider_auth_and_c7_client_error():
    assert classify_exception(HttpError(401)).category is OutcomeClass.C6_PROVIDER_CONFIG
    assert classify_exception(HttpError(403)).category is OutcomeClass.C6_PROVIDER_CONFIG
    assert classify_exception(HttpError(400)).category is OutcomeClass.C7_INVALID_REQUEST


def test_c2_400_requires_explicit_structured_policy_code():
    class PolicyHttpError(Exception):
        status_code = 400
        code = "moderation_blocked"
    class GenericHttpError(Exception):
        status_code = 400
    assert classify_exception(PolicyHttpError("request rejected")).category is OutcomeClass.C2_PROVIDER_POLICY
    assert classify_exception(GenericHttpError("moderation maybe")).category is OutcomeClass.C7_INVALID_REQUEST


def test_local_judge_refusal_is_preserved_not_rerouted():
    class Judge:
        def predict(self, prompt, response):
            return "full_refusal", 0.98
    graph = _graph()
    result = classify_result(graph, ProviderResult("I cannot help with that.", finish_reason="stop"), Judge())
    assert result.category is OutcomeClass.C2_PROVIDER_POLICY


def test_multi_tool_contract_requires_every_named_tool():
    graph = normalize_openai({
        "messages": [{"role": "user", "content": "read and list"}],
        "tools": [
            {"type": "function", "function": {"name": "read_file"}},
            {"type": "function", "function": {"name": "list_files"}},
        ],
        "ladder": {"expected_tools": ["read_file", "list_files"]},
    })
    only_one = ProviderResult("", [__import__("ladder.types", fromlist=["ToolCall"]).ToolCall(
        "c1", "read_file", "{}")], "tool_calls")
    assert classify_result(graph, only_one).category is OutcomeClass.C4_CAPABILITY
