#!/usr/bin/env python3
"""Extract `<!-- FILE: path -->` sections from a fenced Markdown bundle.

The closing marker is removed by slicing the exact three-character suffix
`-->`; no character-set rstrip is used, so filenames ending in `-` survive.
"""
from __future__ import annotations

import argparse
import os
import re
import sys
import tempfile
from dataclasses import dataclass
from pathlib import Path, PurePosixPath

MARKER_PREFIX = "<!-- FILE:"
MARKER_SUFFIX = "-->"
MARKER_RE = re.compile(r"^\s*<!-- FILE:\s*(.*?)\s*-->\s*$")
OPEN_FENCE_RE = re.compile(r"^\s*(`{3,}|~{3,})(?:[A-Za-z0-9_+.-]+)?\s*$")


@dataclass(frozen=True)
class ExtractedFile:
    path: str
    content: str


def _safe_relative_path(name: str) -> PurePosixPath:
    normalized = name.replace("\\", "/")
    path = PurePosixPath(normalized)
    if not normalized or path.is_absolute() or any(part in ("", ".", "..") for part in path.parts):
        raise ValueError(f"unsafe or empty output path: {name!r}")
    if path.parts and re.match(r"^[A-Za-z]:", path.parts[0]):
        raise ValueError(f"drive-qualified output path is not allowed: {name!r}")
    if "\x00" in normalized:
        raise ValueError("NUL byte in output path")
    return path


def parse_bundle(text: str) -> list[ExtractedFile]:
    lines = text.splitlines(keepends=True)
    found: list[ExtractedFile] = []
    seen: set[str] = set()
    i = 0
    while i < len(lines):
        match = MARKER_RE.match(lines[i].rstrip("\r\n"))
        if not match:
            i += 1
            continue
        # Exact suffix handling: the marker grammar consumes exactly `-->`.
        marker_line = lines[i].rstrip("\r\n")
        if not marker_line.endswith(MARKER_SUFFIX):
            raise ValueError(f"malformed file marker on line {i + 1}")
        # Use the parsed group rather than fixed slicing, because the grammar
        # also permits indentation before the marker itself.
        raw_name = match.group(1).strip()
        safe_path = _safe_relative_path(raw_name)
        name = safe_path.as_posix()
        if name in seen:
            raise ValueError(f"duplicate file marker: {name}")
        seen.add(name)
        i += 1
        if i >= len(lines):
            raise ValueError(f"missing fenced content for {name}")
        fence_match = OPEN_FENCE_RE.match(lines[i].rstrip("\r\n"))
        if not fence_match:
            raise ValueError(f"expected an opening code fence after marker for {name}")
        fence = fence_match.group(1)
        fence_char, fence_len = fence[0], len(fence)
        i += 1
        content: list[str] = []
        closing = re.compile(rf"^\s*{re.escape(fence_char)}{{{fence_len},}}\s*$")
        while i < len(lines) and not closing.match(lines[i].rstrip("\r\n")):
            content.append(lines[i])
            i += 1
        if i >= len(lines):
            raise ValueError(f"unterminated code fence for {name}")
        i += 1
        found.append(ExtractedFile(name, "".join(content)))
    return found


def _safe_target(root: Path, relative: PurePosixPath) -> Path:
    root_resolved = root.resolve()
    target = root_resolved.joinpath(*relative.parts)
    # Check every existing component; never follow a symlink supplied in target tree.
    current = root_resolved
    for part in relative.parts:
        current = current / part
        if current.is_symlink():
            raise ValueError(f"refusing to write through symlink: {current}")
    resolved_parent = target.parent.resolve()
    if resolved_parent != root_resolved and root_resolved not in resolved_parent.parents:
        raise ValueError(f"output path escapes destination: {relative}")
    return target


def extract(files: list[ExtractedFile], destination: Path) -> None:
    destination.mkdir(parents=True, exist_ok=True)
    for item in files:
        relative = _safe_relative_path(item.path)
        target = _safe_target(destination, relative)
        target.parent.mkdir(parents=True, exist_ok=True)
        # Re-check after mkdir to catch a symlink appearing in a newly-created path.
        target = _safe_target(destination, relative)
        fd, tmp_name = tempfile.mkstemp(prefix=".ladder-unpack-", dir=str(target.parent))
        try:
            with os.fdopen(fd, "w", encoding="utf-8", newline="") as handle:
                handle.write(item.content)
                handle.flush()
                os.fsync(handle.fileno())
            os.replace(tmp_name, target)
        except BaseException:
            try:
                os.unlink(tmp_name)
            except OSError:
                pass
            raise


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("bundle", help="Markdown bundle path, or - for stdin")
    parser.add_argument("--output", type=Path, default=Path("."), help="destination directory")
    parser.add_argument("--check", action="store_true", help="validate and list files without writing")
    args = parser.parse_args(argv)
    raw = sys.stdin.read() if args.bundle == "-" else Path(args.bundle).read_text(encoding="utf-8")
    files = parse_bundle(raw)
    if not files:
        print("no FILE markers found", file=sys.stderr)
        return 1
    if args.check:
        for item in files:
            print(f"OK {item.path} ({len(item.content.encode('utf-8'))} bytes)")
        return 0
    extract(files, args.output)
    print(f"extracted {len(files)} file(s) to {args.output.resolve()}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
