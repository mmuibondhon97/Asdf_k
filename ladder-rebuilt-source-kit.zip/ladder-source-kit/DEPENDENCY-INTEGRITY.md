# Dependency integrity

## Trust model

- `wheelhouse/MANIFEST.sha256` is a transfer-integrity manifest, not a pip lock.
- `requirements.lock` and `requirements-dev.lock` are installation records. They
  pin the resolved package closure and hashes of the actual wheel artifacts.
- Locks are generated only after the supplied wheelhouse manifest and wheel tags
  have been verified.
- Production and development installs use clean virtual environments and pip
  `--no-index --find-links wheelhouse --require-hashes`.
- No generated SHA-256 value may be guessed, copied from a different platform or
  filled with a placeholder.

## No-GitHub workflow

On an internet-connected Linux x86_64 machine with CPython 3.13, run:

```bash
bash scripts/build-wheelhouse.sh wheelhouse
bash scripts/package-wheelhouse.sh wheelhouse
```

Transfer the resulting `dist/ladder-wheelhouse-cp313-linux-x86_64.zip` and its
`.sha256` file with the source project. On the target CPython 3.13 Linux x86_64
machine:

```bash
sha256sum -c ladder-wheelhouse-cp313-linux-x86_64.zip.sha256
unzip ladder-wheelhouse-cp313-linux-x86_64.zip
make verify-offline
```

The verification script validates the transfer manifest and every wheel tag,
generates both hash locks from verified wheel bytes, creates clean production
and development virtual environments, performs hash-enforced offline
installations, runs both integrity checks, tests and the synthetic dry battery,
and only then produces the final master ZIP. Missing artifacts or any failed
step block packaging.

## Wheel target

CPython 3.13 / Linux x86_64. Pip target selectors are `manylinux2014_x86_64`
and `manylinux_2_28_x86_64`, `--implementation cp`, `--abi cp313`, and
`--only-binary=:all:`. Pure Python `py3-none-any` wheels are permitted. CPython
3.12 wheels, musllinux wheels and source distributions are rejected.

## Static workflow validation

`make static-check` parses the optional workflow YAML, syntax-checks each
workflow shell block using `bash -n`, and validates full 40-character action
SHA formatting and release comments. It also checks the workflow control
fields and the order of the offline release gate. `actionlint` is run when it
is installed; this environment did not have it. SHA formatting is not proof of
action publisher identity or that the pin is still the intended upstream tag.
The workflow is optional and is not needed for the no-GitHub process.

## Direct runtime dependencies

The exact direct dependencies are listed in `requirements.txt`; test/development
dependencies are in `requirements-dev.txt`. Published release metadata and
source references are recorded in `UPSTREAM-SOURCES.md`. Their version pins
alone do not prove that a complete compatible transitive wheel closure was
installed. The wheelhouse and generated lockfiles provide that evidence.
