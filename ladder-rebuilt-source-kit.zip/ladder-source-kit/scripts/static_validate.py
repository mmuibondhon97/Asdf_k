#!/usr/bin/env python3
from pathlib import Path
import hashlib, json, os, re, shutil, subprocess, sys, tarfile, tempfile
try:
    import yaml
except ImportError:
    yaml = None
root = Path(__file__).resolve().parents[1]
files = sorted((root / ".github/workflows").glob("*.yml"))
if not files: raise SystemExit("no workflow YAML files found")
failures, uses_lines = [], []
for wf in files:
    source = wf.read_text(encoding="utf-8")
    try:
        if yaml is not None:
            parsed = yaml.safe_load(source)
        else:
            # GitHub's Ubuntu runner has Ruby/Psych; use it as a parser fallback
            # so the static gate does not require an unpinned pre-install of PyYAML.
            ruby = subprocess.run(
                ["ruby", "-r", "yaml", "-r", "json", "-e",
                 "puts JSON.generate(YAML.load_file(ARGV.fetch(0), aliases: true))", str(wf)],
                cwd=root, text=True, capture_output=True,
            )
            if ruby.returncode:
                raise RuntimeError(ruby.stderr.strip() or "Ruby YAML parser failed")
            parsed = json.loads(ruby.stdout)
    except Exception as exc:
        failures.append(f"{wf}: YAML parse failed: {exc}"); continue
    if not isinstance(parsed, dict): failures.append(f"{wf}: top-level YAML must be a mapping"); continue
    for required in ("pull_request:", "workflow_dispatch:", "permissions:\n  contents: read", "concurrency:", "github.ref", "if: always()", "if: success()", "LADDER_BUILD_WHEELHOUSE: \"1\""):
        if required not in source: failures.append(f"{wf}: missing required workflow control {required!r}")
    if "run: make verify-offline" not in source:
        failures.append(f"{wf}: workflow must use the single make verify-offline entrypoint")
    for n, line in enumerate(source.splitlines(), 1):
        if re.search(r"\buses:\s*", line):
            uses_lines.append(f"{wf.relative_to(root)}:{n}:{line.strip()}")
            m = re.search(r"uses:\s*([^\s#]+)\s+#\s*(v\d+\.\d+\.\d+)\s*$", line)
            if not m or not re.fullmatch(r"[0-9a-f]{40}", m.group(1).split("@")[-1]):
                failures.append(f"{wf}:{n}: uses must be full 40-character SHA plus # vX.Y.Z comment")
    for job_id, job in parsed.get("jobs", {}).items():
        for i, step in enumerate(job.get("steps", []), 1):
            command = step.get("run")
            if command:
                r = subprocess.run(["bash", "-n"], input=command, text=True, capture_output=True)
                if r.returncode: failures.append(f"{wf}:{job_id}:step{i}: bash -n failed: {r.stderr.strip()}")
# Enforce the security-critical ordering in the single offline verification script.
verify_script = (root / "scripts/verify-offline.sh").read_text(encoding="utf-8")
ordered_tokens = [
    'LADDER_BUILD_WHEELHOUSE:-0',
    'scripts/build-wheelhouse.sh \"$WHEELHOUSE\"',
    'sha256sum -c MANIFEST.sha256',
    'manage.py lock --from-manifest',
    'python -m venv "$TMP/prod"',
    'pip install --no-index --find-links "$WHEELHOUSE" --require-hashes -r requirements.lock',
    'manage.py integrity',
    'manage.py test',
    'dist/ladder-master.zip',
]
positions = [verify_script.find(token) for token in ordered_tokens]
if any(pos < 0 for pos in positions) or positions != sorted(positions):
    failures.append("verify-offline.sh: required manifest -> lock -> clean venv -> hash install -> tests -> archive order is missing")

print("ACTION_USES_LINES:")
for line in uses_lines: print(line)
if failures:
    print("STATIC_VALIDATION=FAIL"); print("\n".join(failures), file=sys.stderr); raise SystemExit(1)
print(f"YAML_PARSE=PASS workflow_count={len(files)}")
print("WORKFLOW_RUN_BLOCK_BASH_N=PASS")
print("ACTION_SHA_FORMAT=PASS (all references are full 40-character SHAs with semver comments)")
actionlint = shutil.which("actionlint")
if not actionlint and os.environ.get("GITHUB_ACTIONS") == "true":
    # Fetch a fixed official release binary and verify its published SHA-256.
    url = "https://github.com/rhysd/actionlint/releases/download/v1.7.12/actionlint_1.7.12_linux_amd64.tar.gz"
    expected = "8aca8db96f1b94770f1b0d72b6dddcb1ebb8123cb3712530b08cc387b349a3d8"
    with tempfile.TemporaryDirectory(prefix="ladder-actionlint-") as tempdir:
        archive = Path(tempdir) / "actionlint.tar.gz"
        download = subprocess.run(["curl", "-fsSL", url, "-o", str(archive)], cwd=root)
        if download.returncode: raise SystemExit(download.returncode)
        actual = hashlib.sha256(archive.read_bytes()).hexdigest()
        if actual != expected:
            raise SystemExit(f"actionlint archive SHA-256 mismatch: {actual}")
        with tarfile.open(archive, "r:gz") as bundle:
            member = next((m for m in bundle.getmembers()
                           if Path(m.name).name == "actionlint" and m.isfile()), None)
            if member is None: raise SystemExit("actionlint binary missing from release archive")
            binary = Path(tempdir) / "actionlint"
            source = bundle.extractfile(member)
            if source is None: raise SystemExit("could not read actionlint binary")
            binary.write_bytes(source.read()); binary.chmod(0o755)
        result = subprocess.run([str(binary), *map(str, files)], cwd=root)
        if result.returncode: raise SystemExit(result.returncode)
        print("ACTIONLINT=PASS version=v1.7.12 archive_sha256=verified")
elif actionlint:
    result = subprocess.run([actionlint, *map(str, files)], cwd=root)
    if result.returncode: raise SystemExit(result.returncode)
    print("ACTIONLINT=PASS")
else:
    print("ACTIONLINT=UNAVAILABLE (offline runtime; hosted CI verifies official v1.7.12 binary SHA-256)")
