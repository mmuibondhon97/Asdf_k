#!/usr/bin/env bash
set -Eeuo pipefail
ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
cd "$ROOT"
WHEELHOUSE="${1:-$ROOT/wheelhouse}"
mkdir -p artifacts dist
TRANSCRIPT="$ROOT/artifacts/verification-transcript.txt"
exec > >(tee "$TRANSCRIPT") 2>&1
TMP=""
cleanup() { rc=$?; echo "VERIFY_EXIT_CODE=$rc"; [[ -z "$TMP" ]] || rm -rf "$TMP"; exit "$rc"; }
trap cleanup EXIT

echo "STEP 0: static workflow validation"
python scripts/static_validate.py
python - <<'PYTHON_TARGET'
import platform, sys
if sys.implementation.name != "cpython" or sys.version_info[:2] != (3, 13):
    raise SystemExit("verification requires CPython 3.13")
if platform.system() != "Linux" or platform.machine().lower() not in {"x86_64", "amd64"}:
    raise SystemExit("verification requires Linux x86_64")
print("TARGET=CPython 3.13 Linux x86_64")
PYTHON_TARGET
if [[ ! -f "$WHEELHOUSE/MANIFEST.sha256" ]]; then
  if [[ "${LADDER_BUILD_WHEELHOUSE:-0}" == "1" ]]; then
    echo "STEP 0.5: build target wheelhouse from exact requirements"
    bash scripts/build-wheelhouse.sh "$WHEELHOUSE"
  else
    echo "Missing $WHEELHOUSE/MANIFEST.sha256"
    echo "For connected CI, set LADDER_BUILD_WHEELHOUSE=1; for offline verification, supply the complete manifest-verified wheelhouse."
    exit 2
  fi
fi
echo "STEP 1: transfer manifest verification"
(cd "$WHEELHOUSE" && sha256sum -c MANIFEST.sha256)
echo "STEP 2: target wheel-tag validation"
python scripts/check_wheel_tags.py "$WHEELHOUSE"
echo "STEP 3: lock generation from verified manifest-listed wheel artifacts"
python manage.py lock --from-manifest --wheelhouse "$WHEELHOUSE"
python manage.py lock --dev --from-manifest --wheelhouse "$WHEELHOUSE"
echo "STEP 4: clean virtual environments"
TMP="$(mktemp -d)"
python -m venv "$TMP/prod"
python -m venv "$TMP/dev"
echo "STEP 5: production --require-hashes install and integrity"
"$TMP/prod/bin/python" -m pip install --no-index --find-links "$WHEELHOUSE" --require-hashes -r requirements.lock
"$TMP/prod/bin/python" manage.py integrity
echo "STEP 6: development --require-hashes install and integrity"
"$TMP/dev/bin/python" -m pip install --no-index --find-links "$WHEELHOUSE" --require-hashes -r requirements-dev.lock
"$TMP/dev/bin/python" manage.py integrity --dev
echo "STEP 7: test suite and synthetic battery"
"$TMP/dev/bin/python" manage.py test
LADDER_LANES_JSON='[{"id":"dependency-preflight","model":"dependency-preflight","needs_key":false,"locality":"local","base_url":"http://127.0.0.1:1"}]' \
  "$TMP/dev/bin/python" manage.py battery
echo "STEP 8: verification summary and release archive"
cp "$WHEELHOUSE/MANIFEST.sha256" artifacts/MANIFEST.sha256
cp requirements.lock requirements-dev.lock artifacts/
{
  echo "python=$(python --version 2>&1)"
  echo "wheelhouse_manifest_sha256=$(sha256sum "$WHEELHOUSE/MANIFEST.sha256" | awk '{print $1}')"
  echo "requirements_lock_sha256=$(sha256sum requirements.lock | awk '{print $1}')"
  echo "requirements_dev_lock_sha256=$(sha256sum requirements-dev.lock | awk '{print $1}')"
  echo "pinned_installation=PASS"
  echo "integrity_production=PASS"
  echo "integrity_development=PASS"
  echo "tests=PASS"
  echo "battery=PASS"
} > artifacts/verification-summary.txt
rm -f dist/ladder-master.zip dist/ladder-master.zip.sha256
zip -X -r dist/ladder-master.zip . \
  -x './.git/*' './.venv/*' './.pytest_cache/*' './__pycache__/*' \
     './*/__pycache__/*' './.env' './dist/*' './.mypy_cache/*' './wheelhouse/*'
(cd dist && sha256sum ladder-master.zip | tee ladder-master.zip.sha256)
echo "FINAL_ARCHIVE=$ROOT/dist/ladder-master.zip"
echo "FINAL_ARCHIVE_SHA256=$(awk '{print $1}' dist/ladder-master.zip.sha256)"
echo "VERIFY_EXIT_CODE=0"
