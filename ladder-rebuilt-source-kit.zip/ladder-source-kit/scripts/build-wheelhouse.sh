#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
cd "$ROOT"
WHEELHOUSE="${1:-$ROOT/wheelhouse}"
mkdir -p "$WHEELHOUSE"
find "$WHEELHOUSE" -maxdepth 1 -type f \( -name '*.whl' -o -name 'MANIFEST.sha256' \) -delete
python -m pip download \
  --dest "$WHEELHOUSE" \
  --platform manylinux2014_x86_64 \
  --platform manylinux_2_28_x86_64 \
  --implementation cp \
  --abi cp313 \
  --python-version 3.13 \
  --only-binary=:all: \
  -r requirements-dev.txt
python scripts/check_wheel_tags.py "$WHEELHOUSE"
(
  cd "$WHEELHOUSE"
  shopt -s nullglob
  wheels=( *.whl )
  ((${#wheels[@]} > 0)) || { echo "No wheel artifacts downloaded" >&2; exit 1; }
  sha256sum "${wheels[@]}" > MANIFEST.sha256
)
echo "wheelhouse_manifest=$WHEELHOUSE/MANIFEST.sha256"
