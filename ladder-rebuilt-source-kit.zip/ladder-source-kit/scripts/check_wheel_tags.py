#!/usr/bin/env python3
from __future__ import annotations
import argparse
from pathlib import Path
from pip._vendor.packaging.tags import cpython_tags, compatible_tags
from pip._vendor.packaging.utils import parse_wheel_filename

TARGET_PLATFORMS = ("manylinux2014_x86_64", "manylinux_2_28_x86_64")

def target_tags():
    tags = set(cpython_tags(python_version=(3, 13), platforms=list(TARGET_PLATFORMS)))
    tags.update(compatible_tags(python_version=(3, 13), interpreter="cp313", platforms=list(TARGET_PLATFORMS)))
    return tags

def validate_artifacts(paths):
    """Return (accepted wheel paths, error strings); reject sdists and bad tags."""
    accepted, errors = [], []
    supported = target_tags()
    for path in sorted(map(Path, paths), key=lambda p: p.name):
        if path.name == "MANIFEST.sha256":
            continue
        if path.suffix != ".whl":
            errors.append(f"{path.name}: source distribution/non-wheel artifact rejected")
            continue
        try:
            _name, _version, _build, tags = parse_wheel_filename(path.name)
        except Exception as exc:
            errors.append(f"{path.name}: invalid wheel filename ({exc})")
            continue
        if not set(tags).intersection(supported):
            errors.append(f"{path.name}: incompatible CPython 3.13 Linux x86_64 wheel tag")
            continue
        accepted.append(path)
    return accepted, errors

def validate_direct_pins(accepted_paths, pins):
    """Ensure every direct exact pin has a target-compatible wheel in the set."""
    from pip._vendor.packaging.utils import parse_wheel_filename
    found = set()
    for path in accepted_paths:
        name, version, _build, _tags = parse_wheel_filename(path.name)
        found.add((str(name).lower().replace("_", "-"), str(version)))
    missing = [f"{name}=={version}" for name, version in sorted(pins.items())
               if (name, version) not in found]
    return [f"missing compatible direct-pin wheel: {item}" for item in missing]


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("wheelhouse", type=Path)
    args = parser.parse_args()
    if not args.wheelhouse.is_dir(): parser.error(f"wheelhouse does not exist: {args.wheelhouse}")
    accepted, errors = validate_artifacts(args.wheelhouse.iterdir())
    from manage import _direct_pins
    pins, pin_errors = _direct_pins(Path("requirements-dev.txt"))
    errors.extend(pin_errors)
    errors.extend(validate_direct_pins(accepted, pins))
    for error in errors: print("REJECT:", error)
    print(f"compatible_wheels={len(accepted)} rejected_artifacts={len(errors)} direct_pins={len(pins)}")
    return 1 if errors or not accepted else 0

if __name__ == "__main__":
    raise SystemExit(main())
