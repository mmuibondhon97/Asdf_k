#!/usr/bin/env bash
set -Eeuo pipefail
ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
cd "$ROOT"
WHEELHOUSE="${1:-wheelhouse}"
if [[ "$WHEELHOUSE" != "wheelhouse" ]]; then
  echo "For a reproducible transfer archive, pass the project wheelhouse directory: wheelhouse" >&2
  exit 2
fi
if [[ ! -f wheelhouse/MANIFEST.sha256 ]]; then
  echo "wheelhouse/MANIFEST.sha256 is missing; run scripts/build-wheelhouse.sh first" >&2
  exit 2
fi
(
  cd wheelhouse
  sha256sum -c MANIFEST.sha256
  shopt -s nullglob
  wheels=( *.whl )
  ((${#wheels[@]} > 0)) || { echo "No wheel files found" >&2; exit 1; }
)
mkdir -p dist
rm -f dist/ladder-wheelhouse-cp313-linux-x86_64.zip dist/ladder-wheelhouse-cp313-linux-x86_64.zip.sha256
zip -X -r dist/ladder-wheelhouse-cp313-linux-x86_64.zip wheelhouse -i 'wheelhouse/*.whl' 'wheelhouse/MANIFEST.sha256'
(cd dist && sha256sum ladder-wheelhouse-cp313-linux-x86_64.zip | tee ladder-wheelhouse-cp313-linux-x86_64.zip.sha256)
echo "WHEELHOUSE_ARCHIVE=$ROOT/dist/ladder-wheelhouse-cp313-linux-x86_64.zip"
