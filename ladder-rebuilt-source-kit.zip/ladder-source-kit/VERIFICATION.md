# Verification status

## Current local source preflight — 2026-11-21

Environment observed for this run:

- CPython 3.13.5.
- FastAPI 0.128.2, Uvicorn 0.48.0, HTTPX 0.28.1, pytest 9.0.2,
  Pydantic 2.13.5 and PyYAML 6.0.3 were already installed.
- LiteLLM was not installed. The installed FastAPI/Uvicorn/pytest versions do
  not match all declared direct pins, so this is not a pinned runtime test.

Results:

- `python -m pytest -q`: **112 passed** in the ambient unpinned environment.
- `python -m compileall -q ladder manage.py scripts tests`: PASS.
- `bash -n` for every project shell script: PASS.
- `make static-check`: PASS for YAML parsing, workflow run-block shell syntax,
  full action-SHA formatting and configured workflow controls.
- `actionlint`: unavailable locally; it was not run in this environment.
- `make battery-preflight`: PASS; 25 synthetic probe records and a presence-only
  dummy local lane. No network request or provider validation occurs.
- `python manage.py battery` without lane configuration: FAIL_NO_ACTIVE_LANES,
  as intended for a standalone preflight with no active lane.
- The same battery with the dummy preflight lane: PASS_PREFLIGHT.
- `make verify-offline`: exit 2 because `wheelhouse/MANIFEST.sha256` is absent.
  It stopped before lock generation, clean installs and final packaging.

## Not verified

- Actual CPython 3.13 Linux x86_64 wheelhouse download and manifest.
- `requirements.lock` or `requirements-dev.lock` generated from downloaded
  wheel bytes.
- Clean production/development `--require-hashes` installs and `pip check`.
- Test suite on the exact locked production/development dependency closure.
- Docker image build or Docker runtime.
- A live provider request, provider credential validation, or actual model
  compatibility.
- A real Claude Code or Codex CLI multi-turn tool-use session.
- The 23/25 live probe target, zero C2 hard-failure target, hand-labelled
  120-turn classifier evaluation, or VRAM/model-weight benchmark.

The source preflight must not be described as a dependency-verified release.
Complete the no-GitHub wheelhouse transfer procedure in `README.md` and run
`make verify-offline` on CPython 3.13 Linux x86_64 to complete that gate.

## Upstream release metadata

`UPSTREAM-SOURCES.md` records the exact pinned release versions, upstream
sources, declared Python version ranges, published wheel tags and provenance
observations. Metadata compatibility is not a substitute for installing the
complete wheel dependency closure.
