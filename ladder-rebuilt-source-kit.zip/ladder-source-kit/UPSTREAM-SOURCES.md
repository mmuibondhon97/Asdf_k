# Upstream dependency sources and release review

Review date: 2026-11-21

This file records the upstream projects corresponding to the exact direct pins.
The project consumes published Python distributions; it does not vendor these
repositories, install from mutable branch heads, or treat a Git URL as an
artifact checksum.

| Distribution | Exact pin | Canonical source | Release reference | Declared Python range | PyPI artifact provenance |
|---|---:|---|---|---|---|
| FastAPI | `0.165.0` | <https://github.com/fastapi/fastapi> | <https://github.com/fastapi/fastapi/releases/tag/0.165.0> | `>=3.11` | PyPI reports no provenance for this release's files |
| Uvicorn | `0.54.0` | <https://github.com/Kludex/uvicorn> | <https://github.com/Kludex/uvicorn/releases/tag/0.54.0> | `>=3.10` | PyPI reports full provenance; publishing commit `3eb9a9ab9af69005c687728097461c1fd2a95db9` |
| LiteLLM | `1.110.2` | <https://github.com/BerriAI/litellm> | <https://github.com/BerriAI/litellm/releases/tag/1.110.2> | `>=3.10,<3.16` | PyPI reports full provenance for release files |

## Published artifact observations

The following are upstream PyPI release-page checksums, not locally computed
wheelhouse manifest entries:

- FastAPI `fastapi-0.165.0-py3-none-any.whl`: SHA-256
  `896f48462042bb4f162147eb8fac7e858753dc1f486765709baf105d70e4fc5b`.
  PyPI reports no provenance for the release files.
- Uvicorn `uvicorn-0.54.0-py3-none-any.whl`: SHA-256
  `505bdb0f318731d45f1f712071fc781a8981f6847a31c902c9f5e652d4f67faf`.
  PyPI reports provenance tied to publishing commit
  `3eb9a9ab9af69005c687728097461c1fd2a95db9`.
- LiteLLM `litellm-1.110.2-cp310-abi3-manylinux_2_28_x86_64.whl` is listed by
  PyPI at 43.8 MB with provenance. Its digest is intentionally not copied here;
  the local transfer manifest and generated pip lock must hash the actual file.

## Compatibility assessment

The configured target is CPython 3.13 on Linux x86_64. All three declared
Python ranges include Python 3.13. LiteLLM publishes a `cp310-abi3` wheel for
`manylinux_2_28_x86_64`; the stable ABI tag is compatible with CPython 3.13 and
the selected glibc target. Uvicorn and FastAPI publish pure-Python wheels.

This is a metadata/tag compatibility assessment only. It does not prove that
the full dependency closure resolves, that all selected artifacts install, or
that the Ladder suite passes on the pinned environment. Those claims require
the generated wheelhouse, manifest-derived locks, clean hash installs and test
results produced by `make verify-offline`.

## Distribution versus source repository

- Keep the exact direct pins in `requirements.txt` and `requirements-dev.txt`.
- Resolve transitive dependencies from the selected wheelhouse; do not infer
  their versions from the current default branch of an upstream repository.
- `wheelhouse/MANIFEST.sha256` records transfer integrity for actual downloaded
  wheel files.
- `requirements.lock` and `requirements-dev.lock` record exact selected
  distributions and SHA-256 digests of those actual wheel bytes.
- The upstream release page and PyPI provenance are supply-chain context. They
  do not replace local byte hashing or `pip --require-hashes` installation.

## Reviewed upstream references

- FastAPI 0.165.0 release and Python requirement: <https://pypi.org/project/fastapi/0.165.0/>.
- Uvicorn 0.54.0 release, Python requirement and provenance: <https://pypi.org/project/uvicorn/0.54.0/>.
- Uvicorn 0.54.0 release notes: <https://uvicorn.dev/release-notes/>.
- LiteLLM 1.110.2 release, Python requirement, wheel tags and provenance: <https://pypi.org/project/litellm/1.110.2/>.

